#!/usr/bin/env bash
# Self-hosting: SITE_URL=https://your-domain ./build-apk.sh points the app at your own site.
D0="$(cd "$(dirname "$0")" && pwd)"; if [ -n "${SITE_URL:-}" ]; then H=${SITE_URL#https://}; H=${H%%/*}; sed -i "s#https://mrfluency.higgsfield.app#https://$H#g; s#\"mrfluency.higgsfield.app\"#\"$H\"#g" "$D0/src/com/mrfluency/academy/MainActivity.java" "$D0/assets/offline.html"; fi
# Builds the Mr. Fluency Android app without Gradle: aapt2 + javac + d8 + apksigner.
# Usage: KEYSTORE=/path/mf-release.jks KS_PASS=... bash build-apk.sh
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
T="${TOOLS:-$HOME/android-tools}"; mkdir -p "$T"; cd "$T"
if [ ! -x "$T/jdk/bin/javac" ]; then
  curl -fsSL -o jdk.tgz "https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse"
  mkdir -p jdk && tar -xzf jdk.tgz -C jdk --strip-components=1 && rm jdk.tgz
fi
export JAVA_HOME="$T/jdk"; export PATH="$JAVA_HOME/bin:$PATH"
SDK="$T/sdk"
if [ ! -x "$SDK/build-tools/34.0.0/aapt2" ]; then
  mkdir -p "$SDK/cmdline-tools"
  curl -fsSL -o clt.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  unzip -q -o clt.zip -d "$SDK/cmdline-tools" && rm clt.zip && mv "$SDK/cmdline-tools/cmdline-tools" "$SDK/cmdline-tools/latest" || true
  yes | "$SDK/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK" --licenses >/dev/null || true
  "$SDK/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK" "platforms;android-34" "build-tools;34.0.0" >/dev/null
fi
BT="$SDK/build-tools/34.0.0"; JAR="$SDK/platforms/android-34/android.jar"
OUT="$HERE/build"; rm -rf "$OUT"; mkdir -p "$OUT/gen" "$OUT/classes" "$OUT/res"
cp -r "$HERE/res/." "$OUT/res/"
# Launcher icons from the site logo, on the navy brand colour.
python3 - "$HERE/../app/public/brand/mf-logo.png" "$OUT/res" <<'PY'
import sys, os
from PIL import Image, ImageDraw
src, res = sys.argv[1], sys.argv[2]
logo = Image.open(src).convert("RGBA")
for name, px in [("mdpi",48),("hdpi",72),("xhdpi",96),("xxhdpi",144),("xxxhdpi",192)]:
    S = px * 4
    im = Image.new("RGBA", (S, S), (0,0,0,0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((0,0,S-1,S-1), radius=int(S*0.22), fill=(6,14,34,255), outline=(255,213,74,255), width=max(4,S//40))
    w = int(S*0.72); lg = logo.copy(); lg.thumbnail((w, w), Image.LANCZOS)
    im.alpha_composite(lg, ((S-lg.width)//2, (S-lg.height)//2))
    d2 = os.path.join(res, "mipmap-"+name); os.makedirs(d2, exist_ok=True)
    im.resize((px,px), Image.LANCZOS).save(os.path.join(d2, "ic_launcher.png"))
PY
"$BT/aapt2" compile --dir "$OUT/res" -o "$OUT/res.zip"
"$BT/aapt2" link -o "$OUT/base.apk" -I "$JAR" --manifest "$HERE/AndroidManifest.xml" -A "$HERE/assets" --java "$OUT/gen" "$OUT/res.zip" --min-sdk-version 24 --target-sdk-version 34
javac -encoding UTF-8 -nowarn -source 8 -target 8 -bootclasspath "$JAR" -classpath "$JAR" -d "$OUT/classes" $(find "$HERE/src" "$OUT/gen" -name '*.java') 2>&1 | grep -v "warning" || true
"$BT/d8" --release --min-api 24 --lib "$JAR" --output "$OUT" $(find "$OUT/classes" -name '*.class')
cp "$OUT/base.apk" "$OUT/unsigned.apk"; (cd "$OUT" && zip -q -j unsigned.apk classes.dex)
"$BT/zipalign" -f -p 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"
KEYSTORE="${KEYSTORE:-$T/mf-release.jks}"
if [ ! -f "$KEYSTORE" ]; then
  keytool -genkeypair -keystore "$KEYSTORE" -alias mrfluency -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass "$KS_PASS" -keypass "$KS_PASS" -dname "CN=Ali Alhasawee, OU=Mr. Fluency Academy, O=Mr. Fluency, L=Basra, C=IQ"
fi
"$BT/apksigner" sign --ks "$KEYSTORE" --ks-key-alias mrfluency --ks-pass "pass:$KS_PASS" --key-pass "pass:$KS_PASS" --out "$OUT/mr-fluency.apk" "$OUT/aligned.apk"
"$BT/apksigner" verify --print-certs "$OUT/mr-fluency.apk" | head -3
"$BT/aapt2" dump badging "$OUT/mr-fluency.apk" | head -4
ls -la "$OUT/mr-fluency.apk"
