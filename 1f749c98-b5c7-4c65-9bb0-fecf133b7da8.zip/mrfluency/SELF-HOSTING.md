# Mr. Fluency Academy — host it yourself (GitHub + free Cloudflare)

Your code lives in **your GitHub**. Every time you push to `main`, GitHub Actions
builds the site and deploys it to **your own free Cloudflare account**
(Worker for the site, D1 for the database, R2 for videos/audio/files).
GitHub Pages alone can't run logins, the database or the owner alerts — Cloudflare does that part for free.

Total time: about 30 minutes, once.

---

## 1. Create the two free accounts
- GitHub: https://github.com/signup
- Cloudflare: https://dash.cloudflare.com/sign-up

## 2. Get your Cloudflare Account ID and API token
1. In the Cloudflare dashboard, open **Workers & Pages**. Your **Account ID** is shown on the right. Copy it.
2. Go to **My Profile → API Tokens → Create Token → "Edit Cloudflare Workers"** template.
3. Under *Permissions* click **+ Add more** and add:
   - Account → **D1** → Edit
   - Account → **Workers R2 Storage** → Edit
4. *Account Resources*: Include → your account. *Zone Resources*: All zones.
5. **Continue → Create Token**. Copy the token (it is shown only once).
6. In **R2** (left menu), click **Enable R2** once (free plan; it may ask for a card but the free tier costs nothing).

## 3. Put the code on GitHub
1. On GitHub click **New repository** → name it `mrfluency` → **Private** → Create.
2. Easiest upload: install **GitHub Desktop** (https://desktop.github.com), then
   *File → Add local repository* → choose the unzipped `mrfluency` folder → *Publish repository*.
   (Or on the repo page: *uploading an existing file* → drag in all the unzipped files.)

## 4. Add your secrets (never paste these anywhere else)
Repo → **Settings → Secrets and variables → Actions**.

**Secrets** tab → *New repository secret*:

| Name | Value |
|---|---|
| `CLOUDFLARE_API_TOKEN` | token from step 2 |
| `CLOUDFLARE_ACCOUNT_ID` | account ID from step 2 |
| `OWNER_EMAIL` | ali.alhasawee@gmail.com |
| `OWNER_PASSWORD` | your owner password (same as the current site) |
| `RESEND_API_KEY` | *(optional)* for email alerts — same key as on Higgsfield |
| `CALLMEBOT_APIKEY` | *(optional)* for WhatsApp alerts — same key as on Higgsfield |
| `OWNER_WHATSAPP` | *(optional)* +9647803402205 |

**Variables** tab → *New repository variable* (add after the first deploy, see step 5):

| Name | Value |
|---|---|
| `SITE_URL` | your new address, e.g. `https://mrfluency.<your-name>.workers.dev` |

## 5. First deploy
Repo → **Actions** → *Deploy to Cloudflare* → **Run workflow** (or just push any change).
It creates the database and storage automatically, then deploys.
When it finishes (green tick), Cloudflare → **Workers & Pages → mrfluency** shows your address
(`https://mrfluency.<your-subdomain>.workers.dev`). Put that address into the `SITE_URL` variable and run the deploy once more.

## 6. Copy students, results, courses and videos from the old site
Repo → **Actions** → *Migrate data from old site* → **Run workflow** → choose `everything`.
It signs in to https://mrfluency.higgsfield.app as the owner, copies every database table and every
video/audio/file into your Cloudflare account. It is safe to run again (it overwrites, never duplicates).
Media can take a while (up to an hour); if it times out, just run it again with `media-only`.

## 7. Check it
Open your new address → sign in as Owner → Studio: courses, students, Inbox, placement results should all be there.
Try *Send test alert* in the Inbox.

## 8. Your own domain (optional)
Cloudflare → Workers & Pages → mrfluency → **Settings → Domains & Routes → Add → Custom domain**.
Then update `SITE_URL` and deploy again.

## 9. Android app
The current APK points to the Higgsfield address. To point it at the new site, build it with:
```
SITE_URL=https://your-new-address bash android/build-apk.sh
```
Copy the new `mr-fluency.apk` into `app/public/download/` and push. Because a fresh signing key is used,
students uninstall the old app and install the new one once.

## Updating later
Edit files (or ask Claude to), push to `main` → the site updates automatically in ~3 minutes.

## What is where
- `app/` — the website (React + TanStack Start, runs as a Cloudflare Worker)
- `app/migrations/` — database structure (applied automatically on deploy)
- `app/wrangler.selfhost.jsonc` — Cloudflare settings for your account
- `.github/workflows/deploy.yml` — build + deploy on every push
- `.github/workflows/migrate.yml` + `scripts/migrate-from-higgsfield.mjs` — one-time data copy
- `content/` — course scripts and the generator used to make lessons/audio/video
- `android/` — the Android app source and build script
