#!/usr/bin/env python3
"""Mr. Fluency course builder.

Turns one chapter JSON (content/<LEVEL>/<nn>.json) into a published unit of the
General English course: 4 lessons (video, dialogue+listening audio, reading+audio,
speaking & writing), a quiz after every lesson and a chapter test. `--final LEVEL`
builds the level's final exam from the chapter tests. Everything uses stable ids
(uuid5), so re-running updates in place instead of duplicating.

Usage: OWNER_EMAIL=... OWNER_PW=... python3 build.py content/A1/01.json [...]
       OWNER_EMAIL=... OWNER_PW=... python3 build.py --final A1
"""
import json, os, sys, time, uuid, subprocess, tempfile, textwrap, glob, shutil
import requests
from concurrent.futures import ThreadPoolExecutor
from PIL import Image, ImageDraw, ImageFont

BASE = os.environ.get("SITE", "https://mrfluency.higgsfield.app")
NS = uuid.UUID("6f1c2a9e-5a1d-4b7e-9c3f-4d7266a1c0de")
HERE = os.path.dirname(os.path.abspath(__file__))
LOGO = os.path.join(HERE, "..", "app", "public", "brand", "mf-logo.png")
LEVELS = {"A1": ("A1 - Beginner", 0), "A2": ("A2 - Elementary", 1), "B1": ("B1 - Intermediate", 2),
          "B2": ("B2 - Upper-Intermediate", 3), "C1": ("C1 - Advanced", 4)}
RATE = {"A1": "-12%", "A2": "-8%", "B1": "-4%", "B2": "+0%", "C1": "+0%"}
# Courses this builder can publish. COURSE env picks one (default General English).
COURSES = {
    "general-english": {"title": "General English", "dir": "", "key": "", "unit": "Chapter", "short": "",
                        "levels": LEVELS},
    "business-english": {"title": "Business English", "dir": "BE", "key": "BE:", "unit": "Unit", "short": "BE",
        "subtitle": "Professional communication for the workplace",
        "description": "Twenty-one units from Mr. Fluency's Business English book: vocabulary, emails, meetings, negotiation, reports, proposals and presentations — with video lessons, audio, quizzes, unit tests and a final exam for each level.",
        "levels": {"B1": ("B1 - Business Foundations", 0), "B2": ("B2 - Professional Communication", 1), "C1": ("C1 - Advanced Business Skills", 2)}},
    "email-writing": {"title": "Email & Business Writing", "dir": "EW", "key": "EW:", "unit": "Chapter", "short": "EW",
        "subtitle": "Write clear, professional emails",
        "description": "Ten chapters from Mr. Fluency's Email Writing book: structure, etiquette, subject lines, tone, inquiries, requests, complaints, persuasion, proofreading and advanced business email techniques — with video lessons, audio, quizzes and final exams.",
        "levels": {"B1": ("B1 - Email Essentials", 0), "B2": ("B2 - Professional & Business Emails", 1)}},
}
SLUG = os.environ.get("COURSE", "general-english")
CUR = COURSES[SLUG]
LV = CUR["levels"]
def ckey(s): return CUR["key"] + s
NARRATOR = "en-GB-SoniaNeural"
CAST = ["en-US-GuyNeural", "en-US-JennyNeural", "en-GB-RyanNeural", "en-US-AriaNeural", "en-GB-ThomasNeural", "en-US-MichelleNeural"]
FEMALE = {"anna","sara","sarah","lisa","maya","lina","layla","mary","emma","noor","fatima","zainab","huda","mona","nora","sophie",
          "amina","rana","dina","hana","leila","laila","reem","sana","jane","kate","olivia","mia","lucy","amy","julia","maria","nadia",
          "salma","yasmin","aisha","mariam","maryam","rose","emily","grace","linda","susan","nina","zara","ella","chloe","waitress",
          "mom","mother","sister","teacher (f)","she","woman","girl","customer (f)","receptionist","nurse","hala","ruba","shahad","ola"}
UA = {"user-agent": "mf-course-builder/1.0"}

def uid(key): return str(uuid.uuid5(NS, key))

# ---------------- API ----------------
class API:
    def __init__(self):
        self.s = requests.Session(); self.s.headers.update(UA)
        r = self.call("POST", "/api/auth", json={"action": "owner_login", "email": os.environ["OWNER_EMAIL"], "password": os.environ["OWNER_PW"]})
        assert r.get("ok"), "owner login failed"
        self._media = None
    def call(self, method, path, tries=6, **kw):
        last = None
        for i in range(tries):
            try:
                r = self.s.request(method, BASE + path, timeout=180, **kw)
                if r.status_code < 500 and "temporarily unavailable" not in r.text[:80]:
                    d = r.json()
                    if r.status_code >= 400: raise RuntimeError(f"{path} {r.status_code} {d}")
                    return d
                last = f"{r.status_code} {r.text[:120]}"
            except (requests.RequestException, ValueError) as e:
                last = str(e)
            time.sleep(1.5 * (i + 1))
        raise RuntimeError(f"{path} failed: {last}")
    def cms(self, action, **payload): return self.call("POST", "/api/cms", json={"action": action, **payload})
    def media(self):
        if self._media is None:
            self._media = {m["title"]: m["url"] for m in self.call("GET", "/api/media")["media"]}
        return self._media
    def upload(self, path, title, mime):
        if title in self.media(): return self.media()[title]
        for i in range(5):
            try:
                with open(path, "rb") as f:
                    r = self.s.post(BASE + "/api/media", files={"file": (os.path.basename(path), f, mime)}, data={"title": title}, timeout=300)
                if r.ok and r.json().get("url"):
                    self._media[title] = r.json()["url"]; return r.json()["url"]
            except requests.RequestException: pass
            time.sleep(2 * (i + 1))
        raise RuntimeError("upload failed " + title)

# ---------------- audio ----------------
def tts(text, voice, out, rate="+0%"):
    for i in range(4):
        p = subprocess.run(["edge-tts", "--voice", voice, "--rate=" + rate, "--text", text, "--write-media", out], capture_output=True)
        if p.returncode == 0 and os.path.getsize(out) > 500: return out
        time.sleep(2)
    raise RuntimeError("tts failed: " + text[:60])

def dur(path):
    return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path]).strip())

def concat_audio(parts, out, gap=0.45):
    """parts: list of mp3 paths -> one mp3 with short silences between."""
    tmp = tempfile.mkdtemp(); lst = os.path.join(tmp, "l.txt"); sil = os.path.join(tmp, "s.wav")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "anullsrc=r=24000:cl=mono", "-t", str(gap), sil], check=True)
    with open(lst, "w") as f:
        for i, p in enumerate(parts):
            w = os.path.join(tmp, f"{i}.wav")
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", p, "-ar", "24000", "-ac", "1", w], check=True)
            f.write(f"file '{w}'\nfile '{sil}'\n")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst, "-c:a", "libmp3lame", "-b:a", "64k", out], check=True)
    shutil.rmtree(tmp, ignore_errors=True)
    return out

def voice_for(name, order):
    n = name.strip().lower().split(" ")[0]
    female = n in FEMALE or n.endswith("a") and n not in {"omar"}
    pool = [v for v in CAST if (("Jenny" in v or "Aria" in v or "Michelle" in v) == female)]
    return pool[order.index(name) % len(pool)] if name in order else pool[0]

def conversation_audio(convs, out, rate):
    tmp = tempfile.mkdtemp(); parts = []; order = []
    for c in convs:
        for spk, _ in c["turns"]:
            if spk not in order: order.append(spk)
    jobs = []
    for c in convs:
        if len(convs) > 1 and c.get("title"):
            jobs.append((c["title"] + ".", NARRATOR, os.path.join(tmp, f"{len(jobs)}.mp3")))
        for spk, text in c["turns"]:
            jobs.append((text, voice_for(spk, order), os.path.join(tmp, f"{len(jobs)}.mp3")))
    with ThreadPoolExecutor(6) as ex:
        parts = list(ex.map(lambda j: tts(j[0], j[1], j[2], rate), jobs))
    concat_audio(parts, out)
    shutil.rmtree(tmp, ignore_errors=True)
    return out

# ---------------- video ----------------
def font(name, size):
    for p in [f"/usr/share/fonts/truetype/dejavu/{name}.ttf", f"/usr/share/fonts/truetype/liberation/{name}.ttf"]:
        if os.path.exists(p): return ImageFont.truetype(p, size)
    return ImageFont.load_default()
F_TITLE = lambda s: font("DejaVuSerif-Bold", s)
F_BODY = lambda s: font("DejaVuSans", s)
F_BOLD = lambda s: font("DejaVuSans-Bold", s)
INK, BRASS, GARNET, CHALK, MUTED = (27, 25, 23), (224, 178, 90), (140, 47, 57), (244, 238, 227), (190, 180, 162)

def canvas(level, chapter):
    im = Image.new("RGB", (1280, 720), INK); d = ImageDraw.Draw(im)
    for y in range(720):  # warm vertical gradient
        c = int(18 + 16 * y / 720); d.line([(0, y), (1280, y)], fill=(c + 6, c, c - 4))
    d.ellipse((-220, -260, 420, 380), fill=(58, 24, 29)); d.ellipse((980, 470, 1480, 970), fill=(52, 40, 20))
    d.rectangle((80, 640, 1200, 642), fill=BRASS)
    try:
        lg = Image.open(LOGO).convert("RGBA"); lg.thumbnail((56, 58)); im.paste(lg, (80, 34), lg)
    except Exception: pass
    d.text((150, 46), "Mr. Fluency Academy", font=F_BOLD(24), fill=CHALK)
    d.text((1200, 655), f"{CUR['short'] + ' ' if CUR['short'] else ''}{level} · {CUR['unit']} {chapter}", font=F_BODY(20), fill=MUTED, anchor="ra")
    return im, d

def wrap(d, text, fnt, width):
    words, lines, cur = text.split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if d.textlength(t, font=fnt) <= width: cur = t
        else: lines.append(cur); cur = w
    if cur: lines.append(cur)
    return lines

def slide_title(path, level, ch, title, sub):
    im, d = canvas(level, ch)
    d.text((80, 200), f"{(CUR['title'] + ' · ') if CUR['short'] else ''}{LV[level][0]}  ·  {CUR['unit']} {ch}", font=F_BOLD(28), fill=BRASS)
    y = 250
    for ln in wrap(d, title, F_TITLE(72), 1100)[:3]:
        d.text((80, y), ln, font=F_TITLE(72), fill=CHALK); y += 88
    d.text((80, y + 20), sub, font=F_BODY(34), fill=MUTED)
    im.save(path)

def slide_word(path, level, ch, i, n, term, example):
    im, d = canvas(level, ch)
    d.text((80, 150), f"WORD {i} / {n}", font=F_BOLD(24), fill=BRASS)
    y = 200
    for ln in wrap(d, term, F_TITLE(84), 1100)[:2]:
        d.text((80, y), ln, font=F_TITLE(84), fill=CHALK); y += 100
    d.rectangle((80, y + 18, 200, y + 22), fill=GARNET)
    y += 60
    for ln in wrap(d, example, F_BODY(40), 1100)[:4]:
        d.text((80, y), ln, font=F_BODY(40), fill=(230, 220, 200)); y += 54
    im.save(path)

def slide_text(path, level, ch, head, body, bullets=()):
    im, d = canvas(level, ch)
    d.text((80, 130), head.upper(), font=F_BOLD(26), fill=BRASS)
    y = 180
    for ln in wrap(d, body, F_BODY(36), 1110)[:5]:
        d.text((80, y), ln, font=F_BODY(36), fill=CHALK); y += 48
    y += 16
    for b in bullets[:6]:
        for j, ln in enumerate(wrap(d, b, F_BODY(32), 1060)[:2]):
            d.text((80 if j == 0 else 112, y), ("▸  " if j == 0 else "") + ln, font=F_BODY(32), fill=(232, 214, 170)); y += 42
        y += 6
    im.save(path)

def render_video(segments, out):
    """segments: list of (png, mp3). Each slide lasts as long as its narration + a beat."""
    tmp = tempfile.mkdtemp(); lst = os.path.join(tmp, "v.txt")
    with open(lst, "w") as f:
        for i, (png, mp3) in enumerate(segments):
            seg = os.path.join(tmp, f"{i}.mp4"); t = dur(mp3) + 0.8
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-framerate", "24", "-i", png, "-i", mp3,
                            "-filter_complex", f"[0:v]fade=t=in:st=0:d=0.35,format=yuv420p[v];[1:a]apad=pad_dur=0.8,aresample=44100[a]",
                            "-map", "[v]", "-map", "[a]", "-t", f"{t:.2f}", "-c:v", "libx264", "-preset", "veryfast", "-tune", "stillimage",
                            "-crf", "28", "-c:a", "aac", "-b:a", "96k", "-ac", "1", seg], check=True)
            f.write(f"file '{seg}'\n")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", "-movflags", "+faststart", out], check=True)
    shutil.rmtree(tmp, ignore_errors=True)
    return out

def lesson_video(C, out):
    L, n, rate = C["level"], C["n"], RATE[C["level"]]
    tmp = tempfile.mkdtemp(); segs = []; jobs = []
    def seg(png_fn, text, *a):
        k = len(segs); png = os.path.join(tmp, f"{k}.png"); mp3 = os.path.join(tmp, f"{k}.mp3")
        png_fn(png, *a); jobs.append((text, mp3)); segs.append((png, mp3))
    g = C["grammar"]; vocab = C["vocab"]
    seg(slide_title, f"Welcome to {CUR['title'] + ', ' if CUR['short'] else ''}{LV[L][0].split(' - ')[0]}, {CUR['unit'].lower()} {n}: {C['title']}. In this lesson you will learn {len(vocab)} words and phrases, and the grammar: {g['title']}.",
        L, n, C["title"], "Vocabulary & Grammar")
    for i, (term, ex) in enumerate(vocab, 1):
        seg(slide_word, f"{term}. ... {ex}", L, n, i, len(vocab), term, ex)
    seg(slide_text, f"Grammar: {g['title']}. {g['rule']}", L, n, "Grammar · " + g["title"], g["rule"], [])
    exs = g.get("examples", [])
    for j in range(0, min(len(exs), 12), 4):
        chunk = exs[j:j + 4]
        seg(slide_text, "For example: " + " ... ".join(chunk), L, n, "Examples", "", chunk)
    seg(slide_text, "Great work! Now practise the words below, then take the short quiz to unlock the next lesson.",
        L, n, "Your turn", "Practise the words below, then take the quiz to unlock the next lesson.", [])
    with ThreadPoolExecutor(6) as ex:
        list(ex.map(lambda j: tts(j[0], NARRATOR, j[1], rate), jobs))
    render_video(segs, out); shutil.rmtree(tmp, ignore_errors=True)
    return out

# ---------------- questions ----------------
def question(key, L, topic, q):
    t = q[0]; base = {"id": uid(key), "bank": "course", "cefr": L, "topic": topic[:60], "difficulty": 2, "points": 1, "status": "published"}
    if t == "mcq":
        base.update(type="mcq", prompt=q[1], options=[{"text": o, "is_correct": i == q[3]} for i, o in enumerate(q[2])])
    elif t == "tf":
        base.update(type="truefalse", prompt=q[1], options=[{"text": "True", "is_correct": bool(q[2])}, {"text": "False", "is_correct": not q[2]}])
    elif t == "gap":
        base.update(type="gap", prompt=q[1], data={"answers": [a if isinstance(a, list) else [a] for a in q[2]]})
    elif t == "order":
        words = q[2][:]; shuffled = words[1:] + words[:1]
        base.update(type="order", prompt=q[1], data={"items": shuffled, "order": words})
    else: raise ValueError(t)
    if len(q) > 4 and t == "mcq": base["explanation"] = q[4]
    return base

# ---------------- build ----------------
def tree(api):
    try:
        return api.call("GET", f"/api/lms?what=course&slug={SLUG}", tries=2)
    except RuntimeError:
        api.cms("save_course", course={"id": uid("course-" + SLUG), "slug": SLUG, "title": CUR["title"], "subtitle": CUR.get("subtitle", ""),
            "description": CUR.get("description", ""), "category": "english", "goal": "business" if "business" in SLUG else "writing",
            "status": "published", "access": "open", "instructor": "Ali Alhasawee (Mr. Fluency)", "sort": len(COURSES)})
        return api.call("GET", f"/api/lms?what=course&slug={SLUG}")

def ensure_level(api, T, L):
    course_id = T["course"]["id"]
    for lv in T["tree"]["levels"]:
        if lv["cefr"] == L: return course_id, lv["id"]
    title, sort = LV[L]
    r = api.cms("save_level", level={"id": uid(ckey("level-" + L)), "course_id": course_id, "cefr": L, "title": title,
        "summary": (f"{L} chapters from the Mr. Fluency {L} English book." if not CUR["short"] else f"{title.split(' - ')[1]} — from Mr. Fluency's {CUR['title']} book."),
        "sort": sort, "status": "published", "unlock_rule": "none"})
    return course_id, r["id"]

def build_chapter(api, path):
    C = json.load(open(path)); L, n = C["level"], C["n"]; key = ckey(f"{L}-C{n:02d}"); rate = RATE[L]
    T = tree(api); course_id, level_id = ensure_level(api, T, L)
    work = tempfile.mkdtemp(); print(f"[{key}] {C['title']}", flush=True)
    # media (reused by title on re-runs)
    px = (CUR["short"] + " ") if CUR["short"] else ""
    vt, at, rt = px + f"{L} Ch{n} – {C['title']} · video", px + f"{L} Ch{n} – {C['title']} · listening", px + f"{L} Ch{n} – {C['title']} · reading"
    video_url = api.media().get(vt) or api.upload(lesson_video(C, os.path.join(work, "v.mp4")), vt, "video/mp4")
    print(f"[{key}] video ok", flush=True)
    lis = C["listening"]
    listen_url = api.media().get(at) or api.upload(conversation_audio([{"title": lis.get("title", ""), "turns": lis["turns"]}], os.path.join(work, "l.mp3"), rate), at, "audio/mpeg")
    rd = C["reading"]
    read_url = api.media().get(rt) or api.upload(tts(rd["title"] + ". " + rd["passage"], NARRATOR, os.path.join(work, "r.mp3"), rate), rt, "audio/mpeg")
    print(f"[{key}] audio ok", flush=True)

    first_of_level = n == 1
    mod_id = uid(key)
    batch = lambda items: api.cms("batch", items=[{"kind": k, "data": d} for k, d in items])
    batch([("module", {"id": mod_id, "level_id": level_id, "course_id": course_id, "code": f"{L}.{n}",
        "title": f"{CUR['unit']} {n} – {C['title']}", "summary": C.get("summary", ""), "hours": 3, "sort": 100 + LV[L][1] * 40 + n,
        "status": "published", "unlock_rule": ("min_score" if first_of_level and L != "A1" and not CUR["short"] else "previous_module"),
        "min_score": 60 if first_of_level and L != "A1" and not CUR["short"] else 0})])
    turns = lambda ts: [{"speaker": s, "text": t} for s, t in ts]
    lessons = [
        ("Vocabulary & Grammar", "Watch the video, learn the words and the grammar.", [
            ("video", True, {"title": f"{C['title']} – vocabulary & grammar", "url": video_url}),
            ("vocab", False, {"items": [{"term": a, "example": b} for a, b in C["vocab"]]}),
            ("grammar", False, {"title": C["grammar"]["title"], "rule": C["grammar"]["rule"], "examples": C["grammar"].get("examples", [])}),
        ]),
        ("Dialogues & Listening", "Practise real conversations, then listen and answer.", [
            ("dialogue", False, {"conversations": [{"title": d["title"], "turns": turns(d["turns"])} for d in C["dialogues"]]}),
            ("listening", True, {"title": lis.get("title", "Listening"), "task": lis.get("task", "Listen carefully, then answer the quiz."),
                                 "url": listen_url, "conversations": [{"title": lis.get("title", ""), "turns": turns(lis["turns"])}]}),
        ]),
        ("Reading", "Read the passage, listen to it, and check your understanding.", [
            ("reading", True, {"title": rd["title"], "passage": rd["passage"]}),
            ("audio", False, {"title": "Listen to the passage", "task": "Listen while you read.", "url": read_url}),
        ] + ([("gapfill", True, C["gapfill"])] if C.get("gapfill") else [])),
        ("Speaking & Writing", "Use the chapter's language to speak and write.", [
            ("speaking", False, {"prompts": C["speaking"]}),
            ("writing", False, {"prompts": C["writing"]}),
        ]),
    ]
    for k, (title, summary, blocks) in enumerate(lessons, 1):
        lk = f"{key}-L{k}"; lid = uid(lk)
        items = [("lesson", {"id": lid, "module_id": mod_id, "title": title, "summary": summary,
            "objective": summary, "duration_min": 20, "sort": k, "status": "published", "unlock_rule": "previous_lesson",
            "completion_rule": {"blocks": True, "quiz": True, "minQuizPct": 60}})]
        for j, (kind, req, data) in enumerate(blocks):
            items.append(("block", {"id": uid(f"{lk}-b{j}"), "lesson_id": lid, "kind": kind, "sort": j, "required": req, "data": data}))
        qs = [question(f"{lk}-q{i}", L, C["title"], q) for i, q in enumerate(C["quiz"][f"L{k}"])]
        qids = [q["id"] for q in qs]
        items += [("question", q) for q in qs]
        items.append(("quiz", {"id": uid(lk + "-quiz"), "title": f"Check: {title}", "description": f"{len(qids)} quick questions on this lesson.",
            "kind": "lesson", "course_id": course_id, "level_id": level_id, "module_id": mod_id, "lesson_id": lid,
            "pass_pct": 60, "status": "published", "question_ids": qids}))
        batch(items)
    qs = [question(f"{key}-exam-q{i}", L, C["title"], q) for i, q in enumerate(C["quiz"]["exam"])]
    qids = [q["id"] for q in qs]
    batch([("question", q) for q in qs] + [("quiz", {"id": uid(key + "-exam"), "title": f"Chapter {n} test: {C['title']}", "description": "End-of-chapter test.",
        "kind": "module_exam", "course_id": course_id, "level_id": level_id, "module_id": mod_id, "pass_pct": 60, "status": "published",
        "question_ids": qids})])
    shutil.rmtree(work, ignore_errors=True)
    print(f"[{key}] done", flush=True)

def build_final(api, L):
    T = tree(api); course_id, level_id = ensure_level(api, T, L)
    files = sorted(glob.glob(os.path.join(HERE, CUR["dir"], L, "*.json"))); qids = []
    for f in files:
        C = json.load(open(f)); key = ckey(f"{L}-C{C['n']:02d}")
        for i in range(min(3, len(C["quiz"]["exam"]))):
            qids.append(uid(f"{key}-exam-q{i}"))
    mid = uid(ckey(f"{L}-FINAL"))
    api.cms("save_module", module={"id": mid, "level_id": level_id, "course_id": course_id, "code": f"{L}.F",
        "title": f"{L} Final Exam", "summary": f"The final exam for level {L}. Finish every chapter first.", "hours": 1,
        "sort": 100 + LV[L][1] * 40 + 39, "status": "published", "unlock_rule": "previous_module"})
    api.cms("save_quiz", quiz={"id": uid(ckey(f"{L}-final-exam")), "title": f"{L} Final Exam", "description": f"{len(qids)} questions from every {L} chapter.",
        "kind": "final_exam", "course_id": course_id, "level_id": level_id, "module_id": mid, "pass_pct": 60,
        "time_limit_s": 0, "status": "published", "question_ids": qids})
    print(f"[{L}] final exam with {len(qids)} questions", flush=True)

if __name__ == "__main__":
    api = API()
    if sys.argv[1] == "--final":
        for L in sys.argv[2:]: build_final(api, L)
    elif sys.argv[1] == "--archive-module":
        for mid in sys.argv[2:]: print(api.cms("set_status", kind="module", id=mid, status="archived"))
    else:
        api.media()
        def run(p):
            try: build_chapter(api, p)
            except Exception as e: print(f"FAILED {p}: {e}", flush=True)
        with ThreadPoolExecutor(int(os.environ.get("PAR", "3"))) as ex:
            list(ex.map(run, sys.argv[1:]))
