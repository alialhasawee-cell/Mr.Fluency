#!/usr/bin/env node
// Copies the academy's database rows and uploaded media from the old site
// (mrfluency.higgsfield.app) into YOUR Cloudflare D1 database and R2 bucket.
// Run by .github/workflows/migrate.yml. Safe to re-run: rows are upserted and
// media is overwritten with identical copies.
import { execFileSync } from "node:child_process";
import { mkdirSync, writeFileSync, rmSync } from "node:fs";
import { join } from "node:path";

const OLD = (process.env.OLD_SITE || "https://mrfluency.higgsfield.app").replace(/\/$/, "");
const DB = process.env.D1_NAME || "mrfluency-db";
const BUCKET = process.env.R2_BUCKET || "mrfluency-media";
const CONFIG = process.env.WRANGLER_CONFIG || "app/wrangler.selfhost.jsonc";
const OUT = "migration-tmp";
const wr = (...a) => execFileSync("npx", ["-y", "wrangler@4", ...a], { stdio: ["ignore", "inherit", "inherit"] });

async function login() {
  const r = await fetch(OLD + "/api/auth", {
    method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify({ action: "owner_login", email: process.env.OWNER_EMAIL, password: process.env.OWNER_PASSWORD }),
  });
  const c = (r.headers.get("set-cookie") || "").match(/mf_session=[^;]+/);
  if (!r.ok || !c) throw new Error("Owner login on the old site failed (" + r.status + ")");
  return c[0];
}
async function get(cookie, qs, tries = 5) {
  for (let i = 0; i < tries; i++) {
    const r = await fetch(OLD + "/api/export?" + qs, { headers: { cookie } });
    if (r.ok) return r;
    await new Promise((s) => setTimeout(s, 1500 * (i + 1)));
  }
  throw new Error("Export request failed: " + qs);
}
const lit = (v) => v === null || v === undefined ? "NULL"
  : typeof v === "number" ? (Number.isFinite(v) ? String(v) : "NULL")
  : typeof v === "boolean" ? (v ? "1" : "0")
  : "'" + String(v).replace(/'/g, "''") + "'";

async function copyDatabase(cookie) {
  mkdirSync(OUT, { recursive: true });
  const { tables } = await (await get(cookie, "what=tables")).json();
  let file = 0, buf = [], size = 0, total = 0;
  const flush = () => {
    if (!buf.length) return;
    const p = join(OUT, `part-${String(file++).padStart(4, "0")}.sql`);
    writeFileSync(p, "PRAGMA defer_foreign_keys = true;\n" + buf.join("\n") + "\n");
    buf = []; size = 0;
  };
  for (const t of tables) {
    const create = String(t.sql).replace(/^CREATE TABLE\s+(?!IF NOT EXISTS)/i, "CREATE TABLE IF NOT EXISTS ");
    buf.push(create + ";");
    let offset = 0, n = 0;
    for (;;) {
      const { rows } = await (await get(cookie, `what=rows&table=${encodeURIComponent(t.name)}&offset=${offset}&limit=500`)).json();
      for (const row of rows) {
        const cols = Object.keys(row);
        const stmt = `INSERT OR REPLACE INTO "${t.name}" (${cols.map((c) => `"${c}"`).join(",")}) VALUES (${cols.map((c) => lit(row[c])).join(",")});`;
        buf.push(stmt); size += stmt.length; n++;
        if (size > 800_000) flush();
      }
      if (rows.length < 500) break;
      offset += 500;
    }
    total += n;
    console.log(`  ${t.name}: ${n} rows`);
  }
  flush();
  console.log(`Importing ${total} rows in ${file} batches…`);
  for (let i = 0; i < file; i++) {
    wr("d1", "execute", DB, "--remote", "--yes", "--config", CONFIG, "--file", join(OUT, `part-${String(i).padStart(4, "0")}.sql`));
  }
}

async function copyMedia(cookie) {
  let cursor = null, all = [];
  do {
    const d = await (await get(cookie, "what=objects" + (cursor ? "&cursor=" + encodeURIComponent(cursor) : ""))).json();
    all = all.concat(d.objects); cursor = d.cursor;
  } while (cursor);
  const mb = (all.reduce((s, o) => s + o.size, 0) / 1e6).toFixed(0);
  console.log(`Copying ${all.length} media files (${mb} MB)…`);
  let i = 0;
  for (const o of all) {
    const p = join(OUT, "obj");
    const r = await get(cookie, "what=object&key=" + encodeURIComponent(o.key));
    writeFileSync(p, Buffer.from(await r.arrayBuffer()));
    const args = ["r2", "object", "put", `${BUCKET}/${o.key}`, "--file", p, "--remote"];
    if (o.type) args.push("--content-type", o.type);
    wr(...args);
    if (++i % 25 === 0) console.log(`  ${i}/${all.length}`);
  }
}

const cookie = await login();
console.log("Logged in to the old site as owner.");
if (process.env.SKIP_DB !== "1") await copyDatabase(cookie);
if (process.env.SKIP_MEDIA !== "1") await copyMedia(cookie);
rmSync(OUT, { recursive: true, force: true });
console.log("Migration finished.");
