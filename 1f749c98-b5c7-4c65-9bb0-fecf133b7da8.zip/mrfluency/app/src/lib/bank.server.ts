// SERVER ONLY. The answer key never leaves this module: the API strips `a`
// before any question is sent to a browser.
export type Item = {
  id: string; level: Level; skill: Skill; focus: string;
  q: string; opts: string[]; a: number; passage?: string;
};
export type Level = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";
export type Skill = "Grammar" | "Vocabulary" | "Reading";
export const LEVELS: Level[] = ["A1", "A2", "B1", "B2", "C1", "C2"];
export const ALL_LEVELS = ["A0", ...LEVELS] as const;

const G = "Grammar", V = "Vocabulary", R = "Reading";
type Row = [string, Level, string, string, string, string[], number, string?];
const ROWS: Row[] = [
["a1-1","A1",G,"possessive adjectives","___ name is Omar and I live in Basra.",["My","I","Me","Mine"],0],
["a1-2","A1",G,"verb to be","She ___ a teacher at my school.",["are","is","am","be"],1],
["a1-3","A1",V,"everyday verbs","We usually ___ breakfast at seven o'clock.",["make","take","have","do"],2],
["a1-4","A1",G,"present simple, 3rd person","He ___ to school by bus every morning.",["go","goes","going","gone"],1],
["a1-5","A1",V,"opposites","This bag is very heavy, but that one is ___.",["short","light","small","thin"],1],
["a1-6","A1",G,"there is / there are","There ___ three books on the table.",["is","be","are","have"],2],
["a1-7","A1",G,"present simple negative","I ___ like coffee in the evening.",["am not","don't","doesn't","not"],1],
["a1-8","A1",R,"finding specific detail","Where does Sara work?",["In a school","In a hospital","In an office","In a shop"],1,"Sara is from Egypt. She lives in Dubai now. She works in a hospital and she starts work at eight o'clock. On Friday she does not work."],
["a2-1","A2",G,"past simple, irregular","Yesterday we ___ to the cinema with my cousins.",["go","goed","went","gone"],2],
["a2-2","A2",G,"comparatives","My brother is ___ than me, but I am older.",["tall","taller","tallest","more tall"],1],
["a2-3","A2",V,"places in town","I'm going to the ___ to buy some bread.",["library","bakery","pharmacy","stationery"],1],
["a2-4","A2",G,"present perfect + ever","Have you ___ been to London?",["never","yet","ever","already"],2],
["a2-5","A2",G,"first conditional","If it rains tomorrow, we ___ at home.",["stay","will stay","stayed","would stay"],1],
["a2-6","A2",V,"linking words","I was very tired, ___ I went to bed early.",["because","although","so","but"],2],
["a2-7","A2",G,"quantifiers","There isn't ___ milk left in the fridge.",["some","any","many","a few"],1],
["a2-8","A2",R,"understanding notices","When is it impossible to visit the museum?",["On Sunday morning","At 15:00 on Tuesday","On Monday","At 10:00 on Saturday"],2,"CITY MUSEUM - Open 9:00 to 17:00, Tuesday to Sunday. Closed on Mondays and public holidays. Entry is free for children under 12. Guided tours start at 11:00 and 15:00."],
["b1-1","B1",G,"since / for","I've been living in this city ___ 2019.",["for","since","from","during"],1],
["b1-2","B1",G,"reported speech","He said he ___ finish the report by Friday.",["will","would","is going to","shall"],1],
["b1-3","B1",V,"phrasal verbs","We had to ___ the meeting until next week because the manager was ill.",["put off","put on","put up","put out"],0],
["b1-4","B1",G,"passive voice","The letter ___ to head office yesterday afternoon.",["sent","was sent","has sent","is sending"],1],
["b1-5","B1",G,"second conditional","If I had more free time, I ___ Spanish.",["will learn","learn","would learn","had learned"],2],
["b1-6","B1",V,"describing character","She is completely ___ - she always tells you the truth, even when it is difficult.",["generous","honest","ambitious","patient"],1],
["b1-7","B1",G,"used to vs be used to","After six months on the night shift, I'm used ___ up at four in the morning.",["to get","to getting","get","getting"],1],
["b1-8","B1",R,"identifying reasons","Why did the students think the course was worth the money?",["The materials were excellent","The classes were small","It was cheaper than other courses","The lessons were in the evening"],1,"Although the evening course was more expensive than the others we looked at, almost every student we spoke to said it had been worth the money. The reason was not the materials, which were fairly ordinary, but the fact that classes never had more than eight people in them."],
["b2-1","B2",G,"past perfect","By the time we arrived, the meeting ___ already ___.",["has / started","had / started","was / starting","would / start"],1],
["b2-2","B2",G,"gerund after verb","He firmly denied ___ the confidential documents.",["to see","see","seeing","that he sees"],2],
["b2-3","B2",V,"formal reporting verbs","The audit ___ several weaknesses in the company's internal controls.",["withheld","highlighted","refrained","conceded"],1],
["b2-4","B2",V,"business phrasal verbs","With sales falling, the board decided to ___ back on marketing spend.",["cut","take","turn","bring"],0],
["b2-5","B2",G,"it's time + past","It's high time we ___ about this problem seriously.",["talk","will talk","talked","have talked"],2],
["b2-6","B2",G,"third conditional","If the supplier ___ us earlier, we could have changed the order.",["told","would tell","had told","has told"],2],
["b2-7","B2",V,"precise adjectives","Her argument was ___ - nobody in the room could find a single flaw in it.",["watertight","far-fetched","long-winded","one-sided"],0],
["b2-8","B2",R,"writer's attitude","What is the writer's attitude to remote work?",["Entirely opposed to it","Supportive but sees an overlooked condition","Convinced it solves every problem listed","Indifferent to the debate"],1,"Remote work is regularly presented as the answer to almost everything: commuting, productivity, staff retention, even city planning. It certainly solves some of these. What is rarely mentioned by its more enthusiastic advocates, however, is how much of its apparent success depends on relationships that were built in an office in the first place."],
["c1-1","C1",G,"inversion after not only","Not only ___ late for the interview, but he had also left the portfolio at home.",["he was","was he","he has been","had he been"],1],
["c1-2","C1",G,"negative inversion","Little ___ that the deal would collapse within a week.",["they knew","knew they","did they know","they did know"],2],
["c1-3","C1",V,"evaluative adjectives","The evidence was ___ at best, and the case collapsed on the second day.",["flimsy","robust","exhaustive","meticulous"],0],
["c1-4","C1",V,"fixed expressions","After eleven hours, the negotiations had ___ to a standstill.",["taken","come","gone","fallen"],1],
["c1-5","C1",G,"conditional inversion","___ for your intervention, the whole project would have failed.",["Was it not","Were it not","If it was not","Had it not"],1],
["c1-6","C1",G,"non-defining relative clause","He resigned two days before the audit, ___ came as a surprise to nobody.",["that","what","which","who"],2],
["c1-7","C1",V,"nuance","The difference between the two proposals is ___, but in a regulated market it matters enormously.",["blatant","subtle","conspicuous","drastic"],1],
["c1-8","C1",R,"implied stance","What does the writer imply about the minister's plan?",["It was a courageous and deliberate choice","It was forced by earlier decisions rather than chosen","It was cheaper than the alternatives","It was invented by the press"],1,"The minister's plan has been described in the press as bold. It would be more accurate to call it unavoidable. Having spent four years ruling out every cheaper option, the department arrived at the only policy still available to it and then presented that arrival as a decision."],
["c2-1","C2",G,"mandative subjunctive","The board insisted that the policy ___ reviewed before the end of the quarter.",["is","be","was","would be"],1],
["c2-2","C2",V,"register and connotation","His apology was so ___ that it gave more offence than the original remark.",["heartfelt","perfunctory","effusive","candid"],1],
["c2-3","C2",V,"idiomatic meaning","To damn something with faint praise is to ___.",["praise it so warmly that it sounds false","criticise it openly and at length","praise it so mildly that the praise reads as criticism","refuse to comment on it at all"],2],
["c2-4","C2",V,"academic collocation","Despite a ___ of hard evidence, the theory continues to circulate widely.",["wealth","paucity","surfeit","plethora"],1],
["c2-5","C2",G,"inversion after fronted adverbial","Only after the report was leaked ___ the true scale of the problem.",["we grasped","did we grasp","we did grasp","had we grasped"],1],
["c2-6","C2",V,"low-frequency lexis","Years on the emergency ward had left her almost entirely ___ to the sight of blood.",["inured","averse","susceptible","partial"],0],
["c2-7","C2",G,"complex concession","___ though the findings may appear, they have survived three independent replications.",["Improbable","However improbable","As improbably","Improbably as"],0],
["c2-8","C2",R,"dense argumentation","The writer's central concern is whether the failure ___.",["actually took place","can support any wider conclusion","was the director's fault","was predicted by the regulator"],1,"That the scheme failed is not in dispute. What remains contested is whether its failure tells us anything general at all, or whether the conditions under which it ran were so particular - a collapsing currency, an unusually hostile regulator, a single departing director - that any lesson drawn from it says more about the person drawing it than about the scheme."],
];

export const BANK: Item[] = ROWS.map((r) => ({
  id: r[0], level: r[1], skill: r[2] as Skill, focus: r[3],
  q: r[4], opts: r[5], a: r[6], passage: r[7],
}));

const BY_ID = new Map(BANK.map((i) => [i.id, i]));
export function itemById(id: string): Item | undefined { return BY_ID.get(id); }
export function itemsForLevel(level: Level): Item[] {
  return BANK.filter((i) => i.level === level);
}
// What a browser is allowed to see.
export function publicItem(i: Item) {
  return { id: i.id, level: i.level, skill: i.skill, q: i.q, opts: i.opts, passage: i.passage ?? null };
}
