// SERVER ONLY — every administrative write. Callers are role-checked by the
// route; nothing here reads identity from client input.
import { db, audit } from "./auth.server";

const now = () => Date.now();
const uid = () => crypto.randomUUID();
const S = (v: unknown, max = 200) => (typeof v === "string" ? v.trim().slice(0, max) : "");
const N = (v: unknown, d = 0) => { const n = Number(v); return Number.isFinite(n) ? Math.trunc(n) : d; };
const STATUS = ["draft", "published", "archived"];
const st = (v: unknown, d = "draft") => (STATUS.includes(String(v)) ? String(v) : d);
const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60);

export async function upsertCourse(actor: string, input: any) {
  const id = S(input.id) || uid();
  const title = S(input.title, 120);
  if (!title) return { error: "title_required" as const };
  const t = now();
  const ex = await db().prepare("SELECT id FROM courses WHERE id=?").bind(id).first<any>();
  const v = [title, S(input.subtitle, 200), S(input.description, 4000), S(input.category, 40), S(input.goal, 30),
    S(input.color, 40), S(input.thumbnail_url, 400), S(input.instructor, 120), st(input.status),
    S(input.access, 20) || "open", N(input.price_cents), S(input.currency, 8) || "USD", N(input.sort)];
  if (ex) {
    await db().prepare(
      `UPDATE courses SET title=?,subtitle=?,description=?,category=?,goal=?,color=?,thumbnail_url=?,instructor=?,
       status=?,access=?,price_cents=?,currency=?,sort=?,updated_at=? WHERE id=?`).bind(...v, t, id).run();
  } else {
    await db().prepare(
      `INSERT INTO courses (id,slug,title,subtitle,description,category,goal,color,thumbnail_url,instructor,status,
       access,price_cents,currency,sort,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .bind(id, S(input.slug, 60) || slugify(title), ...v, t, t).run();
  }
  await audit(actor, "CMS_COURSE_SAVED", { id, title });
  return { id };
}

export async function upsertLevel(actor: string, input: any) {
  const id = S(input.id) || uid();
  const courseId = S(input.course_id);
  if (!courseId) return { error: "course_required" as const };
  const t = now();
  const v = [S(input.cefr, 4), S(input.title, 120), S(input.summary, 1000), N(input.sort), st(input.status),
    S(input.unlock_rule, 20) || "none"];
  const ex = await db().prepare("SELECT id FROM course_levels WHERE id=?").bind(id).first<any>();
  if (ex) {
    await db().prepare("UPDATE course_levels SET cefr=?,title=?,summary=?,sort=?,status=?,unlock_rule=?,updated_at=? WHERE id=?")
      .bind(...v, t, id).run();
  } else {
    await db().prepare(
      `INSERT INTO course_levels (id,course_id,cefr,title,summary,sort,status,unlock_rule,created_at,updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?)`).bind(id, courseId, ...v, t, t).run();
  }
  return { id };
}

export async function upsertModule(actor: string, input: any) {
  const id = S(input.id) || uid();
  const levelId = S(input.level_id), courseId = S(input.course_id);
  if (!levelId || !courseId) return { error: "level_required" as const };
  const t = now();
  const v = [S(input.code, 20), S(input.title, 160), S(input.summary, 1000), N(input.hours), N(input.sort),
    st(input.status), S(input.unlock_rule, 20) || "previous_module", N(input.min_score)];
  const ex = await db().prepare("SELECT id FROM modules WHERE id=?").bind(id).first<any>();
  if (ex) {
    await db().prepare(
      `UPDATE modules SET code=?,title=?,summary=?,hours=?,sort=?,status=?,unlock_rule=?,min_score=?,updated_at=? WHERE id=?`)
      .bind(...v, t, id).run();
  } else {
    await db().prepare(
      `INSERT INTO modules (id,level_id,course_id,code,title,summary,hours,sort,status,unlock_rule,min_score,created_at,updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(id, levelId, courseId, ...v, t, t).run();
  }
  return { id };
}

export async function upsertLesson(actor: string, input: any) {
  const id = S(input.id) || uid();
  const moduleId = S(input.module_id);
  if (!moduleId) return { error: "module_required" as const };
  const mod = await db().prepare("SELECT course_id,level_id FROM modules WHERE id=?").bind(moduleId).first<any>();
  if (!mod) return { error: "module_not_found" as const };
  const rule = JSON.stringify({
    blocks: input.completion_rule?.blocks !== false,
    quiz: !!input.completion_rule?.quiz,
    minQuizPct: N(input.completion_rule?.minQuizPct),
  });
  const t = now();
  const v = [S(input.title, 160), S(input.summary, 1000), S(input.objective, 500), N(input.duration_min, 15),
    N(input.sort), st(input.status), S(input.unlock_rule, 24) || "previous_lesson", rule];
  const ex = await db().prepare("SELECT id FROM lessons WHERE id=?").bind(id).first<any>();
  if (ex) {
    await db().prepare(
      `UPDATE lessons SET title=?,summary=?,objective=?,duration_min=?,sort=?,status=?,unlock_rule=?,
       completion_rule=?,updated_at=? WHERE id=?`).bind(...v, t, id).run();
  } else {
    await db().prepare(
      `INSERT INTO lessons (id,module_id,course_id,level_id,title,summary,objective,duration_min,sort,status,
       unlock_rule,completion_rule,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .bind(id, moduleId, mod.course_id, mod.level_id, ...v, t, t).run();
  }
  return { id };
}

const BLOCK_KINDS = ["heading","text","image","gallery","vocab","grammar","example","examples","dialogue","audio","video",
  "animation","pdf","reading","listening","speaking","writing","activity","quiz","assignment","callout",
  // coursebook blocks: a self-marking gap-fill, and warm-ups shown to staff only
  "gapfill","teachernotes"];

export async function upsertBlock(_actor: string, input: any) {
  const id = S(input.id) || uid();
  const lessonId = S(input.lesson_id);
  const kind = BLOCK_KINDS.includes(String(input.kind)) ? String(input.kind) : "";
  if (!lessonId || !kind) return { error: "lesson_and_kind_required" as const };
  const data = JSON.stringify(input.data ?? {}).slice(0, 60000);
  const t = now();
  const ex = await db().prepare("SELECT id FROM lesson_blocks WHERE id=?").bind(id).first<any>();
  if (ex) {
    await db().prepare("UPDATE lesson_blocks SET kind=?,sort=?,required=?,data=?,updated_at=? WHERE id=?")
      .bind(kind, N(input.sort), input.required ? 1 : 0, data, t, id).run();
  } else {
    await db().prepare(
      "INSERT INTO lesson_blocks (id,lesson_id,kind,sort,required,data,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)")
      .bind(id, lessonId, kind, N(input.sort), input.required ? 1 : 0, data, t, t).run();
  }
  return { id };
}

export async function upsertQuestion(actor: string, input: any) {
  const id = S(input.id) || uid();
  const t = now();
  const v = [S(input.bank, 20) || "course", S(input.type, 20), S(input.cefr, 4), S(input.skill, 20),
    S(input.topic, 60), N(input.difficulty, 2), S(input.prompt, 2000), S(input.passage, 4000) || null,
    S(input.media_id) || null, S(input.explanation, 1000), N(input.points, 1),
    JSON.stringify(input.data ?? {}).slice(0, 20000), st(input.status, "published")];
  const ex = await db().prepare("SELECT id FROM questions WHERE id=?").bind(id).first<any>();
  if (ex) {
    await db().prepare(
      `UPDATE questions SET bank=?,type=?,cefr=?,skill=?,topic=?,difficulty=?,prompt=?,passage=?,media_id=?,
       explanation=?,points=?,data=?,status=?,updated_at=? WHERE id=?`).bind(...v, t, id).run();
    await db().prepare("DELETE FROM question_options WHERE question_id=?").bind(id).run();
  } else {
    await db().prepare(
      `INSERT INTO questions (id,bank,type,cefr,skill,topic,difficulty,prompt,passage,media_id,explanation,points,
       data,status,created_by,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .bind(id, ...v, actor, t, t).run();
  }
  const opts = Array.isArray(input.options) ? input.options : [];
  for (let i = 0; i < opts.length; i++) {
    await db().prepare(
      "INSERT INTO question_options (id,question_id,sort,text,is_correct,media_id) VALUES (?,?,?,?,?,?)")
      .bind(uid(), id, i, S(opts[i].text, 500), opts[i].is_correct ? 1 : 0, S(opts[i].media_id) || null).run();
  }
  return { id };
}

export async function upsertQuiz(actor: string, input: any) {
  const id = S(input.id) || uid();
  const t = now();
  const v = [S(input.title, 160), S(input.description, 1000), S(input.kind, 20) || "lesson",
    S(input.course_id) || null, S(input.level_id) || null, S(input.module_id) || null, S(input.lesson_id) || null,
    N(input.pass_pct, 60), N(input.max_attempts), N(input.time_limit_s), N(input.per_question_s),
    input.sequential === false ? 0 : 1, input.shuffle === false ? 0 : 1,
    input.show_feedback === false ? 0 : 1, st(input.status)];
  const ex = await db().prepare("SELECT id FROM quizzes WHERE id=?").bind(id).first<any>();
  if (ex) {
    await db().prepare(
      `UPDATE quizzes SET title=?,description=?,kind=?,course_id=?,level_id=?,module_id=?,lesson_id=?,pass_pct=?,
       max_attempts=?,time_limit_s=?,per_question_s=?,sequential=?,shuffle=?,show_feedback=?,status=?,updated_at=?
       WHERE id=?`).bind(...v, t, id).run();
  } else {
    await db().prepare(
      `INSERT INTO quizzes (id,title,description,kind,course_id,level_id,module_id,lesson_id,pass_pct,max_attempts,
       time_limit_s,per_question_s,sequential,shuffle,show_feedback,status,created_at,updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(id, ...v, t, t).run();
  }
  if (Array.isArray(input.question_ids)) {
    await db().prepare("DELETE FROM quiz_questions WHERE quiz_id=?").bind(id).run();
    for (let i = 0; i < input.question_ids.length; i++) {
      const qid = S(input.question_ids[i]);
      if (!qid) continue;
      await db().prepare("INSERT INTO quiz_questions (id,quiz_id,question_id,sort,points) VALUES (?,?,?,?,1)")
        .bind(uid(), id, qid, i).run();
    }
  }
  await audit(actor, "CMS_QUIZ_SAVED", { id });
  return { id };
}

const TABLES: Record<string, string> = {
  course: "courses", level: "course_levels", module: "modules",
  lesson: "lessons", block: "lesson_blocks", question: "questions", quiz: "quizzes",
};
export async function setStatus(actor: string, kind: string, id: string, status: string) {
  const table = TABLES[kind];
  if (!table || table === "lesson_blocks") return { error: "bad_kind" as const };
  await db().prepare(`UPDATE ${table} SET status=?, updated_at=? WHERE id=?`).bind(st(status), now(), S(id)).run();
  await audit(actor, "CMS_STATUS", { kind, id, status });
  return { ok: true };
}
export async function reorder(_actor: string, kind: string, ids: string[]) {
  const table = TABLES[kind];
  if (!table) return { error: "bad_kind" as const };
  for (let i = 0; i < ids.length; i++) {
    await db().prepare(`UPDATE ${table} SET sort=? WHERE id=?`).bind(i, S(ids[i])).run();
  }
  return { ok: true };
}
export async function removeBlock(id: string) {
  await db().prepare("DELETE FROM lesson_blocks WHERE id=?").bind(S(id)).run();
  return { ok: true };
}
export async function duplicateLesson(actor: string, lessonId: string) {
  const l = await db().prepare("SELECT * FROM lessons WHERE id=?").bind(S(lessonId)).first<any>();
  if (!l) return { error: "not_found" as const };
  const newId = uid(), t = now();
  await db().prepare(
    `INSERT INTO lessons (id,module_id,course_id,level_id,title,summary,objective,duration_min,sort,status,
     unlock_rule,completion_rule,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,'draft',?,?,?,?)`)
    .bind(newId, l.module_id, l.course_id, l.level_id, l.title + " (copy)", l.summary, l.objective,
      l.duration_min, l.sort + 1, l.unlock_rule, l.completion_rule, t, t).run();
  const blocks = (await db().prepare("SELECT * FROM lesson_blocks WHERE lesson_id=? ORDER BY sort")
    .bind(lessonId).all()).results as any[];
  for (const b of blocks) {
    await db().prepare(
      "INSERT INTO lesson_blocks (id,lesson_id,kind,sort,required,data,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)")
      .bind(uid(), newId, b.kind, b.sort, b.required, b.data, t, t).run();
  }
  await audit(actor, "CMS_LESSON_DUPLICATED", { from: lessonId, to: newId });
  return { id: newId };
}
