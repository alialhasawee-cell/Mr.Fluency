// SERVER ONLY — the learning engine: catalogue, content tree, enrolment,
// progression rules and progress. Every read is scoped to the calling user;
// nothing here trusts an id supplied by the browser without checking access.
import { db } from "./auth.server";
import type { User } from "./auth.server";

const now = () => Date.now();
const uid = () => crypto.randomUUID();
const J = <T,>(s: unknown, fallback: T): T => {
  try { return typeof s === "string" ? (JSON.parse(s) as T) : fallback; } catch { return fallback; }
};

export type CompletionRule = { blocks: boolean; quiz: boolean; minQuizPct: number };
export const defaultRule: CompletionRule = { blocks: true, quiz: false, minQuizPct: 0 };

export async function catalogue(includeDrafts = false) {
  const where = includeDrafts ? "" : "WHERE status='published'";
  const rows = (await db().prepare(
    `SELECT c.*,
      (SELECT COUNT(*) FROM course_levels l WHERE l.course_id=c.id) AS levels,
      (SELECT COUNT(*) FROM modules m WHERE m.course_id=c.id) AS modules,
      (SELECT COUNT(*) FROM lessons s WHERE s.course_id=c.id) AS lessons
     FROM courses c ${where} ORDER BY c.sort, c.title`).all()).results as any[];
  return rows;
}

export async function courseBySlug(slug: string, includeDrafts = false) {
  const c = await db().prepare(
    `SELECT * FROM courses WHERE slug=? ${includeDrafts ? "" : "AND status='published'"}`).bind(slug).first<any>();
  return c ?? null;
}

/** The whole tree for one course. Drafts are included only for staff. */
export async function courseTree(courseId: string, includeDrafts = false) {
  const st = includeDrafts ? "" : " AND status='published'";
  const course = await db().prepare(`SELECT * FROM courses WHERE id=?`).bind(courseId).first<any>();
  if (!course) return null;
  const levels = (await db().prepare(
    `SELECT * FROM course_levels WHERE course_id=?${st} ORDER BY sort`).bind(courseId).all()).results as any[];
  const modules = (await db().prepare(
    `SELECT * FROM modules WHERE course_id=?${st} ORDER BY sort`).bind(courseId).all()).results as any[];
  const lessons = (await db().prepare(
    `SELECT id,module_id,level_id,course_id,title,summary,objective,duration_min,sort,status,unlock_rule,completion_rule
     FROM lessons WHERE course_id=?${st} ORDER BY sort`).bind(courseId).all()).results as any[];
  const quizzes = (await db().prepare(
    `SELECT id,title,kind,module_id,lesson_id,level_id,pass_pct,status FROM quizzes WHERE course_id=?${st}`)
    .bind(courseId).all()).results as any[];
  return {
    course,
    levels: levels.map((l) => ({
      ...l,
      modules: modules.filter((m) => m.level_id === l.id).map((m) => ({
        ...m,
        lessons: lessons.filter((s) => s.module_id === m.id),
        quizzes: quizzes.filter((q) => q.module_id === m.id && !q.lesson_id),
      })),
    })),
    finalExams: quizzes.filter((q) => q.kind === "final_exam"),
  };
}

/** Blocks only staff may see. Filtered HERE, in the query, so a student cannot
 *  reach them by calling the API directly — hiding them in the UI would still
 *  ship them in the response. */
const STAFF_ONLY_BLOCKS = ["teachernotes"];

export async function lessonWithBlocks(lessonId: string, includeDrafts = false) {
  const lesson = await db().prepare(
    `SELECT * FROM lessons WHERE id=?${includeDrafts ? "" : " AND status='published'"}`).bind(lessonId).first<any>();
  if (!lesson) return null;
  const blocks = (await db().prepare(
    `SELECT id,kind,sort,required,data FROM lesson_blocks WHERE lesson_id=? ORDER BY sort`)
    .bind(lessonId).all()).results as any[];
  const quiz = await db().prepare(
    `SELECT id,title,pass_pct,sequential,per_question_s,max_attempts FROM quizzes
     WHERE lesson_id=? AND status='published' LIMIT 1`).bind(lessonId).first<any>();
  return {
    ...lesson,
    completion_rule: J<CompletionRule>(lesson.completion_rule, defaultRule),
    blocks: blocks
      .filter((b) => includeDrafts || !STAFF_ONLY_BLOCKS.includes(String(b.kind)))
      .map((b) => ({ ...b, data: J<Record<string, unknown>>(b.data, {}) })),
    quiz: quiz ?? null,
  };
}

// ---------- enrolment ----------
export async function enrollmentsFor(userId: string) {
  return (await db().prepare(
    `SELECT e.*, c.slug, c.title, c.subtitle, c.color, c.thumbnail_url, c.category
     FROM enrollments e JOIN courses c ON c.id=e.course_id
     WHERE e.user_id=? ORDER BY e.enrolled_at DESC`).bind(userId).all()).results as any[];
}
export async function isEnrolled(userId: string, courseId: string) {
  const r = await db().prepare(
    `SELECT id,status,expires_at FROM enrollments WHERE user_id=? AND course_id=?`)
    .bind(userId, courseId).first<any>();
  if (!r || r.status === "revoked") return false;
  if (r.expires_at && r.expires_at < now()) return false;
  return true;
}
export async function enroll(userId: string, courseId: string, opts?: { levelId?: string; source?: string; expiresAt?: number }) {
  const course = await db().prepare("SELECT id,status,access FROM courses WHERE id=?").bind(courseId).first<any>();
  if (!course) return { error: "not_found" as const };
  if (course.status !== "published") return { error: "not_available" as const };
  if (course.access !== "open" && (opts?.source ?? "self") === "self") return { error: "invite_only" as const };
  const existing = await db().prepare("SELECT id FROM enrollments WHERE user_id=? AND course_id=?")
    .bind(userId, courseId).first<{ id: string }>();
  if (existing) {
    await db().prepare("UPDATE enrollments SET status='active', level_id=COALESCE(?,level_id) WHERE id=?")
      .bind(opts?.levelId ?? null, existing.id).run();
    return { enrollmentId: existing.id, already: true };
  }
  const id = uid();
  await db().prepare(
    `INSERT INTO enrollments (id,user_id,course_id,level_id,status,source,enrolled_at,expires_at,progress_pct)
     VALUES (?,?,?,?,'active',?,?,?,0)`)
    .bind(id, userId, courseId, opts?.levelId ?? null, opts?.source ?? "self", now(), opts?.expiresAt ?? null).run();
  await notify(userId, "enrolment", "You are enrolled", "Your course is ready to start.", "/dashboard");
  return { enrollmentId: id };
}

// ---------- progression rules ----------
export const CEFR_ORDER = ["A1", "A2", "B1", "B2", "C1"];
/** The student's placement level from their latest completed placement test (matched by email), or null. */
export async function placedLevel(userId: string): Promise<string | null> {
  const u = await db().prepare("SELECT email FROM users WHERE id=?").bind(userId).first<{ email: string }>();
  if (!u?.email) return null;
  const row = await db().prepare(
    "SELECT result FROM attempts WHERE ckey=? AND status='COMPLETED' AND result IS NOT NULL ORDER BY completed_at DESC LIMIT 1")
    .bind("e:" + String(u.email).trim().toLowerCase()).first<{ result: string }>().catch(() => null);
  if (!row?.result) return null;
  let lvl = "";
  try { lvl = String(JSON.parse(row.result)?.level ?? ""); } catch { return null; }
  if (lvl === "A0" || !lvl) return "A1";
  if (lvl === "C2") return "C1";
  return CEFR_ORDER.includes(lvl) ? lvl : "A1";
}

/**
 * Which lessons this user may open, with the reason when locked.
 * Rules: nothing opens before the placement test. The placed level and every
 * level below it are open; a higher level opens once the final exam of the
 * level before it is passed (the first level of any course is always open once
 * placed). Inside a level, chapters open in order.
 */
export async function accessMap(userId: string, courseId: string) {
  const tree = await courseTree(courseId, false);
  if (!tree) return null;
  const prog = (await db().prepare(
    `SELECT lesson_id,status FROM progress WHERE user_id=? AND course_id=?`)
    .bind(userId, courseId).all()).results as any[];
  const done = new Set(prog.filter((p) => p.status === "completed").map((p) => p.lesson_id));
  const quizBest = (await db().prepare(
    `SELECT quiz_id, MAX(pct) AS best FROM quiz_attempts WHERE user_id=? AND status='COMPLETED' GROUP BY quiz_id`)
    .bind(userId).all()).results as any[];
  const best = new Map(quizBest.map((q) => [q.quiz_id, q.best as number]));
  const placed = await placedLevel(userId);
  const pIdx = placed ? CEFR_ORDER.indexOf(placed) : -1;

  const map: Record<string, { open: boolean; reason?: string }> = {};
  const levels: Record<string, { open: boolean; reason?: string; finalPassed: boolean }> = {};
  let prevFinalPassed = false;

  for (const [lvIndex, lvl] of tree.levels.entries()) {
    const li = CEFR_ORDER.indexOf(lvl.cefr);
    let levelOpen = true, levelReason = "";
    if (!placed) { levelOpen = false; levelReason = "Take the placement test first."; }
    else if (lvIndex > 0 && li > pIdx && !prevFinalPassed) {
      levelOpen = false;
      levelReason = `Pass the ${CEFR_ORDER[li - 1] ?? "previous"} final exam to open ${lvl.cefr}.`;
    }
    let prevLesson: string | null = null;
    let prevModule: { id: string; lessons: string[]; quizId?: string } | null = null;
    let finalQuiz: any = null;
    for (const mod of lvl.modules) {
      for (const q of mod.quizzes ?? []) if (q.kind === "final_exam") finalQuiz = q;
      let moduleOpen = levelOpen, moduleReason = levelReason;
      if (moduleOpen && mod.unlock_rule !== "none" && prevModule) {
        const allDone = prevModule.lessons.every((id) => done.has(id));
        if (!allDone) { moduleOpen = false; moduleReason = "Finish the previous chapter first."; }
        else if (mod.unlock_rule === "min_score" && prevModule.quizId) {
          const bq = best.get(prevModule.quizId) ?? -1;
          if (bq < mod.min_score) { moduleOpen = false; moduleReason = `Score at least ${mod.min_score}% on the previous chapter test.`; }
        }
      }
      for (const les of mod.lessons) {
        let open = moduleOpen, reason = moduleReason;
        if (open && les.unlock_rule === "previous_lesson" && prevLesson && !done.has(prevLesson)) {
          open = false; reason = "Complete the previous lesson first.";
        }
        map[les.id] = open ? { open: true } : { open: false, reason };
        prevLesson = les.id;
      }
      if (mod.lessons.length) prevModule = { id: mod.id, lessons: mod.lessons.map((l: any) => l.id), quizId: mod.quizzes?.[0]?.id };
    }
    const finalPassed = !!finalQuiz && (best.get(finalQuiz.id) ?? -1) >= (finalQuiz.pass_pct ?? 60);
    levels[lvl.id] = levelOpen ? { open: true, finalPassed } : { open: false, reason: levelReason, finalPassed };
    prevFinalPassed = finalPassed;
  }
  return { tree, map, levels, placed, done: Array.from(done) };
}

export async function canOpenLesson(userId: string, lessonId: string, isStaff = false) {
  const lesson = await db().prepare("SELECT id,course_id,status FROM lessons WHERE id=?").bind(lessonId).first<any>();
  if (!lesson || (lesson.status !== "published" && !isStaff)) return { ok: false as const, reason: "not_found" };
  // Staff run the course; they read any lesson without enrolling on it, which
  // is how a teacher opens the lesson (and its notes) before a class.
  if (isStaff) return { ok: true as const, courseId: lesson.course_id };
  if (!(await isEnrolled(userId, lesson.course_id))) return { ok: false as const, reason: "not_enrolled" };
  const am = await accessMap(userId, lesson.course_id);
  const entry = am?.map[lessonId];
  if (!entry?.open) return { ok: false as const, reason: entry?.reason ?? "locked" };
  return { ok: true as const, courseId: lesson.course_id };
}

// ---------- progress ----------
export async function startLesson(userId: string, lessonId: string) {
  const gate = await canOpenLesson(userId, lessonId);
  if (!gate.ok) return { error: gate.reason };
  const lesson = await db().prepare("SELECT id,course_id,module_id FROM lessons WHERE id=?").bind(lessonId).first<any>();
  const existing = await db().prepare("SELECT * FROM progress WHERE user_id=? AND lesson_id=?")
    .bind(userId, lessonId).first<any>();
  if (!existing) {
    await db().prepare(
      `INSERT INTO progress (id,user_id,lesson_id,course_id,module_id,status,checks,seconds,started_at,updated_at)
       VALUES (?,?,?,?,?, 'started','{}',0,?,?)`)
      .bind(uid(), userId, lessonId, lesson.course_id, lesson.module_id, now(), now()).run();
  }
  await db().prepare("UPDATE enrollments SET last_lesson_id=? WHERE user_id=? AND course_id=?")
    .bind(lessonId, userId, lesson.course_id).run();
  return { ok: true };
}

/** Record a completion requirement being met (a video watched, an activity done…). */
export async function checkOff(userId: string, lessonId: string, key: string, seconds = 0) {
  const row = await db().prepare("SELECT * FROM progress WHERE user_id=? AND lesson_id=?")
    .bind(userId, lessonId).first<any>();
  if (!row) return { error: "not_started" as const };
  const checks = J<Record<string, boolean>>(row.checks, {});
  checks[String(key).slice(0, 60)] = true;
  await db().prepare("UPDATE progress SET checks=?, seconds=seconds+?, updated_at=? WHERE id=?")
    .bind(JSON.stringify(checks), Math.max(0, Math.min(3600, seconds)), now(), row.id).run();
  return { ok: true, checks };
}

/** A lesson is complete only when its OWN rule is satisfied — never on page open. */
export async function tryCompleteLesson(userId: string, lessonId: string) {
  const lesson = await lessonWithBlocks(lessonId, false);
  if (!lesson) return { error: "not_found" as const };
  const row = await db().prepare("SELECT * FROM progress WHERE user_id=? AND lesson_id=?")
    .bind(userId, lessonId).first<any>();
  if (!row) return { error: "not_started" as const };
  const checks = J<Record<string, boolean>>(row.checks, {});
  const rule = lesson.completion_rule;
  const required = lesson.blocks.filter((b: any) => b.required === 1);
  const missing: string[] = [];

  if (rule.blocks) for (const b of required) if (!checks["block:" + b.id]) missing.push(b.kind);
  if (rule.quiz && lesson.quiz) {
    const best = await db().prepare(
      `SELECT MAX(pct) AS best FROM quiz_attempts WHERE user_id=? AND quiz_id=? AND status='COMPLETED'`)
      .bind(userId, lesson.quiz.id).first<{ best: number | null }>();
    if ((best?.best ?? -1) < (rule.minQuizPct || lesson.quiz.pass_pct || 0)) missing.push("quiz");
  }
  if (missing.length) return { completed: false as const, missing };
  if (row.status !== "completed") {
    await db().prepare("UPDATE progress SET status='completed', completed_at=?, updated_at=? WHERE id=?")
      .bind(now(), now(), row.id).run();
    await awardXp(userId, 25);
    await recomputeCourseProgress(userId, lesson.course_id);
  }
  return { completed: true as const };
}

export async function recomputeCourseProgress(userId: string, courseId: string) {
  // Only lessons a student can actually reach count: a lesson whose module or
  // level has been retired must not sit in the denominator for ever.
  const total = await db().prepare(
    `SELECT COUNT(*) AS n FROM lessons l
       JOIN modules m ON m.id = l.module_id
       JOIN course_levels v ON v.id = m.level_id
     WHERE l.course_id=? AND l.status='published'
       AND m.status='published' AND v.status='published'`)
    .bind(courseId).first<{ n: number }>();
  const done = await db().prepare(
    `SELECT COUNT(*) AS n FROM progress p
       JOIN lessons l ON l.id = p.lesson_id
       JOIN modules m ON m.id = l.module_id
       JOIN course_levels v ON v.id = m.level_id
     WHERE p.user_id=? AND p.course_id=? AND p.status='completed'
       AND l.status='published' AND m.status='published' AND v.status='published'`)
    .bind(userId, courseId).first<{ n: number }>();
  const pct = total?.n ? Math.round(((done?.n ?? 0) / total.n) * 100) : 0;
  const complete = pct >= 100 && (total?.n ?? 0) > 0;
  await db().prepare(
    `UPDATE enrollments SET progress_pct=?, status=CASE WHEN ? THEN 'completed' ELSE status END,
     completed_at=CASE WHEN ? THEN ? ELSE completed_at END WHERE user_id=? AND course_id=?`)
    .bind(pct, complete ? 1 : 0, complete ? 1 : 0, now(), userId, courseId).run();
  return { pct, complete };
}

export async function progressFor(userId: string, courseId: string) {
  return (await db().prepare(
    `SELECT lesson_id,status,checks,completed_at FROM progress WHERE user_id=? AND course_id=?`)
    .bind(userId, courseId).all()).results as any[];
}

// ---------- gamification + notifications (schema-backed, minimal rules) ----------
export async function awardXp(userId: string, xp: number) {
  await db().prepare("UPDATE users SET xp = xp + ?, last_active=?, updated_at=? WHERE id=?")
    .bind(Math.max(0, xp), now(), now(), userId).run();
}
export async function notify(userId: string, kind: string, title: string, body?: string, link?: string) {
  await db().prepare(
    `INSERT INTO notifications (id,user_id,kind,title,body,link,created_at) VALUES (?,?,?,?,?,?,?)`)
    .bind(uid(), userId, kind, title.slice(0, 120), (body ?? "").slice(0, 400), link ?? null, now()).run();
}
export async function notificationsFor(userId: string) {
  return (await db().prepare(
    `SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 30`).bind(userId).all()).results as any[];
}

export async function dashboardFor(user: User) {
  const courses = await enrollmentsFor(user.id);
  const lessonsDone = await db().prepare("SELECT COUNT(*) AS n FROM progress WHERE user_id=? AND status='completed'")
    .bind(user.id).first<{ n: number }>();
  const quizzes = (await db().prepare(
    `SELECT qa.pct, qa.passed, qa.submitted_at, q.title FROM quiz_attempts qa JOIN quizzes q ON q.id=qa.quiz_id
     WHERE qa.user_id=? AND qa.status='COMPLETED' ORDER BY qa.submitted_at DESC LIMIT 8`)
    .bind(user.id).all()).results as any[];
  const certs = (await db().prepare(
    `SELECT code,course_title,cefr,score_pct,issued_at FROM certificates WHERE user_id=? AND revoked=0
     ORDER BY issued_at DESC`).bind(user.id).all()).results as any[];
  const placement = await db().prepare(
    `SELECT result, completed_at, attempt_no FROM attempts
     WHERE (user_id=? OR email=?) AND status='COMPLETED' ORDER BY completed_at DESC LIMIT 1`)
    .bind(user.id, user.email).first<any>();
  let resume: any = null;
  for (const c of courses) {
    if (c.last_lesson_id) {
      const l = await db().prepare("SELECT id,title,module_id FROM lessons WHERE id=?").bind(c.last_lesson_id).first<any>();
      if (l) { resume = { ...l, courseTitle: c.title, courseId: c.course_id, slug: c.slug }; break; }
    }
  }
  if (!resume && courses.length) {
    const am = await accessMap(user.id, courses[0].course_id);
    const first = am?.tree.levels.flatMap((l: any) => l.modules).flatMap((m: any) => m.lessons)
      .find((l: any) => am.map[l.id]?.open);
    if (first) resume = { ...first, courseTitle: courses[0].title, courseId: courses[0].course_id, slug: courses[0].slug };
  }
  const fresh = await db().prepare("SELECT xp, streak_days, cefr_level FROM users WHERE id=?")
    .bind(user.id).first<{ xp: number; streak_days: number; cefr_level: string | null }>();
  const badges = (await db().prepare(
    `SELECT a.code, a.title, a.description, a.icon, sa.earned_at
     FROM student_achievements sa JOIN achievements a ON a.id = sa.achievement_id
     WHERE sa.user_id=? ORDER BY sa.earned_at DESC`).bind(user.id).all()).results as any[];
  return {
    courses, resume, certificates: certs, quizzes,
    lessonsCompleted: lessonsDone?.n ?? 0,
    xp: fresh?.xp ?? 0,
    streakDays: fresh?.streak_days ?? 0,
    cefrLevel: fresh?.cefr_level ?? null,
    achievements: badges,
    placement: placement?.result ? JSON.parse(placement.result) : null,
    notifications: await notificationsFor(user.id),
  };
}
