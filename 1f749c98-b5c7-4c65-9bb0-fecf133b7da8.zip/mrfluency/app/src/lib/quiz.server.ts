// SERVER ONLY — the reusable assessment engine.
// Shares the placement guarantees: the server owns the order, the clock and the
// key. A correct answer key never leaves this file, and when a quiz is marked
// `sequential` the cursor advances by exactly one position per accepted answer.
import { db } from "./auth.server";
import { canOpenLesson, isEnrolled, placedLevel } from "./lms.server";

const now = () => Date.now();
const uid = () => crypto.randomUUID();
const J = <T,>(s: unknown, f: T): T => { try { return typeof s === "string" ? JSON.parse(s) as T : f; } catch { return f; } };
const norm = (s: unknown) => String(s ?? "").trim().toLowerCase().replace(/\s+/g, " ");
export const GRACE_MS = 2500;

export type QType = "mcq" | "multi" | "truefalse" | "gap" | "match" | "order" | "writing" | "speaking";
const MANUAL: QType[] = ["writing", "speaking"];

async function loadQuestion(id: string) {
  const q = await db().prepare("SELECT * FROM questions WHERE id=?").bind(id).first<any>();
  if (!q) return null;
  const opts = (await db().prepare(
    "SELECT id,sort,text,is_correct,media_id FROM question_options WHERE question_id=? ORDER BY sort")
    .bind(id).all()).results as any[];
  return { ...q, data: J<Record<string, any>>(q.data, {}), options: opts };
}
/** Exactly what a browser is allowed to see. No is_correct, no answers. */
function publicQuestion(q: any) {
  const d = q.data ?? {};
  const safe: Record<string, unknown> = {};
  if (q.type === "gap") safe.gaps = Array.isArray(d.answers) ? d.answers.length : 1;
  if (q.type === "match") safe.left = ((d.left ?? []) as any[]).map((v) => String(v));
  if (q.type === "match") safe.right = shuffle((d.pairs ?? []).map((p: any) => String(p.right)));
  if (q.type === "order") safe.items = shuffle(((d.items ?? []) as any[]).map((v) => String(v)));
  if (q.type === "writing" || q.type === "speaking") safe.minWords = d.minWords ?? 0;
  return {
    id: q.id, type: q.type as QType, prompt: q.prompt, passage: q.passage ?? null,
    skill: q.skill, cefr: q.cefr, points: q.points, mediaId: q.media_id ?? null,
    options: q.options.map((o: any) => ({ id: o.id, text: o.text, mediaId: o.media_id ?? null })),
    ...safe,
  };
}
function shuffle<T>(a: T[]): T[] {
  const x = a.slice();
  for (let i = x.length - 1; i > 0; i--) {
    const j = crypto.getRandomValues(new Uint32Array(1))[0] % (i + 1);
    [x[i], x[j]] = [x[j], x[i]];
  }
  return x;
}

/** Marking. Returns points earned and whether a human must review it. */
export function grade(q: any, response: any): { correct: boolean; points: number; manual: boolean } {
  const type = q.type as QType;
  const pts = q.points ?? 1;
  if (MANUAL.includes(type)) return { correct: false, points: 0, manual: true };
  switch (type) {
    case "mcq":
    case "truefalse": {
      const opt = q.options.find((o: any) => o.id === response);
      const ok = !!opt && opt.is_correct === 1;
      return { correct: ok, points: ok ? pts : 0, manual: false };
    }
    case "multi": {
      const picked = new Set<string>(Array.isArray(response) ? response.map((r: unknown) => String(r)) : []);
      const right = new Set<string>(q.options.filter((o: any) => o.is_correct === 1).map((o: any) => String(o.id)));
      const ok = picked.size === right.size && Array.from(right).every((id) => picked.has(id));
      return { correct: ok, points: ok ? pts : 0, manual: false };
    }
    case "gap": {
      const answers: string[][] = (q.data.answers ?? []).map((a: any) => Array.isArray(a) ? a : [a]);
      const given = Array.isArray(response) ? response : [response];
      let hit = 0;
      answers.forEach((alts, i) => { if (alts.some((a) => norm(a) === norm(given[i]))) hit++; });
      const ok = hit === answers.length && answers.length > 0;
      return { correct: ok, points: Math.round((hit / Math.max(1, answers.length)) * pts), manual: false };
    }
    case "match": {
      const pairs: { left: string; right: string }[] = q.data.pairs ?? [];
      const given = (response ?? {}) as Record<string, string>;
      let hit = 0;
      pairs.forEach((p) => { if (norm(given[p.left]) === norm(p.right)) hit++; });
      const ok = hit === pairs.length && pairs.length > 0;
      return { correct: ok, points: Math.round((hit / Math.max(1, pairs.length)) * pts), manual: false };
    }
    case "order": {
      const right: string[] = q.data.order ?? [];
      const given = Array.isArray(response) ? response.map(String) : [];
      const ok = right.length > 0 && given.length === right.length && right.every((v, i) => norm(v) === norm(given[i]));
      return { correct: ok, points: ok ? pts : 0, manual: false };
    }
    default:
      return { correct: false, points: 0, manual: false };
  }
}

export async function quizMeta(quizId: string) {
  return db().prepare("SELECT * FROM quizzes WHERE id=?").bind(quizId).first<any>();
}
async function questionIdsFor(quizId: string) {
  const rows = (await db().prepare(
    "SELECT question_id,sort FROM quiz_questions WHERE quiz_id=? ORDER BY sort").bind(quizId).all()).results as any[];
  return rows.map((r) => r.question_id as string);
}

/** A lesson quiz opens with its lesson; a chapter test once that chapter's lessons are
 *  done; a level final exam once every lesson in the level is done. Staff skip this. */
async function quizLock(userId: string, quiz: any): Promise<string | null> {
  if (!(await placedLevel(userId))) return "Take the placement test first.";
  if (quiz.lesson_id) {
    const g = await canOpenLesson(userId, quiz.lesson_id);
    return g.ok ? null : (g.reason === "not_enrolled" ? "Enrol on the course first." : g.reason === "not_found" ? "This lesson is not available." : String(g.reason));
  }
  if (!quiz.module_id || !quiz.course_id) return null;
  if (!(await isEnrolled(userId, quiz.course_id))) return "Enrol on the course first.";
  const byLevel = quiz.kind === "final_exam" && quiz.level_id;
  const rows = (await db().prepare(
    `SELECT l.id FROM lessons l JOIN modules m ON m.id=l.module_id
     WHERE ${byLevel ? "l.level_id" : "l.module_id"}=? AND l.status='published' AND m.status='published'
       AND l.id NOT IN (SELECT lesson_id FROM progress WHERE user_id=? AND status='completed')`)
    .bind(byLevel ? quiz.level_id : quiz.module_id, userId).all()).results as any[];
  return rows.length ? (byLevel ? "Finish every lesson in this level first." : "Finish this chapter's lessons first.") : null;
}

export async function startQuiz(userId: string, quizId: string, isStaff = false) {
  const quiz = await quizMeta(quizId);
  if (!quiz || quiz.status !== "published") return { error: "not_found" as const };
  if (!isStaff) {
    const lock = await quizLock(userId, quiz);
    if (lock) return { error: "locked" as const, reason: lock };
  }

  const open = await db().prepare(
    `SELECT * FROM quiz_attempts WHERE user_id=? AND quiz_id=? AND status IN ('IN_PROGRESS','PAUSED')
     ORDER BY updated_at DESC LIMIT 1`).bind(userId, quizId).first<any>();
  if (open) return { attemptId: open.id, resumed: true };

  const used = await db().prepare(
    `SELECT COUNT(*) AS n FROM quiz_attempts WHERE user_id=? AND quiz_id=? AND status IN ('COMPLETED','EXPIRED')`)
    .bind(userId, quizId).first<{ n: number }>();
  if (quiz.max_attempts > 0 && (used?.n ?? 0) >= quiz.max_attempts) return { error: "no_attempts" as const };

  let ids = await questionIdsFor(quizId);
  if (!ids.length) return { error: "empty_quiz" as const };
  if (quiz.shuffle === 1) ids = shuffle(ids);

  const id = uid(), t = now();
  const deadline = quiz.per_question_s > 0 ? t + quiz.per_question_s * 1000 : null;
  await db().prepare(
    `INSERT INTO quiz_attempts (id,quiz_id,user_id,attempt_no,status,order_json,cursor,q_started_at,q_deadline,
      score,max_score,pct,passed,started_at,updated_at)
     VALUES (?,?,?,?,'IN_PROGRESS',?,0,?,?,0,0,0,0,?,?)`)
    .bind(id, quizId, userId, (used?.n ?? 0) + 1, JSON.stringify(ids), t, deadline, t, t).run();
  return { attemptId: id, resumed: false };
}

export async function quizState(userId: string, attemptId: string) {
  let a = await db().prepare("SELECT * FROM quiz_attempts WHERE id=? AND user_id=?")
    .bind(attemptId, userId).first<any>();
  if (!a) return { error: "not_found" as const };
  const quiz = await quizMeta(a.quiz_id);
  if (a.status === "IN_PROGRESS") { await reconcile(a, quiz); a = await db().prepare("SELECT * FROM quiz_attempts WHERE id=?").bind(attemptId).first<any>(); }
  const ids: string[] = J(a.order_json, []);
  const base = {
    attemptId: a.id, quizId: a.quiz_id, title: quiz.title, status: a.status,
    attemptNo: a.attempt_no, index: a.cursor, total: ids.length, serverNow: now(),
    sequential: quiz.sequential === 1, passPct: quiz.pass_pct, pauseCount: a.pause_count,
  };
  if (a.status === "COMPLETED" || a.status === "EXPIRED") {
    return { ...base, score: a.score, maxScore: a.max_score, pct: a.pct, passed: a.passed === 1,
      review: await reviewOf(a.id, quiz.show_feedback === 1) };
  }
  const q = await loadQuestion(ids[a.cursor]);
  if (!q) return { ...base };
  return {
    ...base,
    question: publicQuestion(q),
    secondsAllowed: quiz.per_question_s || 0,
    deadlineAt: a.status === "PAUSED" ? null : a.q_deadline,
    remainingMs: a.status === "PAUSED" ? a.remaining_ms : (a.q_deadline ? Math.max(0, a.q_deadline - now()) : null),
  };
}

async function reconcile(a: any, quiz: any) {
  let guard = 0;
  while (a.status === "IN_PROGRESS" && a.q_deadline && now() > a.q_deadline + GRACE_MS && guard++ < 200) {
    await record(a, null, true);
    if (!(await advance(a, quiz))) break;
    a = await db().prepare("SELECT * FROM quiz_attempts WHERE id=?").bind(a.id).first<any>();
  }
}
async function record(a: any, response: any, timedOut: boolean) {
  const ids: string[] = J(a.order_json, []);
  const q = await loadQuestion(ids[a.cursor]);
  if (!q) return { points: 0 };
  const g = timedOut ? { correct: false, points: 0, manual: false } : grade(q, response);
  await db().prepare(
    `INSERT INTO quiz_answers (id,attempt_id,question_id,response,correct,points,status,answered_at)
     VALUES (?,?,?,?,?,?,?,?)`)
    .bind(uid(), a.id, q.id, timedOut ? null : JSON.stringify(response ?? null),
      g.correct ? 1 : 0, g.points, timedOut ? "TIMED_OUT" : (g.manual ? "PENDING_REVIEW" : "ANSWERED"), now()).run();
  return g;
}
async function advance(a: any, quiz: any) {
  const ids: string[] = J(a.order_json, []);
  if (a.cursor < ids.length - 1) {
    const nextQ = await loadQuestion(ids[a.cursor + 1]);
    const t = now();
    const deadline = quiz.per_question_s > 0 ? t + quiz.per_question_s * 1000 : null;
    await db().prepare(
      "UPDATE quiz_attempts SET cursor=?, q_started_at=?, q_deadline=?, remaining_ms=NULL, updated_at=? WHERE id=?")
      .bind(a.cursor + 1, t, deadline, t, a.id).run();
    a.cursor += 1; a.q_deadline = deadline;
    void nextQ;
    return true;
  }
  await finish(a.id);
  return false;
}

export async function answerQuiz(userId: string, attemptId: string, questionId: string, response: any) {
  let a = await db().prepare("SELECT * FROM quiz_attempts WHERE id=? AND user_id=?").bind(attemptId, userId).first<any>();
  if (!a) return { error: "not_found" as const };
  if (a.status !== "IN_PROGRESS") return { error: "not_active" as const };
  const quiz = await quizMeta(a.quiz_id);
  await reconcile(a, quiz);
  a = await db().prepare("SELECT * FROM quiz_attempts WHERE id=?").bind(attemptId).first<any>();
  if (a.status !== "IN_PROGRESS") return { ok: true, timedOut: true };

  const ids: string[] = J(a.order_json, []);
  const expected = ids[a.cursor];
  // Sequential quizzes refuse anything but the current question (spec 13 / 17).
  if (quiz.sequential === 1 && questionId !== expected) {
    return { error: "wrong_question" as const, expected };
  }
  const expired = !!a.q_deadline && now() > a.q_deadline + GRACE_MS;
  if (expired) { await record(a, null, true); await advance(a, quiz); return { ok: true, timedOut: true }; }

  const q = await loadQuestion(expected);
  if (!q) return { error: "not_found" as const };
  if (quiz.sequential === 1 && !MANUAL.includes(q.type as QType) && isEmpty(response)) {
    return { error: "answer_required" as const };
  }
  await record(a, response, false);
  await advance(a, quiz);
  return { ok: true };
}
function isEmpty(r: any) {
  if (r === null || r === undefined || r === "") return true;
  if (Array.isArray(r)) return r.length === 0 || r.every((x) => x === "" || x === null);
  if (typeof r === "object") return Object.keys(r).length === 0;
  return false;
}

export async function pauseQuiz(userId: string, attemptId: string) {
  const a = await db().prepare("SELECT * FROM quiz_attempts WHERE id=? AND user_id=?").bind(attemptId, userId).first<any>();
  if (!a || a.status !== "IN_PROGRESS") return { error: "not_active" as const };
  await db().prepare(
    "UPDATE quiz_attempts SET status='PAUSED', remaining_ms=?, paused_at=?, pause_count=pause_count+1, updated_at=? WHERE id=?")
    .bind(a.q_deadline ? Math.max(0, a.q_deadline - now()) : null, now(), now(), a.id).run();
  return { ok: true };
}
export async function resumeQuiz(userId: string, attemptId: string) {
  const a = await db().prepare("SELECT * FROM quiz_attempts WHERE id=? AND user_id=?").bind(attemptId, userId).first<any>();
  if (!a) return { error: "not_found" as const };
  if (a.status !== "PAUSED") return { ok: true };
  const away = a.paused_at ? Math.max(0, now() - a.paused_at) : 0;
  await db().prepare(
    `UPDATE quiz_attempts SET status='IN_PROGRESS', total_paused_ms=total_paused_ms+?, paused_at=NULL,
     q_started_at=?, q_deadline=?, remaining_ms=NULL, updated_at=? WHERE id=?`)
    .bind(away, now(), a.remaining_ms != null ? now() + a.remaining_ms : null, now(), a.id).run();
  return { ok: true };
}

export async function finish(attemptId: string) {
  const a = await db().prepare("SELECT * FROM quiz_attempts WHERE id=?").bind(attemptId).first<any>();
  if (!a || a.status === "COMPLETED") return;
  const quiz = await quizMeta(a.quiz_id);
  const ids: string[] = J(a.order_json, []);
  const rows = (await db().prepare("SELECT question_id,points FROM quiz_answers WHERE attempt_id=?")
    .bind(attemptId).all()).results as any[];
  let max = 0;
  for (const id of ids) {
    const q = await db().prepare("SELECT points FROM questions WHERE id=?").bind(id).first<{ points: number }>();
    max += q?.points ?? 1;
  }
  const score = rows.reduce((s, r) => s + (r.points ?? 0), 0);
  const pct = max ? Math.round((score / max) * 100) : 0;
  const passed = pct >= (quiz?.pass_pct ?? 60);
  await db().prepare(
    `UPDATE quiz_attempts SET status='COMPLETED', score=?, max_score=?, pct=?, passed=?, submitted_at=?, updated_at=?
     WHERE id=?`).bind(score, max, pct, passed ? 1 : 0, now(), now(), attemptId).run();
  await db().prepare("UPDATE users SET xp = xp + ?, updated_at=? WHERE id=?")
    .bind(passed ? 40 : 10, now(), a.user_id).run();
}

async function reviewOf(attemptId: string, showFeedback: boolean) {
  const rows = (await db().prepare(
    `SELECT qa.question_id, qa.correct, qa.points, qa.status, q.prompt, q.skill, q.cefr, q.explanation
     FROM quiz_answers qa JOIN questions q ON q.id=qa.question_id WHERE qa.attempt_id=? ORDER BY qa.answered_at`)
    .bind(attemptId).all()).results as any[];
  return rows.map((r) => ({
    prompt: r.prompt, skill: r.skill, cefr: r.cefr,
    correct: r.correct === 1, points: r.points, status: r.status,
    explanation: showFeedback ? r.explanation : null,
  }));
}
export async function bestPct(userId: string, quizId: string) {
  const r = await db().prepare(
    "SELECT MAX(pct) AS best FROM quiz_attempts WHERE user_id=? AND quiz_id=? AND status='COMPLETED'")
    .bind(userId, quizId).first<{ best: number | null }>();
  return r?.best ?? null;
}
