export type Course = {
  id: string; name: string; tag: string; goal: string; aim: string;
  levels: string[]; color: string; outcomes: string[];
  modules: { code: string; title: string; level: string; hours: number; focus: string }[];
  bands?: { cefr: string; band: string }[];
};
export const GOALS = [
  { id: "general", label: "General English" },
  { id: "business", label: "Business English" },
  { id: "writing", label: "Email / Business Writing" },
  { id: "ielts", label: "IELTS preparation" },
];
export const LEVEL_INFO: Record<string, { name: string; blurb: string; can: string; hours: string }> = {
  A0: { name: "Absolute Beginner", blurb: "Little or no functional English. Starts from the alphabet, sounds and survival phrases.", can: "Recognise a few words and very simple phrases.", hours: "0-80 guided hours to reach A1" },
  A1: { name: "Beginner", blurb: "Handles very basic everyday exchanges with simple, memorised language.", can: "Introduce yourself, ask and answer simple personal questions.", hours: "80-100 guided hours to reach A2" },
  A2: { name: "Elementary", blurb: "Copes with routine tasks and simple descriptions of familiar matters.", can: "Describe your background, immediate environment and immediate needs.", hours: "150-200 guided hours to reach B1" },
  B1: { name: "Intermediate", blurb: "Independent in familiar situations; can explain opinions and plans.", can: "Deal with most situations while travelling; write connected text on familiar topics.", hours: "300-400 guided hours to reach B2" },
  B2: { name: "Upper-Intermediate", blurb: "Fluent and spontaneous enough for regular interaction with native speakers.", can: "Argue a viewpoint and follow technical discussion in your own field.", hours: "500-600 guided hours to reach C1" },
  C1: { name: "Advanced", blurb: "Flexible and effective use of language for social, academic and professional purposes.", can: "Produce clear, well-structured text on complex subjects; use language fluently.", hours: "700-800 guided hours to reach C2" },
  C2: { name: "Proficient", blurb: "Effortless command, with precise shades of meaning even in complex situations.", can: "Summarise information from many sources and express yourself with precision.", hours: "Maintenance and specialisation" },
};
export const COURSES: Course[] = [
  { id: "gen", name: "General English", tag: "Core skills programme", goal: "general", color: "var(--l-b1)",
    levels: ["A0","A1","A2","B1","B2","C1","C2"],
    aim: "Build the four skills from the ground up, level by level, following the CEFR ladder.",
    outcomes: ["Speak confidently in everyday and study situations","Write connected text with accurate tense control","Understand extended speech and authentic reading"],
    modules: [
      { code: "GE-01", title: "Sounds, Alphabet & Survival Phrases", level: "A0", hours: 12, focus: "Phonics, greetings, numbers, classroom language" },
      { code: "GE-02", title: "Everyday Present", level: "A1", hours: 16, focus: "to be, present simple, articles, basic questions" },
      { code: "GE-03", title: "Talking About the Past", level: "A2", hours: 18, focus: "Past simple, past continuous, comparatives, quantifiers" },
      { code: "GE-04", title: "Plans, Conditions & Experience", level: "A2", hours: 18, focus: "Future forms, first conditional, present perfect" },
      { code: "GE-05", title: "Independent Speaker", level: "B1", hours: 22, focus: "Narrative tenses, reported speech, passive, phrasal verbs" },
      { code: "GE-06", title: "Opinion & Argument", level: "B1", hours: 22, focus: "Modals of deduction, relative clauses, discourse markers" },
      { code: "GE-07", title: "Fluency & Range", level: "B2", hours: 26, focus: "Perfect aspect, conditionals 2-3, collocation building" },
      { code: "GE-08", title: "Precision & Register", level: "C1", hours: 28, focus: "Inversion, cleft sentences, hedging, idiom" },
      { code: "GE-09", title: "Mastery Workshop", level: "C2", hours: 24, focus: "Nuance, connotation, style-shifting, extended discourse" }]},
  { id: "biz", name: "Business English", tag: "Workplace communication", goal: "business", color: "var(--l-b2)",
    levels: ["A2","B1","B2","C1"],
    aim: "Function professionally in meetings, calls, presentations and negotiations.",
    outcomes: ["Chair and contribute to meetings in English","Present data and recommendations clearly","Negotiate and disagree without damaging the relationship"],
    modules: [
      { code: "BE-01", title: "Workplace Foundations", level: "A2", hours: 14, focus: "Job roles, routines, telephone basics, simple requests" },
      { code: "BE-02", title: "Meetings & Participation", level: "B1", hours: 18, focus: "Agendas, interrupting politely, agreeing, action points" },
      { code: "BE-03", title: "Presenting with Structure", level: "B1", hours: 18, focus: "Signposting, describing trends, handling questions" },
      { code: "BE-04", title: "Negotiation Language", level: "B2", hours: 20, focus: "Conditional bargaining, diplomatic distance, concessions" },
      { code: "BE-05", title: "Reports & Data Commentary", level: "B2", hours: 20, focus: "Passive reporting, cause and effect, formal linking" },
      { code: "BE-06", title: "Influence & Stakeholders", level: "C1", hours: 22, focus: "Persuasion, hedging, cross-cultural register, executive summary" }]},
  { id: "email", name: "Email & Business Writing", tag: "Written correspondence", goal: "writing", color: "var(--l-c1)",
    levels: ["A2","B1","B2","C1"],
    aim: "Write clear, correctly pitched professional emails and documents, first time.",
    outcomes: ["Pitch tone correctly for any recipient","Handle complaints and refusals without offence","Write half the words and say twice as much"],
    modules: [
      { code: "EW-01", title: "Email Anatomy", level: "A2", hours: 10, focus: "Subject lines, openings, closings, basic requests" },
      { code: "EW-02", title: "Tone & Formality", level: "B1", hours: 12, focus: "Formal vs neutral vs friendly, modal softening, contractions" },
      { code: "EW-03", title: "Requests, Replies & Follow-ups", level: "B1", hours: 12, focus: "Polite requests, chasing, confirming, scheduling" },
      { code: "EW-04", title: "Difficult Messages", level: "B2", hours: 14, focus: "Complaints, apologies, refusals, bad news, escalation" },
      { code: "EW-05", title: "Concision & Clarity", level: "B2", hours: 14, focus: "Cutting padding, active voice, paragraphing, bullet discipline" },
      { code: "EW-06", title: "Proposals & Formal Documents", level: "C1", hours: 16, focus: "Executive summaries, formal registers, diplomatic phrasing" }]},
  { id: "ielts", name: "IELTS Preparation", tag: "Exam training, Academic & General", goal: "ielts", color: "var(--l-c2)",
    levels: ["B1","B2","C1","C2"],
    aim: "Convert existing English into exam technique and a target band score.",
    outcomes: ["Know the band descriptors and how you are marked","Finish every paper inside the time limit","Repeatable technique for all four papers"],
    bands: [{ cefr: "B1", band: "4.0 - 5.0" }, { cefr: "B2", band: "5.5 - 6.5" }, { cefr: "C1", band: "7.0 - 8.0" }, { cefr: "C2", band: "8.5 - 9.0" }],
    modules: [
      { code: "IE-01", title: "Test Orientation & Diagnostics", level: "B1", hours: 8, focus: "Format, timing, band descriptors, baseline mock" },
      { code: "IE-02", title: "Listening Strategy", level: "B1", hours: 14, focus: "Prediction, distractors, map labelling, spelling traps" },
      { code: "IE-03", title: "Reading Under Time", level: "B2", hours: 16, focus: "Skimming, True/False/Not Given, matching headings" },
      { code: "IE-04", title: "Writing Task 1", level: "B2", hours: 14, focus: "Data description, overview sentence, trend language" },
      { code: "IE-05", title: "Writing Task 2", level: "B2", hours: 18, focus: "Essay types, position, coherence, 40-minute drill" },
      { code: "IE-06", title: "Speaking Parts 1-3", level: "B2", hours: 16, focus: "Extending answers, cue-card planning, abstract discussion" },
      { code: "IE-07", title: "Band 7+ Refinement", level: "C1", hours: 18, focus: "Complex structures under pressure, accuracy repair, mocks" }]},
];
const ORDER = ["A0","A1","A2","B1","B2","C1","C2"];
export const levelIdx = (l: string) => ORDER.indexOf(l);
export function recommend(level: string, goal: string) {
  let course = COURSES.find((c) => c.goal === goal) ?? COURSES[0];
  const li = levelIdx(level);
  let note = "";
  const mins = course.levels.map(levelIdx).filter((i) => i >= 0);
  const minIdx = mins.length ? Math.min(...mins) : 0;
  if (li < minIdx && course.id !== "gen") {
    note = course.name + " starts at " + ORDER[minIdx] + ". Build the foundation on General English first, then transfer across.";
    course = COURSES[0];
  }
  const mods = course.modules;
  const entry = mods.find((m) => m.level === level) ?? mods.find((m) => levelIdx(m.level) >= li) ?? mods[mods.length - 1];
  const remaining = mods.slice(Math.max(0, mods.indexOf(entry)));
  const hours = remaining.reduce((s, m) => s + m.hours, 0);
  const band = course.bands?.find((b) => b.cefr === level)?.band ?? null;
  return { course, entry, remaining, hours, note, band };
}
export const PROFILE = {
  name: "Ali Alhasawee",
  fullName: "Mr. Ali Abdul Karim Muhammad",
  title: "IELTS Instructor, Senior English Educator, Linguist",
  roles: ["IELTS Instructor","Senior English Educator","Linguist","Course Designer","Training Advisor"],
  city: "Basra, Iraq",
  phone: "+9647803402205",
  phoneDisplay: "+964 780 340 2205",
  email: "ali.alhasawee@gmail.com",
  quote: "English is the key to open doors.",
  motto: "Learn. Practice. Communicate. Achieve.",
};
