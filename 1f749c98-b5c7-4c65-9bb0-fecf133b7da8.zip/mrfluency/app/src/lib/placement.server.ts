// SERVER ONLY. Every rule that protects the test lives here and nowhere else:
// attempt count, question order, deadlines and pause budget are all decided
// from the database row and the server clock. Nothing the browser sends can
// move the cursor except a correctly addressed answer to the CURRENT question.
import { bindings } from "./bindings.server";
import { LEVELS, itemById, itemsForLevel, publicItem, type Item, type Level } from "./bank.server";
import { recommend, LEVEL_INFO } from "./courses";
import type { D1Database } from "@cloudflare/workers-types";
import { alertOwner } from "./alerts.server";

export const CFG = {
  questionSeconds: 75,
  readingSeconds: 150,
  perBlock: 8,
  maxAttempts: 2,
  passPct: 62,
  continuePct: 50,
  graceMs: 2500, // network slack: an answer sent just before the buzzer still counts
};
const now = () => Date.now();
const uid = () => crypto.randomUUID();

export function db(): D1Database {
  const d = bindings().DB;
  if (!d) throw new Error("database_unavailable");
  return d;
}
export function normEmail(e?: string | null) {
  const v = String(e ?? "").trim().toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? v : "";
}
export function candidateKey(email: string, name: string) {
  const e = normEmail(email);
  if (e) return "e:" + e;
  return "n:" + String(name).trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 48);
}
export function questionSeconds(item: Item) {
  return item.skill === "Reading" ? CFG.readingSeconds : CFG.questionSeconds;
}
async function audit(attemptId: string | null, ckey: string | null, event: string, detail?: unknown) {
  try {
    await db().prepare("INSERT INTO audit (id,attempt_id,ckey,event,detail,at) VALUES (?,?,?,?,?,?)")
      .bind(uid(), attemptId, ckey, event, detail ? JSON.stringify(detail).slice(0, 500) : null, now()).run();
  } catch { /* the trail must never break the test */ }
}

type Plan = { level: Level; ids: string[] }[];
export type AttemptRow = {
  id: string; ckey: string; name: string; email: string | null; goal: string;
  attempt_no: number; status: string; plan: string; bi: number; qi: number;
  q_started_at: number | null; q_deadline: number | null; remaining_ms: number | null;
  paused_at: number | null; pause_count: number; total_paused_ms: number;
  created_at: number; updated_at: number; completed_at: number | null; result: string | null;
};

function shuffle<T>(a: T[]): T[] {
  const x = a.slice();
  for (let i = x.length - 1; i > 0; i--) {
    const j = crypto.getRandomValues(new Uint32Array(1))[0] % (i + 1);
    [x[i], x[j]] = [x[j], x[i]];
  }
  return x;
}
function buildPlan(): Plan {
  return LEVELS.map((L) => ({ level: L, ids: shuffle(itemsForLevel(L)).slice(0, CFG.perBlock).map((i) => i.id) }))
    .filter((b) => b.ids.length > 0);
}
const planOf = (a: AttemptRow): Plan => JSON.parse(a.plan);
const planTotal = (p: Plan) => p.reduce((s, b) => s + b.ids.length, 0);
function planIndex(p: Plan, bi: number, qi: number) {
  let n = 0;
  for (let i = 0; i < bi; i++) n += p[i].ids.length;
  return n + qi;
}
function currentItem(a: AttemptRow): Item | undefined {
  const p = planOf(a);
  const b = p[a.bi];
  return b ? itemById(b.ids[a.qi]) : undefined;
}

export async function getAttempt(id: string): Promise<AttemptRow | null> {
  return (await db().prepare("SELECT * FROM attempts WHERE id=?").bind(id).first()) as AttemptRow | null;
}
export async function attemptsUsed(ckey: string) {
  const r = await db().prepare("SELECT COUNT(*) AS n FROM attempts WHERE ckey=? AND status IN ('COMPLETED','EXPIRED')").bind(ckey).first<{ n: number }>();
  return r?.n ?? 0;
}
export async function extraAttempts(ckey: string) {
  const r = await db().prepare("SELECT extra_attempts AS n FROM candidates WHERE ckey=?").bind(ckey).first<{ n: number }>();
  return r?.n ?? 0;
}
export async function openAttempt(ckey: string) {
  return (await db().prepare("SELECT * FROM attempts WHERE ckey=? AND status IN ('IN_PROGRESS','PAUSED') ORDER BY updated_at DESC LIMIT 1").bind(ckey).first()) as AttemptRow | null;
}
async function save(a: AttemptRow) {
  await db().prepare(
    `UPDATE attempts SET status=?,bi=?,qi=?,q_started_at=?,q_deadline=?,remaining_ms=?,paused_at=?,
     pause_count=?,total_paused_ms=?,updated_at=?,completed_at=?,result=? WHERE id=?`)
    .bind(a.status, a.bi, a.qi, a.q_started_at, a.q_deadline, a.remaining_ms, a.paused_at,
      a.pause_count, a.total_paused_ms, now(), a.completed_at, a.result, a.id).run();
}
function arm(a: AttemptRow) {
  const it = currentItem(a);
  if (!it) return;
  a.q_started_at = now();
  a.q_deadline = a.q_started_at + questionSeconds(it) * 1000;
  a.remaining_ms = null;
}

export async function startAttempt(input: { name: string; email: string; goal: string }) {
  const name = String(input.name || "").trim().slice(0, 80);
  const email = normEmail(input.email);
  const goal = ["general", "business", "writing", "ielts"].includes(input.goal) ? input.goal : "general";
  if (!name) return { error: "name_required" as const };
  const ckey = candidateKey(email, name);

  const live = await openAttempt(ckey);
  if (live) return { attemptId: live.id, resumed: true };

  const allowed = CFG.maxAttempts + (await extraAttempts(ckey));
  if ((await attemptsUsed(ckey)) >= allowed) return { error: "no_attempts" as const };

  await db().prepare("INSERT INTO candidates (ckey,name,email,extra_attempts,created_at) VALUES (?,?,?,0,?) ON CONFLICT(ckey) DO UPDATE SET name=excluded.name, email=COALESCE(excluded.email,candidates.email)")
    .bind(ckey, name, email || null, now()).run();

  const id = uid();
  const plan = buildPlan();
  const t = now();
  const first = itemById(plan[0].ids[0])!;
  await db().prepare(
    `INSERT INTO attempts (id,ckey,name,email,goal,attempt_no,status,plan,bi,qi,q_started_at,q_deadline,
     remaining_ms,paused_at,pause_count,total_paused_ms,created_at,updated_at,completed_at,result)
     VALUES (?,?,?,?,?,?,?,?,0,0,?,?,NULL,NULL,0,0,?,?,NULL,NULL)`)
    .bind(id, ckey, name, email || null, goal, (await attemptsUsed(ckey)) + 1, "IN_PROGRESS",
      JSON.stringify(plan), t, t + questionSeconds(first) * 1000, t, t).run();
  await audit(id, ckey, "TEST_STARTED", { attempt: (await attemptsUsed(ckey)) + 1 });
  await audit(id, ckey, "QUESTION_STARTED", { q: first.id });
  return { attemptId: id, resumed: false };
}

// Settle every question whose deadline passed while nobody was on the page.
// Called before anything is shown, so a refresh can never buy time.
async function reconcile(a: AttemptRow) {
  let guard = 0;
  while (a.status === "IN_PROGRESS" && a.q_deadline && now() > a.q_deadline + CFG.graceMs && guard++ < 100) {
    await record(a, null, true);
    if (!(await advance(a))) break;
  }
  return a;
}
async function record(a: AttemptRow, choice: number | null, timedOut: boolean) {
  const it = currentItem(a);
  if (!it) return;
  const t = now();
  const ok = !timedOut && choice === it.a;
  await db().prepare(
    `INSERT INTO responses (id,attempt_id,item_id,level,skill,choice,correct,status,started_at,deadline_at,submitted_at,time_used_ms)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`)
    .bind(uid(), a.id, it.id, it.level, it.skill, timedOut ? null : choice, ok ? 1 : 0,
      timedOut ? "TIMED_OUT" : "ANSWERED", a.q_started_at ?? t, a.q_deadline ?? t, t,
      Math.max(0, t - (a.q_started_at ?? t))).run();
  await audit(a.id, a.ckey, timedOut ? "QUESTION_TIMED_OUT" : "ANSWER_SUBMITTED", { q: it.id });
}
async function blockScore(a: AttemptRow, bi: number) {
  const ids = planOf(a)[bi].ids;
  const rows = await db().prepare(
    `SELECT correct FROM responses WHERE attempt_id=? AND item_id IN (${ids.map(() => "?").join(",")})`)
    .bind(a.id, ...ids).all<{ correct: number }>();
  const list = rows.results ?? [];
  return { correct: list.filter((r) => r.correct === 1).length, total: list.length };
}
// Moves the cursor forward by exactly one position. Returns false when the test is over.
async function advance(a: AttemptRow): Promise<boolean> {
  const p = planOf(a);
  const b = p[a.bi];
  if (a.qi < b.ids.length - 1) {
    a.qi += 1; arm(a); await save(a);
    await audit(a.id, a.ckey, "QUESTION_STARTED", { q: currentItem(a)?.id });
    return true;
  }
  const sc = await blockScore(a, a.bi);
  const pct = sc.total ? Math.round((sc.correct / sc.total) * 100) : 0;
  if (pct >= CFG.continuePct && a.bi < p.length - 1) {
    a.bi += 1; a.qi = 0; arm(a); await save(a);
    await audit(a.id, a.ckey, "QUESTION_STARTED", { q: currentItem(a)?.id });
    return true;
  }
  await complete(a);
  return false;
}

export async function complete(a: AttemptRow) {
  const p = planOf(a);
  const rows = (await db().prepare("SELECT * FROM responses WHERE attempt_id=? ORDER BY submitted_at").bind(a.id).all()).results as any[];
  const byId = new Map(rows.map((r) => [r.item_id, r]));
  let awarded = "A0";
  const blocks: any[] = [];
  for (let i = 0; i <= a.bi; i++) {
    const b = p[i]; if (!b) break;
    const taken = b.ids.filter((id) => byId.has(id));
    if (!taken.length) break;
    const correct = taken.filter((id) => byId.get(id).correct === 1).length;
    const pct = Math.round((correct / taken.length) * 100);
    blocks.push({ level: b.level, correct, total: taken.length, pct, passed: pct >= CFG.passPct });
  }
  for (const bl of blocks) { if (bl.passed) awarded = bl.level; else break; }

  const skills: Record<string, { c: number; t: number }> = {};
  let timedOut = 0;
  for (const r of rows) {
    skills[r.skill] = skills[r.skill] ?? { c: 0, t: 0 };
    skills[r.skill].t++; if (r.correct === 1) skills[r.skill].c++;
    if (r.status === "TIMED_OUT") timedOut++;
  }
  const correctTotal = rows.filter((r) => r.correct === 1).length;
  const rec = recommend(awarded, a.goal);
  const result = {
    level: awarded,
    levelName: LEVEL_INFO[awarded]?.name ?? "",
    percent: rows.length ? Math.round((correctTotal / rows.length) * 100) : 0,
    correct: correctTotal, items: rows.length, timedOut,
    attemptNo: a.attempt_no,
    minutes: Math.max(1, Math.round((now() - a.created_at - (a.total_paused_ms || 0)) / 60000)),
    blocks, skills,
    completion: timedOut ? `Completed - ${timedOut} question${timedOut > 1 ? "s" : ""} ran out of time` : "Completed in full",
    course: rec.course.name, courseAim: rec.course.aim,
    entry: rec.entry ? `${rec.entry.code} - ${rec.entry.title}` : "",
    entryFocus: rec.entry?.focus ?? "", remaining: rec.remaining.length, hours: rec.hours,
    note: rec.note, band: rec.band, date: new Date().toISOString(),
    name: a.name, goal: a.goal,
  };
  a.status = "COMPLETED"; a.completed_at = now(); a.result = JSON.stringify(result);
  a.q_deadline = null; a.q_started_at = null;
  await save(a);
  await audit(a.id, a.ckey, "TEST_COMPLETED", { level: awarded, attempt: a.attempt_no });
  await audit(a.id, a.ckey, "RESULT_GENERATED", { level: awarded });
  if (a.email) {
    try { await db().prepare("UPDATE users SET cefr_level=? WHERE lower(email)=?").bind(awarded, a.email.toLowerCase()).run(); } catch { /* optional */ }
  }
  // The result goes to the owner straight from the server, the moment the
  // test ends. The student never handles or forwards it, so it cannot be edited.
  const skillLines = Object.entries(skills).map(([k, v]) => `  ${k}: ${v.c}/${v.t}`);
  const blockLines = blocks.map((b: any) => `  ${b.level}: ${b.correct}/${b.total} (${b.pct}%)${b.passed ? " ✓" : ""}`);
  await alertOwner("placement", `Placement result: ${a.name} — ${awarded}`, [
    "Student: " + a.name,
    a.email ? "Email: " + a.email : "",
    "Goal: " + a.goal,
    `Level awarded: ${awarded}${result.levelName ? " (" + result.levelName + ")" : ""}`,
    `Score: ${correctTotal}/${rows.length} correct (${result.percent}%)`,
    `Attempt: ${a.attempt_no} · Time: ${result.minutes} min · ${result.completion}`,
    "By level:", ...blockLines,
    "By skill:", ...skillLines,
    result.entry ? "Recommended start: " + result.entry : "",
  ], "/studio");
  return result;
}

export async function stateOf(id: string) {
  let a = await getAttempt(id);
  if (!a) return { error: "not_found" as const };
  if (a.status === "IN_PROGRESS") { await reconcile(a); a = (await getAttempt(id))!; }
  const p = planOf(a);
  const allowed = CFG.maxAttempts + (await extraAttempts(a.ckey));
  const base = {
    attemptId: a.id, status: a.status, attemptNo: a.attempt_no, attemptsAllowed: allowed,
    name: a.name, goal: a.goal, serverNow: now(),
    index: planIndex(p, a.bi, a.qi), total: planTotal(p),
    pauseCount: a.pause_count, pausedMs: a.total_paused_ms,
  };
  if (a.status === "COMPLETED") return { ...base, result: a.result ? JSON.parse(a.result) : null };
  if (a.status === "EXPIRED") return { ...base };
  const it = currentItem(a);
  if (!it) return { ...base };
  return {
    ...base,
    section: p[a.bi].level,
    question: publicItem(it),
    secondsAllowed: questionSeconds(it),
    deadlineAt: a.status === "PAUSED" ? null : a.q_deadline,
    remainingMs: a.status === "PAUSED" ? a.remaining_ms : Math.max(0, (a.q_deadline ?? 0) - now()),
  };
}

export async function submit(id: string, itemId: string, choice: number) {
  let a = await getAttempt(id);
  if (!a) return { error: "not_found" as const };
  if (a.status !== "IN_PROGRESS") return { error: "not_active" as const, status: a.status };
  await reconcile(a);
  a = (await getAttempt(id))!;
  if (a.status !== "IN_PROGRESS") return { ok: true, timedOut: true };

  const it = currentItem(a);
  if (!it) return { error: "no_question" as const };
  // Requirement 17: the server decides which question you are on. An answer
  // addressed to any other question is rejected outright.
  if (itemId !== it.id) {
    await audit(a.id, a.ckey, "OUT_OF_ORDER_REJECTED", { sent: itemId, expected: it.id });
    return { error: "wrong_question" as const, expected: it.id };
  }
  const expired = !!a.q_deadline && now() > a.q_deadline + CFG.graceMs;
  if (expired) {
    await record(a, null, true);
    await advance(a);
    return { ok: true, timedOut: true };
  }
  if (!Number.isInteger(choice) || choice < 0 || choice >= it.opts.length) {
    return { error: "answer_required" as const };
  }
  await record(a, choice, false);
  await advance(a);
  return { ok: true };
}

export async function pause(id: string) {
  let a = await getAttempt(id);
  if (!a) return { error: "not_found" as const };
  if (a.status !== "IN_PROGRESS") return { error: "not_active" as const };
  await reconcile(a);
  a = (await getAttempt(id))!;
  if (a.status !== "IN_PROGRESS") return { ok: true };
  a.remaining_ms = Math.max(0, (a.q_deadline ?? now()) - now());
  a.paused_at = now();
  a.pause_count += 1;
  a.status = "PAUSED";
  await save(a);
  await audit(a.id, a.ckey, "TEST_PAUSED", { remainingSec: Math.round(a.remaining_ms / 1000) });
  return { ok: true };
}
// Resuming banks the time spent away and restarts from the STORED remainder,
// never a fresh allocation - so pausing can never buy extra thinking time.
export async function resume(id: string) {
  const a = await getAttempt(id);
  if (!a) return { error: "not_found" as const };
  if (a.status !== "PAUSED") return { ok: true };
  const away = a.paused_at ? Math.max(0, now() - a.paused_at) : 0;
  a.total_paused_ms += away;
  a.status = "IN_PROGRESS";
  a.paused_at = null;
  a.q_started_at = now();
  a.q_deadline = now() + Math.max(0, a.remaining_ms ?? 0);
  a.remaining_ms = null;
  await save(a);
  await audit(a.id, a.ckey, "TEST_RESUMED", { awaySec: Math.round(away / 1000) });
  return { ok: true };
}
export async function statusFor(name: string, email: string) {
  const ckey = candidateKey(normEmail(email), name);
  const live = await openAttempt(ckey);
  const used = await attemptsUsed(ckey);
  const allowed = CFG.maxAttempts + (await extraAttempts(ckey));
  const last = (await db().prepare("SELECT result FROM attempts WHERE ckey=? AND status='COMPLETED' ORDER BY completed_at DESC LIMIT 1").bind(ckey).first<{ result: string }>());
  return {
    ckey, used, allowed, left: Math.max(0, allowed - used),
    open: live ? { attemptId: live.id, status: live.status, attemptNo: live.attempt_no } : null,
    lastResult: last?.result ? JSON.parse(last.result) : null,
  };
}
