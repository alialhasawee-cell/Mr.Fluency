// SERVER ONLY — issuing and verifying certificates.
// A certificate is only ever issued from a completed enrolment; no route mints
// one from client input.
import { db } from "./auth.server";
import { recomputeCourseProgress } from "./lms.server";

const now = () => Date.now();
const uid = () => crypto.randomUUID();
export const INSTRUCTOR = "Ali Abdulkareem Mohammed Alhasawee";

async function nextCode() {
  const year = new Date().getFullYear();
  const r = await db().prepare("SELECT COUNT(*) AS n FROM certificates").first<{ n: number }>();
  return `MF-${year}-${String((r?.n ?? 0) + 1).padStart(6, "0")}`;
}

export async function issueIfEarned(userId: string, courseId: string) {
  const { pct, complete } = await recomputeCourseProgress(userId, courseId);
  if (!complete) return { issued: false as const, reason: "course_incomplete", pct };

  const existing = await db().prepare("SELECT code FROM certificates WHERE user_id=? AND course_id=? AND revoked=0")
    .bind(userId, courseId).first<{ code: string }>();
  if (existing) return { issued: false as const, reason: "already_issued", code: existing.code };

  const user = await db().prepare("SELECT name FROM users WHERE id=?").bind(userId).first<{ name: string }>();
  const course = await db().prepare("SELECT title FROM courses WHERE id=?").bind(courseId).first<{ title: string }>();
  if (!user || !course) return { issued: false as const, reason: "not_found" };

  const lvl = await db().prepare(
    `SELECT cl.cefr FROM enrollments e LEFT JOIN course_levels cl ON cl.id=e.level_id
     WHERE e.user_id=? AND e.course_id=?`).bind(userId, courseId).first<{ cefr: string | null }>();

  // Final score: the mean of the best attempt on every assessment in this course.
  const s = await db().prepare(
    `SELECT AVG(best) AS avg FROM (
       SELECT MAX(qa.pct) AS best FROM quiz_attempts qa JOIN quizzes q ON q.id=qa.quiz_id
       WHERE qa.user_id=? AND q.course_id=? AND qa.status='COMPLETED' GROUP BY qa.quiz_id)`)
    .bind(userId, courseId).first<{ avg: number | null }>();
  const score = Math.round(s?.avg ?? pct);

  const code = await nextCode();
  await db().prepare(
    `INSERT INTO certificates (id,code,user_id,course_id,level_id,student_name,course_title,cefr,score_pct,
      instructor,issued_at,revoked) VALUES (?,?,?,?,NULL,?,?,?,?,?,?,0)`)
    .bind(uid(), code, userId, courseId, user.name, course.title, lvl?.cefr ?? null, score, INSTRUCTOR, now()).run();
  await db().prepare(
    `INSERT INTO notifications (id,user_id,kind,title,body,link,created_at) VALUES (?,?,?,?,?,?,?)`)
    .bind(uid(), userId, "certificate", "Your certificate is ready",
      `${course.title} — certificate ${code}`, "/verify/" + code, now()).run();
  return { issued: true as const, code, score };
}

/** Public verification — returns only what a verifier needs, never the account. */
export async function verifyCode(code: string) {
  const c = await db().prepare(
    `SELECT code,student_name,course_title,cefr,score_pct,instructor,issued_at,revoked,revoked_reason
     FROM certificates WHERE code=?`).bind(String(code ?? "").trim().toUpperCase().slice(0, 40)).first<any>();
  if (!c) return { valid: false as const, reason: "not_found" };
  if (c.revoked === 1) return { valid: false as const, reason: "revoked", certificate: c };
  return { valid: true as const, certificate: c };
}
export async function certificatesFor(userId: string) {
  return (await db().prepare("SELECT * FROM certificates WHERE user_id=? ORDER BY issued_at DESC")
    .bind(userId).all()).results as any[];
}
