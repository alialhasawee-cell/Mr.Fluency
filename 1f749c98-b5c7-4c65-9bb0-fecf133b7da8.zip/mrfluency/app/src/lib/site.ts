// Public origin of the site. Set VITE_SITE_URL at build time when self-hosting.
export const SITE: string = ((import.meta as any).env?.VITE_SITE_URL || "https://mrfluency.higgsfield.app").replace(/\/$/, "");
