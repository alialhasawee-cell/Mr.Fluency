// SERVER ONLY. Owner alerts: every registration, placement result and
// enquiry is written to the owner_alerts table (the Studio inbox) and pushed
// to the owner by email (Resend) and WhatsApp (CallMeBot) when those secrets
// are configured. Nothing here is callable from the browser; results are
// produced from server-side data only, so a student cannot alter them.
import process from "node:process";
import { bindings } from "./bindings.server";

export const OWNER_NAME = "Mr. Ali Abdul Karim Muhammad";
export const OWNER_NAME_AR = "الأستاذ علي عبد الكريم محمد";
export const OWNER_EMAIL_DEFAULT = "ali.alhasawee@gmail.com";
export const OWNER_WHATSAPP_DEFAULT = "+9647803402205";

export type AlertKind = "registration" | "placement" | "enquiry" | "exam" | "system";
export type AlertRow = {
  id: string; kind: AlertKind; title: string; body: string; link: string | null;
  email_status: string | null; wa_status: string | null; read_at: number | null; created_at: number;
};

function db() {
  const d = bindings().DB;
  if (!d) throw new Error("database_unavailable");
  return d;
}

let ready = false;
async function ensure() {
  if (ready) return;
  await db().prepare(`CREATE TABLE IF NOT EXISTS owner_alerts (
    id TEXT PRIMARY KEY, kind TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, link TEXT,
    email_status TEXT, wa_status TEXT, read_at INTEGER, created_at INTEGER NOT NULL)`).run();
  ready = true;
}

function cfg() {
  return {
    ownerEmail: (process.env.OWNER_ALERT_EMAIL || process.env.OWNER_EMAIL || OWNER_EMAIL_DEFAULT).trim(),
    ownerWa: (process.env.OWNER_WHATSAPP || OWNER_WHATSAPP_DEFAULT).replace(/[^\d+]/g, ""),
    resendKey: (process.env.RESEND_API_KEY || "").trim(),
    resendFrom: (process.env.RESEND_FROM || "Mr. Fluency Academy <onboarding@resend.dev>").trim(),
    callmebotKey: (process.env.CALLMEBOT_APIKEY || "").trim(),
    site: (process.env.SITE_URL || "https://mrfluency.higgsfield.app").replace(/\/$/, ""),
  };
}

export function alertChannels() {
  const c = cfg();
  return { email: !!c.resendKey, whatsapp: !!c.callmebotKey, ownerEmail: c.ownerEmail, ownerWhatsapp: c.ownerWa };
}

const esc = (s: string) => s.replace(/[&<>"]/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]!));

async function sendEmail(subject: string, text: string, link: string | null): Promise<string> {
  const c = cfg();
  if (!c.resendKey) return "not_configured";
  const url = link ? c.site + link : c.site + "/studio";
  const html = `<div style="font-family:Arial,sans-serif;font-size:15px;line-height:1.6;color:#111">
    <h2 style="margin:0 0 12px;color:#0B1B3A">${esc(subject)}</h2>
    <pre style="white-space:pre-wrap;font-family:inherit;margin:0 0 16px">${esc(text)}</pre>
    <a href="${esc(url)}" style="display:inline-block;background:#0B1B3A;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none">Open in Studio</a>
    <p style="color:#666;font-size:12px;margin-top:20px">Mr. Fluency Academy — automatic owner alert</p></div>`;
  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { authorization: "Bearer " + c.resendKey, "content-type": "application/json" },
      body: JSON.stringify({ from: c.resendFrom, to: [c.ownerEmail], subject, text: text + "\n\n" + url, html }),
      signal: AbortSignal.timeout(8000),
    });
    return r.ok ? "sent" : "error_" + r.status;
  } catch { return "error_network"; }
}

async function sendWhatsApp(text: string): Promise<string> {
  const c = cfg();
  if (!c.callmebotKey || !c.ownerWa) return "not_configured";
  const u = "https://api.callmebot.com/whatsapp.php?phone=" + encodeURIComponent(c.ownerWa)
    + "&text=" + encodeURIComponent(text.slice(0, 1400)) + "&apikey=" + encodeURIComponent(c.callmebotKey);
  try {
    const r = await fetch(u, { signal: AbortSignal.timeout(8000) });
    const body = (await r.text().catch(() => "")).toLowerCase();
    return r.ok && !body.includes("error") ? "sent" : "error_" + r.status;
  } catch { return "error_network"; }
}

/** Record an owner alert and push it by email + WhatsApp. Never throws. */
export async function alertOwner(kind: AlertKind, title: string, lines: string[], link: string | null = "/studio") {
  const id = crypto.randomUUID();
  const body = lines.filter(Boolean).join("\n");
  try {
    await ensure();
    await db().prepare("INSERT INTO owner_alerts (id,kind,title,body,link,created_at) VALUES (?,?,?,?,?,?)")
      .bind(id, kind, title.slice(0, 200), body.slice(0, 4000), link, Date.now()).run();
  } catch { /* the inbox must never break the caller */ }
  const [email, wa] = await Promise.all([
    sendEmail("Mr. Fluency — " + title, body, link),
    sendWhatsApp("*Mr. Fluency — " + title + "*\n" + body),
  ]);
  try {
    await db().prepare("UPDATE owner_alerts SET email_status=?, wa_status=? WHERE id=?").bind(email, wa, id).run();
  } catch { /* ignore */ }
  return { id, email, wa };
}

export async function listAlerts(limit = 100): Promise<{ alerts: AlertRow[]; unread: number }> {
  await ensure();
  const r = await db().prepare("SELECT * FROM owner_alerts ORDER BY created_at DESC LIMIT ?").bind(limit).all<AlertRow>();
  const u = await db().prepare("SELECT COUNT(*) AS n FROM owner_alerts WHERE read_at IS NULL").first<{ n: number }>();
  return { alerts: r.results ?? [], unread: u?.n ?? 0 };
}

export async function markAlertsRead(ids?: string[]) {
  await ensure();
  if (ids && ids.length) {
    for (const id of ids.slice(0, 200)) {
      await db().prepare("UPDATE owner_alerts SET read_at=? WHERE id=? AND read_at IS NULL").bind(Date.now(), id).run();
    }
  } else {
    await db().prepare("UPDATE owner_alerts SET read_at=? WHERE read_at IS NULL").bind(Date.now()).run();
  }
}

export async function testAlert() {
  return alertOwner("system", "Test alert", [
    "This is a test from your Studio.",
    "If you received it, alerts are working.",
  ], "/studio");
}
