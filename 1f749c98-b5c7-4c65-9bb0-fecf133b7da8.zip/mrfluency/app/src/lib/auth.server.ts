// SERVER ONLY — identity, passwords, sessions, roles.
// Passwords use PBKDF2-SHA256 through WebCrypto (Workers has no bcrypt binding).
// Session tokens are random 256-bit values; only their SHA-256 digest is stored,
// so a database read cannot be replayed as a login.
import { bindings } from "./bindings.server";
import type { D1Database } from "@cloudflare/workers-types";

export const ROLES = ["owner", "admin", "teacher", "student"] as const;
export type Role = (typeof ROLES)[number];
const RANK: Record<Role, number> = { student: 1, teacher: 2, admin: 3, owner: 4 };

export const SESSION_COOKIE = "mf_session";
const SESSION_DAYS = 30;
const PBKDF2_ITER = 100_000;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_MAX_FAILS = 8;

export type User = {
  id: string; email: string; name: string; phone: string | null; role: Role;
  status: string; email_verified: number; avatar_url: string | null;
  goal: string | null; preferred_course: string | null; cefr_level: string | null;
  xp: number; streak_days: number; last_active: number | null;
  created_at: number; updated_at: number;
};

export function db(): D1Database {
  const d = bindings().DB;
  if (!d) throw new Error("database_unavailable");
  return d;
}
const now = () => Date.now();
const uid = () => crypto.randomUUID();
const b64 = (b: ArrayBuffer) => btoa(String.fromCharCode(...new Uint8Array(b)));
const fromB64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

export const normEmail = (e: unknown) => String(e ?? "").trim().toLowerCase();
export const validEmail = (e: string) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e) && e.length <= 160;
export function passwordProblem(pw: string): string | null {
  if (typeof pw !== "string" || pw.length < 8) return "Password must be at least 8 characters.";
  if (pw.length > 200) return "That password is too long.";
  if (!/[a-zA-Z]/.test(pw) || !/[0-9]/.test(pw)) return "Password must contain a letter and a number.";
  return null;
}

async function pbkdf2(password: string, salt: Uint8Array, iter: number) {
  const saltBuf = new Uint8Array(salt).buffer as ArrayBuffer;
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  return crypto.subtle.deriveBits({ name: "PBKDF2", salt: saltBuf, iterations: iter, hash: "SHA-256" }, key, 256);
}
export async function hashPassword(password: string) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const bits = await pbkdf2(password, salt, PBKDF2_ITER);
  return `pbkdf2$${PBKDF2_ITER}$${b64(salt.buffer as ArrayBuffer)}$${b64(bits)}`;
}
export async function verifyPassword(password: string, stored: string) {
  try {
    const [scheme, iterStr, saltB64, hashB64] = String(stored).split("$");
    if (scheme !== "pbkdf2") return false;
    const bits = await pbkdf2(password, fromB64(saltB64), parseInt(iterStr, 10));
    const a = new Uint8Array(bits), b = fromB64(hashB64);
    if (a.length !== b.length) return false;
    let diff = 0;
    for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
    return diff === 0;
  } catch { return false; }
}
async function sha256Hex(s: string) {
  const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return Array.from(new Uint8Array(b)).map((x) => x.toString(16).padStart(2, "0")).join("");
}

export async function audit(userId: string | null, event: string, detail?: unknown) {
  try {
    await db().prepare("INSERT INTO audit (id,attempt_id,ckey,event,detail,at) VALUES (?,?,?,?,?,?)")
      .bind(uid(), null, userId, event, detail ? JSON.stringify(detail).slice(0, 500) : null, now()).run();
  } catch { /* the trail never breaks the request */ }
}

// ---------- registration ----------
export async function registerStudent(input: {
  name: string; email: string; password: string; confirm?: string;
  phone?: string; goal?: string; preferredCourse?: string;
}) {
  const name = String(input.name ?? "").trim().slice(0, 80);
  const email = normEmail(input.email);
  if (!name) return { error: "name_required" as const };
  if (!validEmail(email)) return { error: "email_invalid" as const };
  const pwErr = passwordProblem(input.password);
  if (pwErr) return { error: "password_weak" as const, message: pwErr };
  if (input.confirm !== undefined && input.confirm !== input.password) return { error: "password_mismatch" as const };

  const existing = await db().prepare("SELECT id FROM users WHERE email=?").bind(email).first<{ id: string }>();
  if (existing) return { error: "email_taken" as const };

  const id = uid(), t = now();
  await db().prepare(
    `INSERT INTO users (id,email,name,phone,password_hash,role,status,email_verified,verify_token,
      goal,preferred_course,xp,streak_days,created_at,updated_at)
     VALUES (?,?,?,?,?,'student','active',0,?,?,?,0,0,?,?)`)
    .bind(id, email, name, String(input.phone ?? "").trim().slice(0, 40) || null,
      await hashPassword(input.password), uid(),
      String(input.goal ?? "general").slice(0, 30), String(input.preferredCourse ?? "").slice(0, 60) || null,
      t, t).run();
  await audit(id, "USER_REGISTERED", { email });
  return { userId: id };
}

// ---------- login with rate limiting ----------
async function recentFailures(key: string) {
  const r = await db().prepare("SELECT COUNT(*) AS n FROM login_attempts WHERE key=? AND ok=0 AND at > ?")
    .bind(key, now() - LOGIN_WINDOW_MS).first<{ n: number }>();
  return r?.n ?? 0;
}
export async function login(email0: string, password: string, ua?: string) {
  const email = normEmail(email0);
  if (!validEmail(email) || typeof password !== "string") return { error: "bad_credentials" as const };
  if ((await recentFailures(email)) >= LOGIN_MAX_FAILS) {
    await audit(null, "LOGIN_RATE_LIMITED", { email });
    return { error: "rate_limited" as const };
  }
  const u = await db().prepare("SELECT * FROM users WHERE email=?").bind(email).first<User & { password_hash: string }>();
  const ok = u ? await verifyPassword(password, u.password_hash) : false;
  await db().prepare("INSERT INTO login_attempts (id,key,at,ok) VALUES (?,?,?,?)")
    .bind(uid(), email, now(), ok ? 1 : 0).run();
  if (!u || !ok) {
    await new Promise((r) => setTimeout(r, 350));   // flatten the timing signal
    return { error: "bad_credentials" as const };
  }
  if (u.status !== "active") return { error: "suspended" as const };
  const { token } = await createSession(u.id, ua);
  await db().prepare("UPDATE users SET last_active=?, updated_at=? WHERE id=?").bind(now(), now(), u.id).run();
  await audit(u.id, "LOGIN_OK", {});
  return { token, user: publicUser(u) };
}

export async function createSession(userId: string, ua?: string) {
  const raw = b64(crypto.getRandomValues(new Uint8Array(32)).buffer as ArrayBuffer);
  const t = now();
  await db().prepare("INSERT INTO sessions_auth (id,user_id,token_hash,created_at,expires_at,last_seen,ua) VALUES (?,?,?,?,?,?,?)")
    .bind(uid(), userId, await sha256Hex(raw), t, t + SESSION_DAYS * 864e5, t, String(ua ?? "").slice(0, 200)).run();
  return { token: raw };
}
export async function destroySession(token: string) {
  if (!token) return;
  await db().prepare("DELETE FROM sessions_auth WHERE token_hash=?").bind(await sha256Hex(token)).run();
}
export async function destroyAllSessions(userId: string) {
  await db().prepare("DELETE FROM sessions_auth WHERE user_id=?").bind(userId).run();
}

export function publicUser(u: any): User {
  const { password_hash, verify_token, reset_token, reset_expires, ...rest } = u ?? {};
  return rest as User;
}
export function cookieValue(req: Request, name: string): string | null {
  const raw = req.headers.get("cookie") ?? "";
  const m = raw.match(new RegExp("(?:^|;\\s*)" + name + "=([^;]+)"));
  return m ? decodeURIComponent(m[1]) : null;
}
export function sessionCookie(token: string) {
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; Max-Age=${SESSION_DAYS * 86400}; HttpOnly; Secure; SameSite=Lax`;
}
export const clearedCookie = () => `${SESSION_COOKIE}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax`;

/** The single source of truth for "who is calling". Every protected route uses it. */
export async function currentUser(req: Request): Promise<User | null> {
  const token = cookieValue(req, SESSION_COOKIE);
  if (!token) return null;
  const hash = await sha256Hex(token);
  const row = await db().prepare(
    `SELECT u.* FROM sessions_auth s JOIN users u ON u.id = s.user_id
     WHERE s.token_hash=? AND s.expires_at > ?`).bind(hash, now()).first<any>();
  if (!row || row.status !== "active") return null;
  return publicUser(row);
}
export async function requireUser(req: Request) {
  const u = await currentUser(req);
  if (!u) return { error: "unauthenticated" as const, status: 401 };
  return { user: u };
}
export function atLeast(user: User | null, role: Role) {
  return !!user && RANK[user.role] >= RANK[role];
}
export async function requireRole(req: Request, role: Role) {
  const u = await currentUser(req);
  if (!u) return { error: "unauthenticated" as const, status: 401 };
  if (!atLeast(u, role)) return { error: "forbidden" as const, status: 403 };
  return { user: u };
}

// ---------- owner bootstrap ----------
// The owner is created from deployment secrets, never from a public route.
// There is deliberately no "become admin" endpoint anywhere in the codebase.
export async function ensureOwner() {
  const env = bindings() as Record<string, any>;
  const email = normEmail(env.OWNER_EMAIL);
  const password = typeof env.OWNER_PASSWORD === "string" ? env.OWNER_PASSWORD : "";
  if (!validEmail(email) || password.length < 8) return { skipped: "not_configured" as const };
  const existing = await db().prepare("SELECT id, role FROM users WHERE email=?").bind(email).first<{ id: string; role: string }>();
  const t = now();
  if (existing) {
    if (existing.role !== "owner") {
      await db().prepare("UPDATE users SET role='owner', status='active', updated_at=? WHERE id=?").bind(t, existing.id).run();
    }
    return { ownerId: existing.id, created: false };
  }
  const id = uid();
  await db().prepare(
    `INSERT INTO users (id,email,name,password_hash,role,status,email_verified,xp,streak_days,created_at,updated_at)
     VALUES (?,?,?,?,'owner','active',1,0,0,?,?)`)
    .bind(id, email, String(env.OWNER_NAME ?? "Ali Abdulkareem Mohammed Alhasawee"),
      await hashPassword(password), t, t).run();
  await audit(id, "OWNER_BOOTSTRAPPED", { email });
  return { ownerId: id, created: true };
}

// ---------- password reset ----------
export async function beginReset(email0: string) {
  const email = normEmail(email0);
  if (!validEmail(email)) return { ok: true };            // never reveal which addresses exist
  const u = await db().prepare("SELECT id FROM users WHERE email=?").bind(email).first<{ id: string }>();
  if (!u) return { ok: true };
  const token = b64(crypto.getRandomValues(new Uint8Array(24)).buffer as ArrayBuffer);
  await db().prepare("UPDATE users SET reset_token=?, reset_expires=?, updated_at=? WHERE id=?")
    .bind(await sha256Hex(token), now() + 60 * 60 * 1000, now(), u.id).run();
  await db().prepare("INSERT INTO email_outbox (id,to_email,subject,body,kind,status,created_at) VALUES (?,?,?,?,?,'PENDING',?)")
    .bind(uid(), email, "Reset your Mr. Fluency password",
      "Use this code to reset your password. It expires in one hour.\n\n" + token, "password_reset", now()).run();
  await audit(u.id, "PASSWORD_RESET_REQUESTED", {});
  return { ok: true, token };   // only ever handed to the owner (studio), never to the requester
}
export async function completeReset(token: string, password: string) {
  const pwErr = passwordProblem(password);
  if (pwErr) return { error: "password_weak" as const, message: pwErr };
  const u = await db().prepare("SELECT id FROM users WHERE reset_token=? AND reset_expires > ?")
    .bind(await sha256Hex(String(token ?? "")), now()).first<{ id: string }>();
  if (!u) return { error: "invalid_token" as const };
  await db().prepare("UPDATE users SET password_hash=?, reset_token=NULL, reset_expires=NULL, updated_at=? WHERE id=?")
    .bind(await hashPassword(password), now(), u.id).run();
  await destroyAllSessions(u.id);
  await audit(u.id, "PASSWORD_RESET_COMPLETED", {});
  return { ok: true };
}
