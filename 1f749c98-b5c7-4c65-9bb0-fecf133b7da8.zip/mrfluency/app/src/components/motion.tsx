// Shared motion + high-contrast visual kit used across the whole site.
// - <BgVideo/>: muted looping classroom clips behind content, darkened so
//   white text always stays readable. Honors reduced motion / data saver.
// - <Reveal/>: scroll-in transitions; every card gets a *different* one.
// - <BigArrow/>: large animated arrow that points at the next action.
import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";

export const BG_CLIPS = ["/bg/class-1.mp4", "/bg/class-2.mp4", "/bg/class-3.mp4", "/bg/class-4.mp4"];
export const BG_POSTERS = ["/bg/class-1.jpg", "/bg/class-2.jpg", "/bg/class-3.jpg", "/bg/class-4.jpg"];

function prefersLessMotion() {
  if (typeof window === "undefined") return true;
  const nav = navigator as Navigator & { connection?: { saveData?: boolean } };
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches || !!nav.connection?.saveData;
}

/** Background video layer. `fixed` pins it to the viewport (whole-page backdrop). */
export function BgVideo({ clip = 0, dim = 0.74, fixed = false }: { clip?: number; dim?: number; fixed?: boolean }) {
  const n = BG_CLIPS.length;
  const [i, setI] = useState(((clip % n) + n) % n);
  const [still, setStill] = useState(true);
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => { setStill(prefersLessMotion()); }, []);
  useEffect(() => { setI(((clip % n) + n) % n); }, [clip, n]);
  useEffect(() => {
    const v = ref.current;
    if (!v || still) return;
    v.muted = true;
    v.play().catch(() => { /* autoplay blocked: poster stays */ });
  }, [i, still]);
  return (
    <div className={"mf-bgv" + (fixed ? " mf-bgv-fixed" : "")} aria-hidden="true">
      {still ? (
        <img src={BG_POSTERS[i]} alt="" className="mf-bgv-media" />
      ) : (
        <video key={i} ref={ref} className="mf-bgv-media" src={BG_CLIPS[i]} poster={BG_POSTERS[i]}
          autoPlay muted playsInline loop preload="auto" />
      )}
      <div className="mf-bgv-shade" style={{ "--dim": dim } as CSSProperties} />
    </div>
  );
}

const VARIANTS = ["rise", "zoom", "flip", "slide-l", "slide-r", "blur", "swing", "drop", "tilt", "pop"] as const;
export type RevealVariant = (typeof VARIANTS)[number];
export const variantFor = (i: number): RevealVariant => VARIANTS[((i % VARIANTS.length) + VARIANTS.length) % VARIANTS.length];

/** Animates its children in when scrolled into view. Each `index` gets a different transition. */
export function Reveal({ children, index = 0, variant, delay, className = "", style }: {
  children: ReactNode; index?: number; variant?: RevealVariant; delay?: number; className?: string; style?: CSSProperties;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (prefersLessMotion() || typeof IntersectionObserver === "undefined") { setShown(true); return; }
    const io = new IntersectionObserver((es) => {
      if (es.some((e) => e.isIntersecting)) { setShown(true); io.disconnect(); }
    }, { rootMargin: "0px 0px -6% 0px", threshold: 0.08 });
    io.observe(el);
    const t = setTimeout(() => setShown(true), 2500); // never leave content hidden
    return () => { io.disconnect(); clearTimeout(t); };
  }, []);
  const v = variant ?? variantFor(index);
  const d = delay ?? Math.min(index % 6, 5) * 0.08;
  return (
    <div ref={ref} data-rv={v} className={"mf-rv " + (shown ? "in " : "") + className}
      style={{ ...(style ?? {}), transitionDelay: d + "s" }}>
      {children}
    </div>
  );
}

/** A big, bouncing arrow pointing students to the next step. */
export function BigArrow({ dir = "down", size = 64 }: { dir?: "down" | "right"; size?: number }) {
  return (
    <span className={"mf-arrow mf-arrow-" + dir} aria-hidden="true">
      <svg viewBox="0 0 64 64" width={size} height={size} fill="none" stroke="currentColor" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M32 6v46M12 34l20 20 20-20" />
      </svg>
    </span>
  );
}

/** English words drifting upward behind a section. */
export function WordField({ words }: { words?: string[] }) {
  const w = words ?? ["Hello", "Grammar", "Speak", "Listen", "Read", "Write", "Fluency", "Vocabulary", "IELTS", "Question", "Answer", "Learn", "Future", "Friends"];
  return (
    <div className="mf-words" aria-hidden="true">
      {w.map((x, i) => (
        <span key={x} style={{ left: ((i * 37) % 92) + 2 + "%", animationDelay: -(i * 2.3) + "s", animationDuration: 18 + (i % 5) * 3 + "s", fontSize: 16 + (i % 4) * 8 + "px" }}>{x}</span>
      ))}
    </div>
  );
}
