// Owner inbox (Studio tab): every registration, placement result and enquiry.
import { useCallback, useEffect, useState } from "react";

type Alert = {
  id: string; kind: string; title: string; body: string; link: string | null;
  email_status: string | null; wa_status: string | null; read_at: number | null; created_at: number;
};
type Channels = { email: boolean; whatsapp: boolean; ownerEmail: string; ownerWhatsapp: string };

const KIND: Record<string, [string, string]> = {
  registration: ["New student", "#38BDF8"],
  placement: ["Placement result", "#FACC15"],
  enquiry: ["Enquiry", "#F472B6"],
  exam: ["Exam", "#34D399"],
  system: ["System", "#A78BFA"],
};

function Status({ label, v }: { label: string; v: string | null }) {
  const ok = v === "sent";
  const off = !v || v === "not_configured";
  return (
    <span style={{ fontSize: 12, padding: "2px 8px", borderRadius: 999, background: ok ? "rgba(52,211,153,.18)" : off ? "rgba(255,255,255,.08)" : "rgba(248,113,113,.18)", color: ok ? "#A7F3D0" : off ? "#CBD5E1" : "#FECACA" }}>
      {label}: {ok ? "sent" : off ? "not set up" : "failed"}
    </span>
  );
}

export function OwnerInbox() {
  const [data, setData] = useState<{ alerts: Alert[]; unread: number; channels: Channels } | null>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/alerts", { credentials: "same-origin", cache: "no-store" });
      if (!r.ok) throw new Error(String(r.status));
      setData(await r.json()); setErr("");
    } catch { setErr("Could not load the inbox."); }
  }, []);
  useEffect(() => { void load(); const id = setInterval(load, 20000); return () => clearInterval(id); }, [load]);

  const post = async (body: unknown) => {
    setBusy(true); setMsg("");
    try {
      const r = await fetch("/api/alerts", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
      const j = await r.json().catch(() => ({}));
      if (j?.result) setMsg(`Test sent — email: ${j.result.email}, WhatsApp: ${j.result.wa}`);
      await load();
    } finally { setBusy(false); }
  };

  return (
    <div style={{ color: "var(--ink)" }}>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 10, alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 26, fontWeight: 800 }}>Inbox {data?.unread ? <span style={{ background: "#FACC15", color: "#0B1220", borderRadius: 999, padding: "2px 10px", fontSize: 14, marginInlineStart: 8 }}>{data.unread} new</span> : null}</h2>
          <p style={{ margin: "4px 0 0", color: "var(--ink-2)", fontSize: 15 }}>New students, placement results and questions arrive here instantly — and by email and WhatsApp once connected.</p>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <button className="cta-quiet" disabled={busy} onClick={() => post({ action: "read_all" })}>Mark all read</button>
          <button className="cta-test" disabled={busy} onClick={() => post({ action: "test" })}>Send test alert</button>
        </div>
      </div>
      {data ? (
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 14, fontSize: 14 }}>
          <span className="mf-pill" data-on={String(data.channels.email)}>Email → {data.channels.ownerEmail}: {data.channels.email ? "connected" : "not connected (add RESEND_API_KEY)"}</span>
          <span className="mf-pill" data-on={String(data.channels.whatsapp)}>WhatsApp → {data.channels.ownerWhatsapp}: {data.channels.whatsapp ? "connected" : "not connected (add CALLMEBOT_APIKEY)"}</span>
        </div>
      ) : null}
      {msg ? <div className="mf-note" style={{ marginBottom: 12 }}>{msg}</div> : null}
      {err ? <div className="mf-note" style={{ marginBottom: 12 }}>{err}</div> : null}
      <div style={{ display: "grid", gap: 10 }}>
        {data?.alerts.length === 0 ? <p style={{ color: "var(--ink-2)" }}>Nothing yet.</p> : null}
        {data?.alerts.map((a) => {
          const [label, color] = KIND[a.kind] ?? [a.kind, "#CBD5E1"];
          return (
            <article key={a.id} style={{ borderRadius: 14, padding: "14px 16px", background: a.read_at ? "var(--surface)" : "rgba(250,204,21,.10)", border: "1px solid " + (a.read_at ? "var(--line)" : "rgba(250,204,21,.55)") }}>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
                <span style={{ fontSize: 12, fontWeight: 800, color: "#0B1220", background: color, borderRadius: 6, padding: "2px 8px" }}>{label}</span>
                <strong style={{ fontSize: 17 }}>{a.title}</strong>
                <span style={{ color: "var(--ink-3)", fontSize: 13, marginInlineStart: "auto" }}>{new Date(a.created_at).toLocaleString()}</span>
              </div>
              <pre style={{ whiteSpace: "pre-wrap", fontFamily: "inherit", margin: "8px 0", color: "var(--ink-2)", fontSize: 15, lineHeight: 1.55 }}>{a.body}</pre>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
                <Status label="Email" v={a.email_status} /><Status label="WhatsApp" v={a.wa_status} />
                {!a.read_at ? <button className="mf-link" style={{ background: "none", cursor: "pointer", fontSize: 13 }} onClick={() => post({ action: "read", ids: [a.id] })}>Mark read</button> : null}
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
