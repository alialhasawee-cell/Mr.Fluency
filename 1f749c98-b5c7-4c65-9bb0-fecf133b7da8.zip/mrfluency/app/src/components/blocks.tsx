import { useMemo, useRef, useState, type ReactNode } from "react";
import { VocabTrainer, DialoguePlayer, ListeningBlock, GapFill, PromptList, TeacherNotes, SpeakButton } from "./teaching";

export type Block = { id: string; kind: string; sort: number; required: number; data: any };

/** Tiny, safe inline formatter: **bold**, *italic*, `code`. No HTML is ever
 *  injected, so admin-authored copy cannot become a script. */
function Rich({ text }: { text: string }) {
  const parts = useMemo(() => {
    const out: ReactNode[] = [];
    const src = String(text ?? "");
    const re = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g;
    let last = 0, m: RegExpExecArray | null, k = 0;
    while ((m = re.exec(src))) {
      if (m.index > last) out.push(src.slice(last, m.index));
      const tok = m[0];
      if (tok.startsWith("**")) out.push(<b key={k++}>{tok.slice(2, -2)}</b>);
      else if (tok.startsWith("`")) out.push(
        <code key={k++} className="mf-mono" style={{ background: "var(--surface-2)", padding: "1px 5px", borderRadius: 4 }}>{tok.slice(1, -1)}</code>);
      else out.push(<i key={k++}>{tok.slice(1, -1)}</i>);
      last = m.index + tok.length;
    }
    if (last < src.length) out.push(src.slice(last));
    return out;
  }, [text]);
  return <>{parts}</>;
}
function Paras({ text, className }: { text: string; className?: string }) {
  return (
    <>{String(text ?? "").split(/\n{2,}/).filter(Boolean).map((p, i) => (
      <p key={i} className={className ?? "mf-prose mt-3"}>
        {p.split("\n").map((line, j, arr) => (
          <span key={j}><Rich text={line} />{j < arr.length - 1 ? <br /> : null}</span>
        ))}
      </p>
    ))}</>
  );
}
function Frame({ label, children, tone }: { label?: string; children: ReactNode; tone?: string }) {
  return (
    <section className="mf-card p-5 sm:p-6" style={tone ? { borderLeft: "3px solid " + tone } : undefined}>
      {label ? <div className="mf-eyebrow mb-3">{label}</div> : null}
      {children}
    </section>
  );
}

const TONE: Record<string, string> = {
  vocab: "var(--l-a2)", grammar: "var(--l-b1)", dialogue: "var(--l-b2)", reading: "var(--brass)",
  listening: "var(--l-a1)", speaking: "var(--l-c1)", writing: "var(--l-c2)", activity: "var(--garnet)",
  video: "var(--l-b2)", animation: "var(--l-b2)", gapfill: "var(--l-b1)", examples: "var(--brass)",
};
const LABEL: Record<string, string> = {
  vocab: "Vocabulary", grammar: "Grammar", dialogue: "Dialogue", reading: "Reading",
  listening: "Listening", speaking: "Speaking", writing: "Writing", activity: "Practice",
  video: "Video", animation: "Animation", example: "Examples", examples: "Examples",
  gapfill: "Gap-fill", teachernotes: "Teacher notes", gallery: "Pictures", pdf: "Download",
};

export function BlockView({ block, onDone, done }: { block: Block; onDone?: (id: string) => void; done?: boolean }) {
  const d = block.data ?? {};
  const [watched, setWatched] = useState(false);
  const needsWatch = (block.kind === "video" || block.kind === "animation") && !!d.url && !done;
  const mark = block.required === 1 && onDone ? (
    <div className="mt-4 flex flex-wrap items-center gap-3">
      <button className={done ? "cta-resume" : "cta-quiet"} style={{ padding: "9px 16px", fontSize: 12 }}
        onClick={() => onDone(block.id)} disabled={done || (needsWatch && !watched)}>
        {done ? "✓ Done" : needsWatch && !watched ? "Watch the video to continue" : "Mark as done"}
      </button>
      {!done ? <span className="text-xs" style={{ color: "var(--ink-3)" }}>Required to finish the lesson</span> : null}
    </div>
  ) : null;

  let body: ReactNode = null;
  switch (block.kind) {
    case "heading":
      return <h2 className={d.level === 3 ? "text-xl" : "text-2xl"}>{d.text}</h2>;
    case "text": body = <Paras text={d.text ?? ""} />; break;
    case "callout": body = <div className="mf-note"><Paras text={d.text ?? ""} className="m-0 text-sm" /></div>; break;
    case "image":
      body = (
        <figure className="m-0">
          <img src={d.url} alt={d.alt ?? ""} loading="lazy"
            style={{ width: "100%", borderRadius: 10, border: "1px solid var(--line)" }} />
          {d.caption ? <figcaption className="mt-2 text-xs" style={{ color: "var(--ink-3)" }}>{d.caption}</figcaption> : null}
        </figure>); break;
    case "gallery":
      body = (
        <div className="grid gap-3 sm:grid-cols-2">
          {(d.items ?? []).map((it: any, i: number) => (
            <figure key={i} className="m-0">
              <img src={it.url} alt={it.alt ?? ""} loading="lazy"
                style={{ width: "100%", borderRadius: 10, border: "1px solid var(--line)" }} />
              {it.caption ? <figcaption className="mt-1.5 text-xs" style={{ color: "var(--ink-3)" }}>{it.caption}</figcaption> : null}
            </figure>))}
        </div>); break;
    case "vocab": body = <VocabTrainer items={d.items ?? []} blockId={block.id} />; break;
    case "grammar":
      body = (
        <>
          {d.title ? <h3 className="text-xl">{d.title}</h3> : null}
          <Paras text={d.rule ?? ""} />
          {(d.examples ?? []).length ? (
            <ul className="mt-4 grid list-none gap-2 p-0">
              {(d.examples ?? []).map((e: string, i: number) => (
                <li key={i} className="rounded-lg px-4 py-2.5 text-[15px]"
                  style={{ background: "var(--surface-2)", border: "1px solid var(--line)" }}><Rich text={e} /></li>))}
            </ul>) : null}
        </>); break;
    case "example":
      body = (
        <ul className="grid list-none gap-2 p-0">
          {(d.items ?? []).map((e: string, i: number) => (
            <li key={i} className="flex gap-2.5 text-[15px]"><span style={{ color: "var(--brass)" }}>▸</span><Rich text={e} /></li>))}
        </ul>); break;
    case "dialogue":
      body = (d.conversations ?? []).length
        ? <DialoguePlayer conversations={d.conversations} blockId={block.id} />
        : <Dialogue lines={d.lines ?? []} audio={d.audioUrl} />;
      break;
    case "audio":
    case "listening": body = <ListeningBlock data={d} blockId={block.id} />; break;
    case "video":
    case "animation": body = <VideoBlock data={d} onWatched={() => setWatched(true)} />; break;
    case "pdf":
      body = (
        <a className="chip-contact" href={d.url} target="_blank" rel="noopener">
          <svg viewBox="0 0 24 24"><path d="M6 2h8l4 4v16H6z" fill="none" stroke="currentColor" strokeWidth="1.8" /><path d="M14 2v4h4" fill="none" stroke="currentColor" strokeWidth="1.8" /></svg>
          <span className="flex flex-col"><span className="mf-label" style={{ marginBottom: 0 }}>PDF</span>
            <span className="text-sm font-semibold">{d.title ?? "Download"}</span></span>
        </a>); break;
    case "reading":
      body = (
        <>
          {d.title ? <h3 className="text-xl">{d.title}</h3> : null}
          <div className="mt-3 rounded-lg p-4 text-[15px] leading-relaxed"
            style={{ background: "var(--surface-2)", border: "1px solid var(--line)", borderLeft: "3px solid var(--brass)" }}>
            <Paras text={d.passage ?? d.text ?? ""} className="m-0 mt-3 first:mt-0" />
          </div>
          <div className="mt-3">
            <SpeakButton text={d.passage ?? d.text ?? ""} id={block.id + "-read"} label="Read it to me" rate={0.88} />
          </div>
        </>); break;
    case "speaking":
      if ((d.prompts ?? []).length) {
        body = <PromptList items={d.prompts} kind="speaking" blockId={block.id} />;
        break;
      }
      body = (
        <>
          <Paras text={d.prompt ?? ""} />
          {(d.tips ?? []).length ? (
            <ul className="mt-3 grid list-none gap-1.5 p-0 text-sm" style={{ color: "var(--ink-2)" }}>
              {(d.tips ?? []).map((t: string, i: number) => <li key={i}>• {t}</li>)}
            </ul>) : null}
          <p className="mt-3 text-xs" style={{ color: "var(--ink-3)" }}>
            Practise aloud. Mr. Fluency assesses speaking in your session.
          </p>
        </>); break;
    case "writing":
      body = (d.prompts ?? []).length
        ? <PromptList items={d.prompts} kind="writing" blockId={block.id} />
        : <WritingBlock data={d} blockId={block.id} />;
      break;
    case "gapfill": body = <GapFill data={d} blockId={block.id} />; break;
    case "teachernotes": return <TeacherNotes items={d.items ?? []} />;
    case "examples":
      body = (
        <ul className="grid list-none gap-2 p-0">
          {(d.items ?? []).map((e: string, i: number) => (
            <li key={i} className="flex items-center gap-2.5 text-[15px]">
              <span style={{ color: "var(--brass)" }}>&#9656;</span>
              <span className="flex-1"><Rich text={e} /></span>
              {d.speak ? <SpeakButton small text={e} id={block.id + "-x-" + i} label="Say" /> : null}
            </li>))}
        </ul>); break;
    case "activity": body = <Activity data={d} />; break;
    default: body = <Paras text={d.text ?? ""} />;
  }
  return <Frame label={LABEL[block.kind]} tone={TONE[block.kind]}>{body}{mark}</Frame>;
}

function MediaSlot({ what }: { what: string }) {
  return (
    <div className="mt-3 rounded-lg p-8 text-center" style={{ background: "var(--surface-2)", border: "1px dashed var(--line-2)" }}>
      <p className="text-sm" style={{ color: "var(--ink-3)" }}>
        {what} slot ready — upload a file in the teacher area and it plays here.
      </p>
    </div>
  );
}

function VocabList({ items }: { items: any[] }) {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <div className="grid gap-2">
      {items.map((v, i) => (
        <button key={i} className="mf-card w-full p-4 text-left" style={{ cursor: "pointer" }}
          onClick={() => setOpen(open === i ? null : i)} aria-expanded={open === i}>
          <div className="flex flex-wrap items-baseline gap-3">
            <b className="text-lg" style={{ fontFamily: "var(--display)" }}>{v.term}</b>
            {v.ipa ? <span className="mf-mono text-xs" style={{ color: "var(--ink-3)" }}>{v.ipa}</span> : null}
            {v.pos ? <span className="text-xs italic" style={{ color: "var(--ink-3)" }}>{v.pos}</span> : null}
            <span className="ml-auto text-xs" style={{ color: "var(--brass)" }}>{open === i ? "hide" : "meaning"}</span>
          </div>
          {open === i ? (
            <div className="mt-2">
              <p className="text-sm" style={{ color: "var(--ink-2)" }}>{v.meaning}</p>
              {v.example ? <p className="mt-1.5 text-sm italic" style={{ color: "var(--ink-3)" }}>“{v.example}”</p> : null}
            </div>) : null}
        </button>))}
    </div>
  );
}

function Dialogue({ lines, audio }: { lines: any[]; audio?: string }) {
  const speakers = Array.from(new Set(lines.map((l) => l.speaker)));
  return (
    <div>
      {audio ? <audio controls preload="none" src={audio} style={{ width: "100%", marginBottom: 14 }} /> : null}
      <div className="grid gap-2.5">
        {lines.map((l, i) => {
          const first = speakers.indexOf(l.speaker) === 0;
          return (
            <div key={i} className="flex" style={{ justifyContent: first ? "flex-start" : "flex-end" }}>
              <div className="max-w-[85%] rounded-xl px-4 py-2.5"
                style={{
                  background: first ? "var(--surface-2)" : "var(--garnet-soft)",
                  border: "1px solid " + (first ? "var(--line)" : "color-mix(in srgb, var(--garnet) 25%, transparent)"),
                }}>
                <span className="mf-label" style={{ marginBottom: 2 }}>{l.speaker}</span>
                <span className="block text-[15px]"><Rich text={l.text} /></span>
                {l.note ? <span className="mt-1 block text-xs" style={{ color: "var(--ink-3)" }}>{l.note}</span> : null}
              </div>
            </div>);
        })}
      </div>
    </div>
  );
}

/** Video with optional checkpoint questions that pause playback at a timestamp. */
function VideoBlock({ data, onWatched }: { data: any; onWatched?: () => void }) {
  const ref = useRef<HTMLVideoElement | null>(null);
  const furthest = useRef(0);
  const [seen, setSeen] = useState(0);
  const [failed, setFailed] = useState(false);
  // Forward seeking is limited to what has already been watched; rewinding is free.
  function onSeeking() {
    const v = ref.current; if (!v) return;
    if (v.currentTime > furthest.current + 1.5) v.currentTime = furthest.current;
  }
  function track() {
    const v = ref.current; if (!v || !v.duration || v.seeking) return;
    if (v.currentTime <= furthest.current + 1.5) furthest.current = Math.max(furthest.current, v.currentTime);
    const p = Math.min(100, Math.round((furthest.current / v.duration) * 100));
    setSeen(p);
    if (p >= 95) onWatched?.();
  }
  const [asked, setAsked] = useState<number[]>([]);
  const [active, setActive] = useState<any>(null);
  const [picked, setPicked] = useState<number | null>(null);
  const cps: any[] = data.checkpoints ?? [];

  function onTime() {
    track();
    const v = ref.current;
    if (!v || active) return;
    const hit = cps.findIndex((c, i) => !asked.includes(i) && v.currentTime >= (c.at ?? 0));
    if (hit >= 0) { v.pause(); setActive({ ...cps[hit], _i: hit }); setPicked(null); }
  }
  function resolve() {
    setAsked((a) => [...a, active._i]);
    setActive(null);
    setTimeout(() => { void ref.current?.play().catch(() => {}); }, 60);
  }
  return (
    <div>
      {data.title ? <h3 className="mb-3 text-xl">{data.title}</h3> : null}
      {data.url ? (
        <video ref={ref} controls preload="metadata" src={data.url} poster={data.poster}
          onTimeUpdate={onTime} onSeeking={onSeeking}
          onEnded={() => { if (ref.current) furthest.current = ref.current.duration; track(); onWatched?.(); }}
          onError={() => setFailed(true)} controlsList="nodownload" playsInline
          style={{ width: "100%", borderRadius: 10, border: "1px solid var(--line)" }} />
      ) : <MediaSlot what="Video" />}
      {data.url && !failed ? (
        <div className="mt-2 flex items-center gap-3">
          <div className="mf-bar" style={{ flex: 1, maxWidth: 320 }}><i style={{ width: seen + "%" }} /></div>
          <span className="mf-mono text-xs" style={{ color: "var(--ink-3)" }}>{seen}% watched</span>
        </div>) : null}
      {failed ? (
        <div className="mf-note mt-3 text-sm">This video could not load. Check your connection and{" "}
          <button className="mf-link" style={{ background: "none", border: 0, cursor: "pointer" }}
            onClick={() => { setFailed(false); ref.current?.load(); }}>try again</button>.</div>) : null}
      {cps.length ? (
        <p className="mt-2 text-xs" style={{ color: "var(--ink-3)" }}>
          This video pauses {cps.length} time{cps.length === 1 ? "" : "s"} to ask you a question.
        </p>) : null}
      {active ? (
        <div className="mf-card mt-4 p-5" style={{ borderLeft: "3px solid var(--garnet)" }}>
          <div className="mf-eyebrow mb-2">Checkpoint</div>
          <p className="text-[17px]" style={{ fontFamily: "var(--display)" }}>{active.q}</p>
          <div className="mt-3 grid gap-2" role="radiogroup">
            {(active.options ?? []).map((o: string, i: number) => (
              <button key={i} className="opt-btn" aria-checked={picked === i} role="radio" onClick={() => setPicked(i)}>
                <span className="opt-key">{"ABCD"[i]}</span><span>{o}</span>
              </button>))}
          </div>
          {picked !== null ? (
            <div className="mt-3">
              <p className="text-sm" style={{ color: picked === active.answer ? "var(--ok)" : "var(--danger)" }}>
                {picked === active.answer ? "Correct." : "Not quite — the answer is “" + (active.options?.[active.answer] ?? "") + "”."}
              </p>
              <button className="cta-test mt-3" style={{ padding: "10px 18px", fontSize: 14 }} onClick={resolve}>
                Continue watching →
              </button>
            </div>) : null}
        </div>) : null}
    </div>
  );
}

function WritingBlock({ data, blockId }: { data: any; blockId: string }) {
  const [text, setText] = useState("");
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const min = data.minWords ?? 0;
  return (
    <>
      <Paras text={data.prompt ?? ""} />
      <textarea className="mf-field mt-3" id={"w-" + blockId} rows={7} value={text}
        onChange={(e) => setText(e.target.value)} placeholder="Write your answer here…" />
      <p className="mt-2 text-xs" style={{ color: words >= min && min > 0 ? "var(--ok)" : "var(--ink-3)" }}>
        {words} word{words === 1 ? "" : "s"}{min ? ` — at least ${min} required` : ""}
      </p>
      <p className="mt-1 text-xs" style={{ color: "var(--ink-3)" }}>
        Bring this to your session for feedback, or paste it into an assignment when one is set.
      </p>
    </>
  );
}

/** Self-checking practice: gap-fill or matching, marked in the browser because
 *  nothing here counts towards a grade. Graded work goes through /api/quiz. */
function Activity({ data }: { data: any }) {
  const kind = data.kind ?? "gap";
  const [vals, setVals] = useState<Record<string, string>>({});
  const [checked, setChecked] = useState(false);
  const items: any[] = data.items ?? [];
  const norm = (s: string) => String(s ?? "").trim().toLowerCase();
  const right = items.filter((it, i) => norm(vals[String(i)]) === norm(it.answer)).length;

  return (
    <div>
      {data.instructions ? <Paras text={data.instructions} /> : null}
      <div className="mt-4 grid gap-2.5">
        {items.map((it, i) => {
          const ok = checked && norm(vals[String(i)]) === norm(it.answer);
          const bad = checked && !ok;
          return (
            <div key={i} className="flex flex-wrap items-center gap-3 rounded-lg p-3"
              style={{ background: "var(--surface-2)", border: "1px solid " + (bad ? "var(--danger)" : "var(--line)") }}>
              <span className="mf-mono text-xs" style={{ color: "var(--ink-3)" }}>{i + 1}</span>
              <span className="min-w-[170px] flex-1 text-[15px]"><Rich text={it.text ?? ""} /></span>
              {kind === "match" ? (
                <select className="mf-field" style={{ width: 190 }} value={vals[String(i)] ?? ""}
                  onChange={(e) => setVals({ ...vals, [String(i)]: e.target.value })}>
                  <option value="">Choose…</option>
                  {(data.choices ?? []).map((c: string) => <option key={c} value={c}>{c}</option>)}
                </select>
              ) : (
                <input className="mf-field" style={{ width: 190 }} value={vals[String(i)] ?? ""} placeholder="Your answer"
                  onChange={(e) => setVals({ ...vals, [String(i)]: e.target.value })} />
              )}
              {ok ? <span style={{ color: "var(--ok)" }}>✓</span> : null}
              {bad ? <span className="text-xs" style={{ color: "var(--danger)" }}>{it.answer}</span> : null}
            </div>);
        })}
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-3">
        <button className="cta-quiet" onClick={() => setChecked(true)}>Check my answers</button>
        {checked ? (
          <>
            <span className="mf-mono text-sm">{right} / {items.length}</span>
            <button className="mf-link" style={{ background: "none", border: 0, cursor: "pointer", fontSize: 13 }}
              onClick={() => { setChecked(false); setVals({}); }}>Try again</button>
          </>) : null}
      </div>
    </div>
  );
}
