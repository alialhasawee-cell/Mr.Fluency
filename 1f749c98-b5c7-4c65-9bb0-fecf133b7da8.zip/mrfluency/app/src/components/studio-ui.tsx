import { useState, type ReactNode } from "react";

export function Tabs({ tabs, active, onChange }: { tabs: { id: string; label: string }[]; active: string; onChange: (id: string) => void }) {
  return (
    <div className="flex flex-wrap gap-1.5 border-b pb-3" style={{ borderColor: "var(--line)" }}>
      {tabs.map((t) => (
        <button key={t.id} onClick={() => onChange(t.id)} className="rounded-md px-3.5 py-2 text-sm font-medium"
          style={{
            background: active === t.id ? "var(--surface)" : "transparent",
            color: active === t.id ? "var(--ink)" : "var(--ink-2)",
            border: "1px solid " + (active === t.id ? "var(--line)" : "transparent"), cursor: "pointer",
          }}>{t.label}</button>))}
    </div>
  );
}
export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="mb-4 block"><span className="mf-label">{label}</span>{children}
      {hint ? <span className="mt-1 block text-xs" style={{ color: "var(--ink-3)" }}>{hint}</span> : null}</label>
  );
}
export function Text({ value, onChange, placeholder, type = "text" }: any) {
  return <input className="mf-field" type={type} value={value ?? ""} placeholder={placeholder}
    onChange={(e) => onChange(e.target.value)} />;
}
export function Area({ value, onChange, rows = 4, placeholder }: any) {
  return <textarea className="mf-field" rows={rows} value={value ?? ""} placeholder={placeholder}
    onChange={(e) => onChange(e.target.value)} />;
}
export function Select({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: { v: string; l: string }[] }) {
  return (
    <select className="mf-field" value={value} onChange={(e) => onChange(e.target.value)}>
      {options.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
    </select>
  );
}
export function Card({ children, tone }: { children: ReactNode; tone?: string }) {
  return <div className="mf-card p-5" style={tone ? { borderLeft: "3px solid " + tone } : undefined}>{children}</div>;
}
export function Row({ children }: { children: ReactNode }) {
  return <div className="flex flex-wrap items-center gap-3">{children}</div>;
}
export function Pill({ children, tone }: { children: ReactNode; tone?: string }) {
  return (
    <span className="rounded-full px-2.5 py-0.5 text-xs font-semibold"
      style={{
        background: tone === "ok" ? "var(--ok)" : tone === "warn" ? "var(--brass)" : "var(--surface-2)",
        color: tone ? "#0B1220" : "var(--ink-2)", border: "1px solid " + (tone ? "transparent" : "var(--line)"),
      }}>{children}</span>
  );
}
export function Modal({ title, children, onClose, onSave, saveLabel = "Save", wide }: any) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center p-4" style={{ background: "rgba(20,18,15,.55)" }} onClick={onClose}>
      <div className="mf-card w-full overflow-hidden" style={{ maxWidth: wide ? 820 : 560 }} onClick={(e) => e.stopPropagation()}>
        <div className="border-b px-6 py-4" style={{ borderColor: "var(--line)" }}><h3 className="text-xl">{title}</h3></div>
        <div className="max-h-[62vh] overflow-auto px-6 py-5">{children}</div>
        <div className="flex justify-end gap-2 border-t px-6 py-4" style={{ borderColor: "var(--line)" }}>
          <button className="cta-quiet" onClick={onClose}>Cancel</button>
          {onSave ? <button className="cta-test" style={{ padding: "11px 20px", fontSize: 14 }} onClick={onSave}>{saveLabel}</button> : null}
        </div>
      </div>
    </div>
  );
}
export function Toast({ msg }: { msg: string }) {
  if (!msg) return null;
  return (
    <div className="fixed left-1/2 z-[60] -translate-x-1/2 rounded-full px-5 py-2.5 text-sm font-medium"
      style={{ bottom: 24, background: "var(--ink)", color: "var(--chalk)" }}>{msg}</div>
  );
}
export function useToast() {
  const [msg, setMsg] = useState("");
  return { msg, toast: (m: string) => { setMsg(m); setTimeout(() => setMsg(""), 2200); } };
}

/** Starter payloads so a new block is never an empty box. */
export const BLOCK_TEMPLATES: Record<string, any> = {
  heading: { text: "Section title", level: 2 },
  text: { text: "Write the explanation here.\n\nUse **bold** and *italic* where it helps." },
  callout: { text: "A short note the student should not miss." },
  image: { url: "", alt: "", caption: "" },
  gallery: { items: [{ url: "", alt: "", caption: "" }] },
  vocab: { items: [{ term: "hello", ipa: "/h@'l@U/", pos: "exclamation", meaning: "a greeting", example: "Hello! How are you?" }] },
  grammar: { title: "The verb to be", rule: "Explain the rule here.", examples: ["I **am** a student.", "She **is** from Basra."] },
  example: { items: ["First example.", "Second example."] },
  dialogue: { audioUrl: "", lines: [{ speaker: "Ali", text: "Hello! What's your name?" }, { speaker: "Sara", text: "My name is Sara." }] },
  audio: { url: "", task: "Listen and answer.", transcript: "" },
  listening: { url: "", task: "Listen and answer.", transcript: "" },
  video: { url: "", title: "", poster: "", checkpoints: [{ at: 12, q: "What is the girl's name?", options: ["Anna", "Sara", "Lily", "Emma"], answer: 1 }] },
  animation: { url: "", title: "", checkpoints: [] },
  pdf: { url: "", title: "Worksheet" },
  reading: { title: "", passage: "Paste the reading passage here." },
  speaking: { prompt: "Say these sentences aloud.", tips: ["Speak slowly.", "Stress the key word."] },
  writing: { prompt: "Write about yourself.", minWords: 40 },
  activity: { kind: "gap", instructions: "Complete the sentences.", items: [{ text: "My name ___ Sara.", answer: "is" }] },
  assignment: { title: "", instructions: "" },
};
export const BLOCK_KINDS = Object.keys(BLOCK_TEMPLATES);
