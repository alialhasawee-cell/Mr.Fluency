/** What makes a lesson feel taught rather than read: pronunciation on every
 *  word, role-play dialogue, a listening script you hear before you read, and
 *  gap-fills the page marks itself. */
import { useMemo, useState, type ReactNode } from "react";
import { useSpeech } from "./speech";

export const norm = (s: string) =>
  (s ?? "").toLowerCase().normalize("NFKD").replace(/[‘’']/g, "'")
    .replace(/[^\w'\s]/g, "").replace(/\s+/g, " ").trim();

export function Seg({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button type="button" onClick={onClick} className="rounded-md px-3 py-1.5 text-xs font-semibold"
      style={{
        border: "1px solid " + (active ? "var(--garnet)" : "var(--line)"),
        background: active ? "var(--garnet-soft)" : "var(--surface)",
        color: active ? "#93C5FD" : "var(--ink-2)", cursor: "pointer",
      }}>{children}</button>);
}

export function SpeakButton({
  text, id, lang, rate, voiceIndex, label = "Listen", small,
}: { text: string; id: string; lang?: string; rate?: number; voiceIndex?: number; label?: string; small?: boolean }) {
  const { supported, speak, stop, speakingId } = useSpeech();
  if (!supported) return null;
  const on = speakingId === id;
  return (
    <button type="button" onClick={() => (on ? stop() : speak(text, id, { lang, rate, voiceIndex }))}
      aria-label={on ? "Stop speaking" : `${label}: ${text.slice(0, 60)}`}
      className="inline-flex items-center gap-1.5 rounded-md"
      style={{
        border: "1px solid var(--line)", background: on ? "var(--garnet-soft)" : "var(--surface)",
        color: on ? "#93C5FD" : "var(--ink-2)", cursor: "pointer",
        padding: small ? "3px 8px" : "6px 12px", fontSize: small ? 11 : 13, flex: "none",
      }}>
      <svg viewBox="0 0 24 24" width={small ? 12 : 14} height={small ? 12 : 14} aria-hidden="true">
        {on ? <rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" />
            : <><path d="M4 9v6h4l5 4V5L8 9H4z" fill="currentColor" />
                <path d="M16 8.5a5 5 0 0 1 0 7" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></>}
      </svg>
      {small ? null : <span>{on ? "Stop" : label}</span>}
    </button>
  );
}

/* ------------------------------------------------------------------ vocab */

export function VocabTrainer({ items, blockId }: { items: any[]; blockId: string }) {
  const [open, setOpen] = useState<number | null>(null);
  const [mode, setMode] = useState<"list" | "practice">("list");
  if (!items?.length) return null;
  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <Seg active={mode === "list"} onClick={() => setMode("list")}>Word list</Seg>
        <Seg active={mode === "practice"} onClick={() => setMode("practice")}>Practise</Seg>
        <span className="ml-auto text-xs" style={{ color: "var(--ink-3)" }}>{items.length} words</span>
      </div>
      {mode === "list" ? (
        <div className="grid gap-2">
          {items.map((v, i) => (
            <div key={i} className="mf-card p-4">
              <div className="flex flex-wrap items-baseline gap-3">
                <b className="text-lg" style={{ fontFamily: "var(--display)" }}>{v.term}</b>
                <SpeakButton small text={v.term} id={`${blockId}-t-${i}`} label="Say" />
                <button type="button" className="ml-auto text-xs"
                  style={{ color: "var(--brass)", background: "none", border: 0, cursor: "pointer" }}
                  onClick={() => setOpen(open === i ? null : i)} aria-expanded={open === i}>
                  {open === i ? "hide" : v.meaning ? "meaning" : "example"}
                </button>
              </div>
              {open === i ? (
                <div className="mt-2">
                  {v.meaning ? <p className="m-0 text-sm" style={{ color: "var(--ink-2)" }}>{v.meaning}</p> : null}
                  {v.example ? (
                    <p className="mt-1.5 flex flex-wrap items-center gap-2 text-sm italic" style={{ color: "var(--ink-3)" }}>
                      <span>&ldquo;{v.example}&rdquo;</span>
                      <SpeakButton small text={v.example} id={`${blockId}-e-${i}`} label="Say" />
                    </p>) : null}
                </div>) : null}
            </div>))}
        </div>
      ) : <VocabPractice items={items} blockId={blockId} />}
    </div>
  );
}

/** Hear the sentence, type the missing word. Marked as you go. */
function VocabPractice({ items, blockId }: { items: any[]; blockId: string }) {
  const pool = useMemo(() => items.filter((v) => v.term && v.example &&
    String(v.example).toLowerCase().includes(String(v.term).toLowerCase())), [items]);
  const [i, setI] = useState(0);
  const [val, setVal] = useState("");
  const [state, setState] = useState<"idle" | "right" | "wrong" | "shown">("idle");
  if (!pool.length) return <p className="mf-prose text-sm">No practice items in this set.</p>;
  const cur = pool[i % pool.length];
  const gapped = String(cur.example).replace(
    new RegExp(String(cur.term).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"), "_____");
  const check = () => setState(norm(val) === norm(cur.term) ? "right" : "wrong");
  return (
    <div className="mf-card p-5">
      <div className="flex flex-wrap items-center gap-3">
        <span className="mf-label" style={{ marginBottom: 0 }}>Word {(i % pool.length) + 1} of {pool.length}</span>
        <SpeakButton small text={cur.example} id={`${blockId}-p-${i}`} label="Hear it" />
      </div>
      <p className="mt-3 text-lg">{gapped}</p>
      <div className="mt-3 flex flex-wrap gap-2">
        <input value={val} onChange={(e) => { setVal(e.target.value); setState("idle"); }}
          onKeyDown={(e) => { if (e.key === "Enter") check(); }}
          placeholder="Type the missing word" aria-label="Your answer"
          className="min-w-[180px] flex-1 rounded-md px-3 py-2 text-[15px]"
          style={{ border: "1px solid var(--line)", background: "var(--surface)", color: "var(--ink)" }} />
        <button type="button" className="cta-quiet" style={{ padding: "9px 16px", fontSize: 12 }} onClick={check}>Check</button>
        <button type="button" className="cta-quiet" style={{ padding: "9px 16px", fontSize: 12 }}
          onClick={() => { setVal(cur.term); setState("shown"); }}>Show me</button>
      </div>
      {state !== "idle" ? (
        <p className="mt-3 text-sm"
          style={{ color: state === "right" ? "#4ADE80" : state === "wrong" ? "#F87171" : "var(--ink-2)" }}>
          {state === "right" ? "✓ That's it."
            : state === "wrong" ? "Not quite — try again, or press Show me."
            : `The word is “${cur.term}”.`}
        </p>) : null}
      <button type="button" className="mt-4 text-sm"
        style={{ color: "var(--brass)", background: "none", border: 0, cursor: "pointer" }}
        onClick={() => { setI(i + 1); setVal(""); setState("idle"); }}>Next word &rarr;</button>
    </div>
  );
}

/* --------------------------------------------------------------- dialogue */

export function DialoguePlayer({ conversations, blockId }: { conversations: any[]; blockId: string }) {
  const [ci, setCi] = useState(0);
  const [myRole, setMyRole] = useState<string | null>(null);
  const { speakSequence, stop, speakingId, supported } = useSpeech();
  const conv = conversations?.[ci] ?? conversations?.[0];
  const speakers: string[] = useMemo(
    () => Array.from(new Set(((conv?.turns ?? []) as any[]).map((t) => t.speaker))), [conv]);
  if (!conv) return null;
  const id = `${blockId}-conv-${ci}`;
  const playing = speakingId === id;

  function playAll() {
    if (playing) { stop(); return; }
    const parts = (conv.turns as any[])
      .filter((t) => t.speaker !== myRole)
      .map((t) => ({ text: t.text, voiceIndex: speakers.indexOf(t.speaker) }));
    if (parts.length) speakSequence(parts, id);
  }

  return (
    <div>
      {conversations.length > 1 ? (
        <div className="mb-4 flex flex-wrap gap-1.5">
          {conversations.map((c: any, i: number) => (
            <Seg key={i} active={i === ci} onClick={() => { stop(); setCi(i); setMyRole(null); }}>
              {c.title ? String(c.title).slice(0, 26) : `Dialogue ${i + 1}`}
            </Seg>))}
        </div>) : null}

      {conv.title ? <h3 className="text-xl">{conv.title}</h3> : null}

      <div className="mt-3 mb-4 flex flex-wrap items-center gap-2">
        {supported ? (
          <button type="button" className={playing ? "cta-resume" : "cta-quiet"}
            style={{ padding: "9px 16px", fontSize: 12 }} onClick={playAll}>
            {playing ? "Stop" : myRole ? `Play — you are ${myRole}` : "Play conversation"}
          </button>) : null}
        <span className="text-xs" style={{ color: "var(--ink-3)" }}>Take a part:</span>
        {speakers.map((s) => (
          <Seg key={s} active={myRole === s} onClick={() => { stop(); setMyRole(myRole === s ? null : s); }}>{s}</Seg>
        ))}
      </div>

      <div className="grid gap-2.5">
        {(conv.turns as any[]).map((t, i) => {
          const first = speakers.indexOf(t.speaker) === 0;
          const mine = myRole === t.speaker;
          return (
            <div key={i} className="flex" style={{ justifyContent: first ? "flex-start" : "flex-end" }}>
              <div className="max-w-[88%] rounded-xl px-4 py-2.5"
                style={{
                  background: mine ? "var(--brass-soft)" : first ? "var(--surface-2)" : "var(--garnet-soft)",
                  border: "1px solid " + (mine ? "color-mix(in srgb, var(--brass) 45%, transparent)"
                    : first ? "var(--line)" : "color-mix(in srgb, var(--garnet) 25%, transparent)"),
                }}>
                <span className="mf-label flex flex-wrap items-center gap-2" style={{ marginBottom: 2 }}>
                  {t.speaker}{mine ? " — your line" : ""}
                  <SpeakButton small text={t.text} id={`${blockId}-l-${ci}-${i}`}
                    voiceIndex={speakers.indexOf(t.speaker)} label="Say" />
                </span>
                <span className="block text-[15px]">{t.text}</span>
              </div>
            </div>);
        })}
      </div>
      {myRole ? (
        <p className="mt-3 text-xs" style={{ color: "var(--ink-3)" }}>
          Your lines stay silent. Press play and say them aloud when it is your turn.
        </p>) : null}
    </div>
  );
}

/* -------------------------------------------------------------- listening */

export function ListeningBlock({ data, blockId }: { data: any; blockId: string }) {
  const [revealed, setRevealed] = useState(false);
  const [rate, setRate] = useState(0.9);
  const { speakSequence, speak, stop, speakingId, supported } = useSpeech();
  const convs: any[] = data.conversations ?? [];
  const turns: any[] = convs.length ? (convs[0].turns ?? []) : [];
  const speakers = Array.from(new Set(turns.map((t: any) => t.speaker)));
  const id = `${blockId}-listen`;
  const playing = speakingId === id;
  const hasAudio = !!(turns.length || data.script);

  function play() {
    if (playing) { stop(); return; }
    if (turns.length) {
      speakSequence(turns.map((t: any) => ({
        text: `${t.speaker}. ${t.text}`, voiceIndex: speakers.indexOf(t.speaker),
      })), id, { rate });
    } else if (data.script) speak(data.script, id, { rate });
  }

  return (
    <div>
      {data.task ? <p className="mf-prose">{data.task}</p> : null}
      {data.url ? <audio controls preload="none" src={data.url} style={{ width: "100%", marginTop: 12 }} /> : null}
      {hasAudio && supported ? (
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <button type="button" className={playing ? "cta-resume" : "cta-test"}
            style={{ padding: "11px 20px", fontSize: 14 }} onClick={play}>
            {playing ? "Stop" : "▶ Listen"}
          </button>
          <label className="flex items-center gap-2 text-xs" style={{ color: "var(--ink-3)" }}>
            Speed
            <input type="range" min={0.6} max={1.15} step={0.05} value={rate}
              onChange={(e) => setRate(Number(e.target.value))} style={{ width: 96 }} />
            <span className="mf-mono">{rate.toFixed(2)}&times;</span>
          </label>
        </div>) : null}
      {hasAudio ? (
        <div className="mt-4">
          <button type="button" className="text-sm"
            style={{ color: "var(--brass)", background: "none", border: 0, cursor: "pointer" }}
            onClick={() => setRevealed(!revealed)} aria-expanded={revealed}>
            {revealed ? "Hide the script" : "Show the script"}
          </button>
          <p className="mt-1 text-xs" style={{ color: "var(--ink-3)" }}>
            Try listening first &mdash; reading along makes it easier than it should be.
          </p>
          {revealed ? (
            <div className="mt-3 rounded-lg p-4" style={{ background: "var(--surface-2)", border: "1px solid var(--line)" }}>
              {turns.length ? turns.map((t: any, i: number) => (
                <p key={i} className="m-0 mt-1.5 text-sm first:mt-0"><b>{t.speaker}:</b> {t.text}</p>
              )) : <p className="m-0 text-sm">{data.script}</p>}
            </div>) : null}
        </div>
      ) : (
        <div className="mt-3 rounded-lg p-6 text-center"
          style={{ background: "var(--surface-2)", border: "1px dashed var(--line-2)" }}>
          <p className="m-0 text-sm" style={{ color: "var(--ink-3)" }}>
            Audio slot ready &mdash; upload a recording in the teacher area.
          </p>
        </div>)}
    </div>
  );
}

/* ---------------------------------------------------------------- gapfill */

/** "(1) ____" and a bare "____" both mark a gap. */
function splitGaps(text: string): { text: string; gap?: boolean }[] {
  const out: { text: string; gap?: boolean }[] = [];
  const re = /\(\s*\d{1,2}\s*\)\s*_{2,}|_{2,}/g;
  let last = 0, m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push({ text: text.slice(last, m.index) });
    out.push({ text: "", gap: true });
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push({ text: text.slice(last) });
  return out;
}

export function GapFill({ data, blockId }: { data: any; blockId: string }) {
  const answers: string[] = data.answers ?? [];
  const parts = useMemo(() => splitGaps(data.text ?? ""), [data.text]);
  const gapCount = parts.filter((p) => p.gap).length;
  const [vals, setVals] = useState<string[]>(() => Array(Math.max(gapCount, answers.length)).fill(""));
  const [checked, setChecked] = useState(false);
  if (!parts.length) return null;

  const canMark = answers.length > 0;
  const score = vals.reduce((n, v, i) => n + (answers[i] && norm(v) === norm(answers[i]) ? 1 : 0), 0);
  let gi = -1;

  return (
    <div>
      <p className="text-[15px]" style={{ lineHeight: 2.2 }}>
        {parts.map((p, i) => {
          if (!p.gap) return <span key={i}>{p.text}</span>;
          gi += 1;
          const k = gi;
          const right = checked && answers[k] && norm(vals[k] ?? "") === norm(answers[k]);
          const wrong = checked && answers[k] && !right;
          return (
            <input key={i} value={vals[k] ?? ""} aria-label={`Gap ${k + 1}`}
              onChange={(e) => { const n = [...vals]; n[k] = e.target.value; setVals(n); setChecked(false); }}
              className="mx-1 rounded px-2 py-0.5 text-[15px]"
              style={{
                width: 104,
                border: "1px solid " + (right ? "#2F7A4F" : wrong ? "var(--garnet)" : "var(--line)"),
                background: right ? "color-mix(in srgb, #2F7A4F 12%, transparent)"
                  : wrong ? "var(--garnet-soft)" : "var(--surface)",
                color: "var(--ink)",
              }} />);
        })}
      </p>
      {canMark ? (
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <button type="button" className="cta-quiet" style={{ padding: "9px 16px", fontSize: 12 }}
            onClick={() => setChecked(true)}>Check my answers</button>
          <button type="button" className="cta-quiet" style={{ padding: "9px 16px", fontSize: 12 }}
            onClick={() => { setVals(answers.slice()); setChecked(true); }}>Show answers</button>
          {checked ? (
            <span className="text-sm" style={{ color: score === answers.length ? "#4ADE80" : "var(--ink-2)" }}>
              {score} of {answers.length} correct
            </span>) : null}
        </div>
      ) : <p className="mt-3 text-xs" style={{ color: "var(--ink-3)" }}>Your teacher marks this one.</p>}
    </div>
  );
}

/* ------------------------------------------------------ prompts and notes */

export function PromptList({ items, kind, blockId }: { items: string[]; kind: "speaking" | "writing"; blockId: string }) {
  const [notes, setNotes] = useState<Record<number, string>>({});
  return (
    <ol className="m-0 grid list-none gap-3 p-0">
      {items.map((p, i) => (
        <li key={i} className="rounded-lg p-3.5" style={{ background: "var(--surface-2)", border: "1px solid var(--line)" }}>
          <div className="flex flex-wrap items-start gap-2">
            <span className="mf-mono text-xs" style={{ color: "var(--ink-3)", paddingTop: 3 }}>{i + 1}</span>
            <span className="min-w-[160px] flex-1 text-[15px]">{p}</span>
            {kind === "speaking" ? <SpeakButton small text={p} id={`${blockId}-sp-${i}`} label="Hear" /> : null}
          </div>
          <textarea rows={kind === "writing" ? 3 : 2} value={notes[i] ?? ""}
            onChange={(e) => setNotes({ ...notes, [i]: e.target.value })}
            placeholder={kind === "writing" ? "Write your answer…" : "Notes for your answer…"}
            aria-label={`Answer ${i + 1}`}
            className="mt-2 w-full rounded-md px-3 py-2 text-sm"
            style={{ border: "1px solid var(--line)", background: "var(--surface)", color: "var(--ink)" }} />
        </li>))}
    </ol>
  );
}

/** Warm-ups and classroom games from the book. Staff only — the lesson page
 *  decides whether to render this at all. */
export function TeacherNotes({ items }: { items: string[] }) {
  if (!items?.length) return null;
  return (
    <div className="mf-card p-5" style={{ borderLeft: "3px solid var(--brass)", background: "var(--brass-soft)" }}>
      <div className="mf-eyebrow mb-2">Teacher notes &mdash; students do not see this</div>
      <ul className="m-0 grid list-none gap-1.5 p-0 text-sm">
        {items.map((t, i) => <li key={i} className="flex gap-2"><span style={{ color: "var(--brass)" }}>&#9656;</span>{t}</li>)}
      </ul>
    </div>);
}
