import { Link } from "@tanstack/react-router";
import { BigArrow } from "./motion";

export const LEVEL_LOOK: Record<string, { color: string; grad: string; name: string; icon: string }> = {
  A1: { color: "#7DD3FC", grad: "linear-gradient(135deg,#0369A1,#0EA5E9)", name: "Beginner", icon: "🌱" },
  A2: { color: "#6EE7B7", grad: "linear-gradient(135deg,#047857,#10B981)", name: "Elementary", icon: "🚀" },
  B1: { color: "#BEF264", grad: "linear-gradient(135deg,#4D7C0F,#84CC16)", name: "Intermediate", icon: "🧭" },
  B2: { color: "#FCD34D", grad: "linear-gradient(135deg,#B45309,#F59E0B)", name: "Upper-Intermediate", icon: "🏆" },
  C1: { color: "#FDBA74", grad: "linear-gradient(135deg,#9A3412,#F97316)", name: "Advanced", icon: "🎓" },
};

export function PlacementGate({ placed, signedIn }: { placed: string | null; signedIn: boolean }) {
  if (placed) {
    return (
      <div className="mf-card flex flex-wrap items-center gap-3 p-5" style={{ borderColor: "#4ADE80" }}>
        <span style={{ fontSize: 28 }}>✅</span>
        <div className="min-w-[200px] flex-1">
          <b style={{ fontSize: 19 }}>Your placement level: {placed}</b>
          <div style={{ color: "var(--ink-2)", fontSize: 16 }}>{placed} and every level below it are open. Higher levels open after you pass the final exam of the level before.</div>
        </div>
      </div>
    );
  }
  return (
    <div className="mf-banner flex flex-wrap items-center gap-5">
      <BigArrow dir="right" size={56} />
      <div className="min-w-[220px] flex-1">
        <b style={{ fontSize: 22 }}>First step: the placement test</b>
        <div style={{ color: "var(--ink-2)", fontSize: 17 }}>
          You can look around freely, but no course can start until you finish the placement test. Your result goes straight to Mr. Ali.
        </div>
      </div>
      <Link to={signedIn ? "/placement" : "/guest"} search={signedIn ? undefined : ({ mode: "signup" } as any)} className="cta-test" style={{ fontSize: 18 }}>
        {signedIn ? "Take the placement test" : "Create an account to start"}
      </Link>
    </div>
  );
}

