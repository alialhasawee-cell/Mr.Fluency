import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { PROFILE } from "../lib/courses";

export const ALL_LEVELS = ["A0", "A1", "A2", "B1", "B2", "C1", "C2"];

/** The Mr. Fluency logo, sized by HEIGHT so its 682x704 proportions survive.
 *  The badge and the MR. FLUENCY plate are one shape — cropping the plate off
 *  clips the wordmark, and forcing the result square squashes it, so the whole
 *  lockup is used at every size. */
export function Mark({ size = 38, alt = "" }: { size?: number; alt?: string }) {
  const w = Math.round((size * 682) / 704);
  return (
    <img
      src="/brand/mf-logo.webp"
      alt={alt}
      {...(alt ? {} : { "aria-hidden": "true" as const })}
      width={w}
      height={size}
      decoding="async"
      style={{ width: w, height: size, flex: "none", display: "block" }}
    />
  );
}

/** The same logo, sized by width, for places with vertical room. */
export function LogoLockup({ width = 180, alt = "Mr. Fluency" }: { width?: number; alt?: string }) {
  const h = Math.round((width * 704) / 682);
  return (
    <img
      src="/brand/mf-logo.webp"
      alt={alt}
      width={width}
      height={h}
      decoding="async"
      style={{ width, height: h, display: "block" }}
    />
  );
}

export function LevelChip({ level }: { level: string }) {
  return <span className={"lvl lvl-" + level}>{level}</span>;
}

export function DoorArt() {
  return (
    <svg viewBox="0 0 320 240" role="img"
      aria-label="An open doorway with light beyond it and a key in the foreground"
      style={{ width: "100%", height: "auto", maxWidth: 400 }}>
      <defs>
        <linearGradient id="mfBeam" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="var(--brass)" stopOpacity=".55" />
          <stop offset="100%" stopColor="var(--brass)" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="mfDoor" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--garnet)" stopOpacity=".92" />
          <stop offset="100%" stopColor="var(--garnet)" stopOpacity=".62" />
        </linearGradient>
        <pattern id="mfGrid" width="16" height="16" patternUnits="userSpaceOnUse">
          <path d="M16 0H0v16" fill="none" stroke="var(--line)" strokeWidth="1" />
        </pattern>
      </defs>
      <rect width="320" height="240" fill="url(#mfGrid)" opacity=".55" />
      <path d="M118 28 L300 6 L300 234 L118 214 Z" fill="url(#mfBeam)" />
      <rect x="62" y="26" width="112" height="188" rx="3" fill="var(--surface)" stroke="var(--line-2)" strokeWidth="2" />
      <rect x="74" y="38" width="88" height="164" rx="2" fill="var(--chalk)" stroke="var(--line)" strokeWidth="1.5" />
      <path d="M118 26 L174 44 L174 196 L118 214 Z" fill="url(#mfDoor)" />
      <path d="M126 56 L166 68 L166 116 L126 106 Z" fill="var(--chalk)" opacity=".22" />
      <path d="M126 128 L166 136 L166 180 L126 174 Z" fill="var(--chalk)" opacity=".14" />
      <circle cx="126" cy="122" r="3.4" fill="var(--brass)" />
      <g transform="translate(196 126) rotate(-18)">
        <circle r="17" fill="none" stroke="var(--brass)" strokeWidth="5" />
        <circle r="6" fill="var(--chalk)" stroke="var(--brass)" strokeWidth="2.5" />
        <rect x="15" y="-3.2" width="74" height="6.4" rx="3" fill="var(--brass)" />
        <rect x="66" y="3" width="6" height="15" rx="2.5" fill="var(--brass)" />
        <rect x="80" y="3" width="6" height="21" rx="2.5" fill="var(--brass)" />
      </g>
      <circle cx="246" cy="52" r="3" fill="var(--brass)" opacity=".7" />
      <circle cx="272" cy="86" r="2" fill="var(--brass)" opacity=".5" />
      <circle cx="232" cy="196" r="2.4" fill="var(--brass)" opacity=".45" />
    </svg>
  );
}

export function Monogram({ size = 150 }: { size?: number }) {
  return (
    <svg viewBox="0 0 160 160" role="img" aria-label="Monogram: the initials A A" style={{ width: size, height: size }}>
      <defs>
        <linearGradient id="mfRing" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="var(--garnet)" /><stop offset="100%" stopColor="var(--brass)" />
        </linearGradient>
      </defs>
      <circle cx="80" cy="80" r="74" fill="none" stroke="url(#mfRing)" strokeWidth="3" />
      <circle cx="80" cy="80" r="64" fill="var(--surface-2)" stroke="var(--line)" strokeWidth="1" />
      <text x="80" y="80" textAnchor="middle" dominantBaseline="central"
        fontFamily="Newsreader, Georgia, serif" fontSize="52" fontWeight="500" fill="var(--garnet)">AA</text>
      <text x="80" y="118" textAnchor="middle" fontFamily="IBM Plex Mono, monospace"
        fontSize="9" letterSpacing="3" fill="var(--ink-3)">BASRA</text>
    </svg>
  );
}

const LEVEL_NAMES: Record<string, string> = {
  A0: "Absolute Beginner", A1: "Beginner", A2: "Elementary", B1: "Intermediate",
  B2: "Upper-Intermediate", C1: "Advanced", C2: "Proficient",
};

export function Staircase({ current }: { current?: string }) {
  return (
    <svg viewBox="0 0 320 190" role="img" aria-label="The CEFR ladder from A0 up to C2 drawn as a staircase"
      style={{ width: "100%", height: "auto" }}>
      <line x1="6" y1="168.5" x2="314" y2="168.5" stroke="var(--line-2)" strokeWidth="1.5" />
      {ALL_LEVELS.map((L, i) => {
        const w = 38, x = 12 + i * 43, y = 150 - i * 19;
        const c = "var(--l-" + L.toLowerCase() + ")";
        const here = current === L;
        return (
          <g key={L}>
            <rect x={x} y={y} width={w} height={150 - y + 18} rx="2" fill={c} opacity={here ? 0.45 : 0.2 + i * 0.09} />
            <rect x={x} y={y} width={w} height="16" rx="2" fill={c} />
            <text x={x + w / 2} y={y + 11.5} textAnchor="middle" fontFamily="IBM Plex Mono, monospace"
              fontSize="9.5" fontWeight="600" fill="var(--chalk)">{L}</text>
            {here ? (
              <text x={x + w / 2} y={y - 7} textAnchor="middle" fontFamily="IBM Plex Mono, monospace"
                fontSize="8" fontWeight="600" fill={c}>YOU</text>
            ) : null}
            <title>{L + " - " + LEVEL_NAMES[L]}</title>
          </g>
        );
      })}
    </svg>
  );
}

const GLYPHS: Record<string, ReactNode> = {
  gen: <><circle cx="24" cy="24" r="17" fill="none" stroke="currentColor" strokeWidth="2.2" /><ellipse cx="24" cy="24" rx="7.5" ry="17" fill="none" stroke="currentColor" strokeWidth="1.6" /><path d="M7.5 18h33M7.5 30h33" stroke="currentColor" strokeWidth="1.6" /></>,
  biz: <><rect x="7" y="16" width="34" height="24" rx="3" fill="none" stroke="currentColor" strokeWidth="2.2" /><path d="M18 16v-3a3 3 0 013-3h6a3 3 0 013 3v3" fill="none" stroke="currentColor" strokeWidth="2.2" /><path d="M7 26h34" stroke="currentColor" strokeWidth="1.6" /><rect x="21" y="23" width="6" height="6" rx="1.5" fill="currentColor" /></>,
  email: <><rect x="6" y="12" width="36" height="26" rx="3" fill="none" stroke="currentColor" strokeWidth="2.2" /><path d="M6.5 15l17.5 13L41.5 15" fill="none" stroke="currentColor" strokeWidth="2" /><path d="M6 36l12-10M42 36L30 26" stroke="currentColor" strokeWidth="1.4" /></>,
  ielts: <><circle cx="24" cy="19" r="12" fill="none" stroke="currentColor" strokeWidth="2.2" /><circle cx="24" cy="19" r="4.5" fill="currentColor" /><path d="M16 29l-3 14 11-5.5L35 43l-3-14" fill="none" stroke="currentColor" strokeWidth="2.1" strokeLinejoin="round" /></>,
};
export function CourseGlyph({ id, size = 40 }: { id: string; size?: number }) {
  return <svg viewBox="0 0 48 48" aria-hidden="true" style={{ width: size, height: size }}>{GLYPHS[id] ?? GLYPHS.gen}</svg>;
}

export function ContactRow() {
  const wa = "https://wa.me/" + PROFILE.phone.replace(/[^0-9]/g, "");
  const Item = ({ href, label, value, children, ext }: { href?: string; label: string; value: string; children: ReactNode; ext?: boolean }) => {
    const inner = (
      <>
        {children}
        <span className="flex min-w-0 flex-col">
          <span className="mf-label" style={{ marginBottom: 0 }}>{label}</span>
          <span className="break-words text-sm font-semibold">{value}</span>
        </span>
      </>
    );
    return href ? (
      <a className="chip-contact" href={href} {...(ext ? { target: "_blank", rel: "noopener" } : {})}>{inner}</a>
    ) : (
      <div className="chip-contact" style={{ cursor: "default" }}>{inner}</div>
    );
  };
  return (
    <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
      <Item href={"tel:" + PROFILE.phone} label="Phone" value={PROFILE.phoneDisplay}>
        <svg viewBox="0 0 24 24"><path d="M5 3h4l2 5-2.5 1.5a12 12 0 006 6L16 13l5 2v4a2 2 0 01-2 2A16 16 0 013 5a2 2 0 012-2z" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /></svg>
      </Item>
      <Item href={wa} label="WhatsApp" value={PROFILE.phoneDisplay} ext>
        <svg viewBox="0 0 24 24"><path d="M3.5 20.5l1.3-4.2A8.2 8.2 0 1112 20.2a8.4 8.4 0 01-3.9-1z" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /><path d="M9 9.2c.3 2.6 3.2 5.5 5.8 5.8l1-1.4 1.8 1-.7 1.4c-2.8.8-7.8-3.6-8.4-6.8l1.4-.8 1 1.8z" fill="currentColor" /></svg>
      </Item>
      <Item href={"mailto:" + PROFILE.email} label="Email" value={PROFILE.email}>
        <svg viewBox="0 0 24 24"><rect x="2.5" y="4.5" width="19" height="15" rx="2" fill="none" stroke="currentColor" strokeWidth="1.8" /><path d="M3 6l9 6.5L21 6" fill="none" stroke="currentColor" strokeWidth="1.8" /></svg>
      </Item>
      <Item label="Based in" value={PROFILE.city}>
        <svg viewBox="0 0 24 24"><path d="M12 21s7-6.2 7-11a7 7 0 10-14 0c0 4.8 7 11 7 11z" fill="none" stroke="currentColor" strokeWidth="1.8" /><circle cx="12" cy="10" r="2.6" fill="currentColor" /></svg>
      </Item>
    </div>
  );
}
