// The motion-led entrance system: a dark stage with a living "letter
// constellation" (English + Arabic glyphs drifting and linking in brass light),
// a bilingual EN/AR switch, and the glass card used by the owner/guest forms.
// Everything is drawn in code — no video or image generation needed — and the
// whole stage falls back to a still frame for prefers-reduced-motion.
import { useEffect, useRef, useState, createContext, useContext, type ReactNode } from "react";
import { GATE_CSS } from "./gate-css";
import { BgVideo } from "./motion";

export type Lang = "en" | "ar";
const LangCtx = createContext<{ lang: Lang; setLang: (l: Lang) => void }>({ lang: "en", setLang: () => {} });
export const useLang = () => useContext(LangCtx);
export const t = (lang: Lang, en: string, ar: string) => (lang === "ar" ? ar : en);

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");
  useEffect(() => {
    try { const s = localStorage.getItem("mf_lang"); if (s === "ar" || s === "en") setLangState(s); } catch { /* private mode */ }
  }, []);
  const setLang = (l: Lang) => { setLangState(l); try { localStorage.setItem("mf_lang", l); } catch { /* ignore */ } };
  return <LangCtx.Provider value={{ lang, setLang }}>{children}</LangCtx.Provider>;
}

export function useReducedMotion() {
  const [r, setR] = useState(false);
  useEffect(() => {
    const m = window.matchMedia("(prefers-reduced-motion: reduce)");
    setR(m.matches);
    const on = () => setR(m.matches);
    m.addEventListener?.("change", on);
    return () => m.removeEventListener?.("change", on);
  }, []);
  return r;
}

const GLYPHS = "ABCDEFGHIJKLMNOPQRSTUVWXYZابتثجحخدذرزسشصضطظعغفقكلمنهوي".split("");

/** Full-bleed canvas: glyph particles drifting upward, linked by brass threads,
 *  leaning gently toward the pointer. Pauses when the tab is hidden. */
export function Constellation() {
  const ref = useRef<HTMLCanvasElement | null>(null);
  const reduced = useReducedMotion();
  useEffect(() => {
    const c = ref.current; if (!c) return;
    const ctx = c.getContext("2d"); if (!ctx) return;
    let w = 0, h = 0, raf = 0, running = true;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const mouse = { x: -9999, y: -9999 };
    type P = { x: number; y: number; vx: number; vy: number; g: string; s: number; a: number; hue: number };
    let ps: P[] = [];
    function resize() {
      w = c!.clientWidth; h = c!.clientHeight;
      c!.width = w * dpr; c!.height = h * dpr; ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
      const n = Math.round(Math.min(90, Math.max(34, (w * h) / 16000)));
      ps = Array.from({ length: n }, () => ({
        x: Math.random() * w, y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.18, vy: -0.12 - Math.random() * 0.32,
        g: GLYPHS[(Math.random() * GLYPHS.length) | 0], s: 11 + Math.random() * 16,
        a: 0.18 + Math.random() * 0.5, hue: Math.random(),
      }));
    }
    function frame() {
      ctx!.clearRect(0, 0, w, h);
      for (let i = 0; i < ps.length; i++) for (let j = i + 1; j < ps.length; j++) {
        const a = ps[i], b = ps[j]; const dx = a.x - b.x, dy = a.y - b.y; const d = dx * dx + dy * dy;
        if (d < 120 * 120) {
          ctx!.strokeStyle = `rgba(214,165,72,${0.16 * (1 - Math.sqrt(d) / 120)})`;
          ctx!.lineWidth = 1; ctx!.beginPath(); ctx!.moveTo(a.x, a.y); ctx!.lineTo(b.x, b.y); ctx!.stroke();
        }
      }
      for (const p of ps) {
        if (!reduced) {
          const dx = mouse.x - p.x, dy = mouse.y - p.y, d = Math.hypot(dx, dy);
          if (d < 180 && d > 0) { p.vx += (dx / d) * 0.012; p.vy += (dy / d) * 0.012; }
          p.vx *= 0.995; p.x += p.vx; p.y += p.vy;
          if (p.y < -30) { p.y = h + 20; p.x = Math.random() * w; }
          if (p.x < -30) p.x = w + 20;
          if (p.x > w + 30) p.x = -20;
        }
        ctx!.font = `${p.s}px "Newsreader", "IBM Plex Sans Arabic", serif`;
        ctx!.fillStyle = p.hue > 0.72 ? `rgba(196,72,86,${p.a})` : `rgba(236,214,170,${p.a})`;
        ctx!.fillText(p.g, p.x, p.y);
      }
      if (running && !reduced) raf = requestAnimationFrame(frame);
    }
    const onMove = (e: PointerEvent) => { const r = c!.getBoundingClientRect(); mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top; };
    const onVis = () => { running = !document.hidden; if (running && !reduced) { cancelAnimationFrame(raf); raf = requestAnimationFrame(frame); } };
    resize(); frame();
    window.addEventListener("resize", resize); window.addEventListener("pointermove", onMove);
    document.addEventListener("visibilitychange", onVis);
    return () => { running = false; cancelAnimationFrame(raf); window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", onMove); document.removeEventListener("visibilitychange", onVis); };
  }, [reduced]);
  return <canvas ref={ref} aria-hidden="true" className="gt-canvas" />;
}

export function LangSwitch() {
  const { lang, setLang } = useLang();
  return (
    <div className="gt-lang" role="group" aria-label="Language / اللغة">
      <button aria-pressed={lang === "en"} onClick={() => setLang("en")}>EN</button>
      <button aria-pressed={lang === "ar"} onClick={() => setLang("ar")} lang="ar">عربي</button>
    </div>
  );
}

/** Dark stage shared by the entrance, owner sign-in and guest sign-in. */
export function Stage({ children, bgClip = 0 }: { children: ReactNode; bgClip?: number }) {
  const { lang } = useLang();
  return (
    <div className="gt-stage" dir={lang === "ar" ? "rtl" : "ltr"} lang={lang}>
      <style>{GATE_CSS}</style>
      <BgVideo clip={bgClip} dim={0.58} />
      <div className="gt-aurora" aria-hidden="true"><i /><i /><i /></div>
      <Constellation />
      <div className="gt-grain" aria-hidden="true" />
      <div className="gt-top"><a href="/" className="gt-home"><img src="/brand/mf-logo.webp" alt="" width={29} height={30} />
        <span>Mr. Fluency</span></a><LangSwitch /></div>
      <div className="gt-content">{children}</div>
    </div>
  );
}

export function Field({ label, ...p }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="gt-field"><span>{label}</span><input {...p} /></label>
  );
}
