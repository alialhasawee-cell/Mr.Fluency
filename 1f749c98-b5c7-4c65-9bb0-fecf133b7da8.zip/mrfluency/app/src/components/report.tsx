import { Link } from "@tanstack/react-router";
import { Staircase, LevelChip } from "./brand";
import { LEVEL_INFO, PROFILE } from "../lib/courses";

export function Report({ r }: { r: any }) {
  const info = LEVEL_INFO[r.level] ?? { name: "", blurb: "", can: "", hours: "" };
  const wa = "https://wa.me/" + PROFILE.phone.replace(/[^0-9]/g, "") + "?text=" +
    encodeURIComponent("Hello Mr. Fluency. I took the placement test and my result is " +
      r.level + " (" + r.percent + "%). I would like to ask about " + r.course + ".");
  return (
    <div>
      <div className="mf-card p-8 text-center">
        <div className="mf-label">Placement result · {r.name}</div>
        <div className="mt-2 text-[4rem] leading-none"
          style={{ fontFamily: "var(--display)", color: "var(--l-" + String(r.level).toLowerCase() + ")" }}>
          {r.level}
        </div>
        <div className="mt-1 text-xl" style={{ fontFamily: "var(--display)", color: "var(--ink-2)" }}>{r.levelName}</div>
        <p className="mf-prose mx-auto mt-3 text-sm">{info.blurb}</p>
        <div className="mt-6"><Staircase current={r.level} /></div>
        <div className="mf-mono mt-5 flex flex-wrap justify-center gap-5 text-[13px]" style={{ color: "var(--ink-2)" }}>
          <span><b>{r.percent}%</b> overall</span>
          <span><b>{r.correct}/{r.items}</b> correct</span>
          <span><b>{r.minutes}</b> min</span>
          <span>attempt <b>{r.attemptNo}</b></span>
        </div>
        <p className="mt-3 text-xs" style={{ color: "var(--ink-3)" }}>{r.completion}</p>
      </div>

      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <div className="mf-card p-6">
          <h2 className="text-xl">Recommended programme</h2>
          <p className="mt-3 text-base font-semibold" style={{ color: "var(--brass)" }}>{r.course}</p>
          <p className="mt-2 text-sm" style={{ color: "var(--ink-2)" }}>{r.courseAim}</p>
          {r.entry ? <div className="mf-note mt-4">Start at <b>{r.entry}</b><br />{r.entryFocus}</div> : null}
          {r.note ? <p className="mt-3 text-sm" style={{ color: "var(--l-c1)" }}>{r.note}</p> : null}
          <p className="mt-4 text-sm" style={{ color: "var(--ink-2)" }}>
            Remaining pathway: <b style={{ color: "var(--ink)" }}>{r.remaining} modules · {r.hours} guided hours</b>
          </p>
          {r.band ? (
            <p className="mt-2 text-sm" style={{ color: "var(--ink-2)" }}>
              Indicative IELTS band at this level: <b style={{ color: "var(--ink)" }}>{r.band}</b>
            </p>
          ) : null}
        </div>

        <div className="mf-card p-6">
          <h2 className="text-xl">Skill breakdown</h2>
          <div className="mt-4 grid gap-2.5">
            {["Grammar", "Vocabulary", "Reading"].map((k) => {
              const s = r.skills?.[k];
              if (!s) return null;
              const p = s.t ? Math.round((s.c / s.t) * 100) : 0;
              return (
                <div key={k} className="flex items-center gap-3">
                  <span className="w-24 flex-none text-sm font-semibold">{k}</span>
                  <span className="mf-bar flex-1"><i style={{ width: p + "%" }} /></span>
                  <span className="mf-mono w-12 text-right text-xs" style={{ color: "var(--ink-2)" }}>{s.c}/{s.t}</span>
                </div>
              );
            })}
            {["Listening", "Writing", "Speaking"].map((k) => (
              <div key={k} className="flex items-center gap-3">
                <span className="w-24 flex-none text-sm" style={{ color: "var(--ink-3)" }}>{k}</span>
                <span className="text-xs" style={{ color: "var(--ink-3)" }}>Not assessed in this paper</span>
              </div>
            ))}
          </div>

          <h2 className="mt-6 text-xl">Section by section</h2>
          <div className="mt-3 overflow-x-auto">
            <table className="mf-table">
              <thead><tr><th>Level</th><th>Score</th><th>%</th><th>Outcome</th></tr></thead>
              <tbody>
                {(r.blocks ?? []).map((b: any) => (
                  <tr key={b.level}>
                    <td><LevelChip level={b.level} /></td>
                    <td className="mf-mono">{b.correct}/{b.total}</td>
                    <td className="mf-mono">{b.pct}%</td>
                    <td className="text-xs">{b.passed ? "Passed" : "Ceiling"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="mf-card mt-4 p-6">
        <h2 className="text-xl">What you can do at {r.level}</h2>
        <p className="mt-2 text-sm" style={{ color: "var(--ink-2)" }}>{info.can}</p>
        <p className="mt-2 text-xs" style={{ color: "var(--ink-3)" }}>Typical study load: {info.hours}</p>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <a className="cta-test" href={wa} target="_blank" rel="noopener">Send my result on WhatsApp</a>
        <Link to="/courses" className="cta-quiet">See the programme</Link>
      </div>
      <p className="mt-4 text-xs" style={{ color: "var(--ink-3)" }}>
        Individual answers and marking thresholds are not shown. Mr. Fluency can go through them with you.
      </p>
    </div>
  );
}
