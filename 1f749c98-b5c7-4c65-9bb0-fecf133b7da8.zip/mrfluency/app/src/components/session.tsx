import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";

export type SessionUser = {
  id: string; name: string; email: string; role: "owner" | "admin" | "teacher" | "student";
  cefr_level?: string | null; xp?: number; avatar_url?: string | null;
};
type Ctx = { user: SessionUser | null; loading: boolean; refresh: () => Promise<void>; logout: () => Promise<void> };
const SessionCtx = createContext<Ctx>({ user: null, loading: true, refresh: async () => {}, logout: async () => {} });

export function SessionProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const r = await fetch("/api/auth", { credentials: "same-origin" });
      const d = await r.json();
      setUser(d?.user ?? null);
    } catch { setUser(null); } finally { setLoading(false); }
  }, []);

  const logout = useCallback(async () => {
    await fetch("/api/auth", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "logout" }), credentials: "same-origin",
    });
    setUser(null);
    if (typeof window !== "undefined") window.location.href = "/";
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);
  return <SessionCtx.Provider value={{ user, loading, refresh, logout }}>{children}</SessionCtx.Provider>;
}
export const useSession = () => useContext(SessionCtx);

export const api = {
  async get(url: string) {
    const r = await fetch(url, { credentials: "same-origin" });
    return { ok: r.ok, status: r.status, data: await r.json().catch(() => ({})) };
  },
  async post(url: string, body: unknown) {
    const r = await fetch(url, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify(body), credentials: "same-origin",
    });
    return { ok: r.ok, status: r.status, data: await r.json().catch(() => ({})) };
  },
};

export function Spinner({ label = "Loading…" }: { label?: string }) {
  return <p className="mf-prose py-10 text-sm" role="status">{label}</p>;
}
export function ErrorNote({ children, onRetry }: { children: ReactNode; onRetry?: () => void }) {
  return (
    <div className="mf-card p-5" style={{ borderLeft: "3px solid var(--danger)" }}>
      <p className="text-sm" style={{ color: "var(--ink-2)" }}>{children}</p>
      {onRetry ? <button className="cta-quiet mt-4" onClick={onRetry}>Try again</button> : null}
    </div>
  );
}
export function EmptyNote({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="mf-card p-8 text-center">
      <h3 className="text-xl">{title}</h3>
      {children ? <p className="mf-prose mx-auto mt-2 text-sm">{children}</p> : null}
    </div>
  );
}
