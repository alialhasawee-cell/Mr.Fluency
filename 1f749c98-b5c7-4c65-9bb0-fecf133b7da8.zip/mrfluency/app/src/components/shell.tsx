import { Link, useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { PROFILE } from "../lib/courses";
import { Mark, LogoLockup, ContactRow } from "./brand";
import { useSession } from "./session";
import { AudioButton } from "./audio-controls";
import { BgVideo, BigArrow } from "./motion";

const NAV = [
  { to: "/academy", label: "Home" },
  { to: "/courses", label: "Courses" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

function clipFor(path: string) {
  let h = 0;
  for (let i = 0; i < path.length; i++) h = (h * 31 + path.charCodeAt(i)) | 0;
  return Math.abs(h);
}

export function Shell({ children }: { children: ReactNode }) {
  const { user, loading, logout } = useSession();
  const staff = user && (user.role === "owner" || user.role === "admin" || user.role === "teacher");
  const path = useRouterState({ select: (st) => st.location.pathname });
  const needsPlacement = !!user && user.role === "student" && !user.cefr_level && !path.startsWith("/placement");
  return (
    <div className="mf relative flex min-h-screen flex-col" style={{ isolation: "isolate" }}>
      <BgVideo fixed clip={clipFor(path)} dim={0.8} />
      <header className="sticky top-0 z-40 border-b"
        style={{ borderColor: "var(--line)", background: "rgba(6,14,34,.88)", backdropFilter: "blur(12px)" }}>
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:px-6">
          <Link to="/academy" className="flex items-center gap-2.5 no-underline" style={{ color: "var(--ink)" }}>
            <Mark size={38} alt="Mr. Fluency" />
            <span className="leading-tight">
              <b className="block text-[17px]" style={{ fontFamily: "var(--display)", fontWeight: 600 }}>Mr. Fluency</b>
              <span className="mf-label hidden sm:block" style={{ marginBottom: 0 }}>Basra · Iraq</span>
            </span>
          </Link>
          <nav className="ml-auto hidden items-center gap-1 md:flex">
            {NAV.map((n) => (
              <Link key={n.to} to={n.to} className="rounded-md px-3 py-2 text-sm font-medium no-underline"
                style={{ color: "var(--ink-2)" }}
                activeProps={{ style: { color: "var(--ink)", background: "var(--surface-2)" } }}>
                {n.label}
              </Link>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2 md:ml-2">
            <AudioButton />
            {loading ? null : user ? (
              <>
                {staff ? (
                  <Link to="/studio" className="rounded-md px-3 py-2 text-sm font-medium no-underline"
                    style={{ color: "var(--ink-2)" }}>Teacher area</Link>
                ) : null}
                <Link to="/dashboard" className="cta-test" style={{ padding: "10px 18px", fontSize: 14 }}>
                  My learning
                </Link>
                <button onClick={logout} className="hidden text-sm sm:block"
                  style={{ background: "none", border: 0, cursor: "pointer", color: "var(--ink-3)" }}>Sign out</button>
              </>
            ) : (
              <>
                <Link to="/guest" search={{ mode: "signin" }} className="hidden rounded-md px-3 py-2 text-sm font-medium no-underline sm:block"
                  style={{ color: "var(--ink-2)" }}>Sign in</Link>
                <Link to="/guest" search={{ mode: "signup" }} className="cta-test" style={{ padding: "10px 18px", fontSize: 14 }}>
                  Create account
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      {needsPlacement ? (
        <div className="relative z-10 mx-auto mt-4 w-full max-w-6xl px-4 sm:px-6">
          <div className="mf-banner flex flex-wrap items-center gap-4">
            <BigArrow dir="right" size={44} />
            <div className="min-w-[220px] flex-1">
              <b style={{ fontSize: 20 }}>Start with your placement test</b>
              <div style={{ color: "var(--ink-2)", fontSize: 16 }}>You can browse freely, but courses unlock only after the placement test.</div>
            </div>
            <Link to="/placement" className="cta-test">Take the placement test</Link>
          </div>
        </div>
      ) : null}
      <main className="relative z-10 flex-1">{children}</main>
      <a href={"https://wa.me/" + PROFILE.phone.replace(/[^0-9]/g, "")} target="_blank" rel="noopener"
        className="mf-wa-fab" aria-label={"Ask " + PROFILE.fullName + " on WhatsApp"}>
        <svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"><path d="M3.5 20.5l1.3-4.2A8.2 8.2 0 1112 20.2a8.4 8.4 0 01-3.9-1z" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" /><path d="M9 9.2c.3 2.6 3.2 5.5 5.8 5.8l1-1.4 1.8 1-.7 1.4c-2.8.8-7.8-3.6-8.4-6.8l1.4-.8 1 1.8z" fill="currentColor" /></svg>
        <span>Questions? Ask Mr. Ali</span>
      </a>

      <footer className="relative z-10 mt-24 border-t" style={{ borderColor: "var(--line)", background: "rgba(10,20,44,.94)" }}>
        <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
          <div className="flex flex-wrap items-start gap-10">
            <div className="min-w-[240px] flex-1">
              <LogoLockup width={148} />
              <p className="mf-prose mt-4 text-sm">
                {PROFILE.title}. Over 14 years teaching English in Basra and beyond.
              </p>
              <p className="mt-4 text-lg" style={{ fontFamily: "var(--display)", fontStyle: "italic", color: "var(--brass)" }}>
                “{PROFILE.quote}”
              </p>
            </div>
            <nav className="flex flex-col gap-2">
              <span className="mf-eyebrow mb-1">Pages</span>
              {NAV.concat([{ to: "/placement", label: "Placement test" }, { to: "/app", label: "Android app" }, { to: "/", label: "Entrance" }]).map((n) => (
                <Link key={n.to} to={n.to} className="text-sm no-underline" style={{ color: "var(--ink-2)" }}>
                  {n.label}
                </Link>
              ))}
            </nav>
          </div>
          <div className="mt-10"><ContactRow /></div>
          <p className="mt-8 text-xs" style={{ color: "var(--ink-3)" }}>
            © {new Date().getFullYear()} Mr. Fluency — {PROFILE.name}. {PROFILE.motto}
          </p>
        </div>
      </footer>
    </div>
  );
}

export function Section({ eyebrow, title, lead, children, tight }: {
  eyebrow?: string; title?: string; lead?: string; children?: ReactNode; tight?: boolean;
}) {
  return (
    <section className={"mx-auto max-w-6xl px-4 sm:px-6 " + (tight ? "py-10" : "py-16 sm:py-20")}>
      {eyebrow ? <div className="mf-eyebrow mb-3">{eyebrow}</div> : null}
      {title ? <h2 className="text-3xl sm:text-4xl">{title}</h2> : null}
      {lead ? <p className="mf-prose mt-4 text-base">{lead}</p> : null}
      {children}
    </section>
  );
}
