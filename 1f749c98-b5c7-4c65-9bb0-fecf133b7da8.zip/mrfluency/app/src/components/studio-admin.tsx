import { useCallback, useEffect, useRef, useState } from "react";
import { LevelChip } from "./brand";
import { api } from "./session";
import { Field, Text, Area, Select, Card, Row, Pill, Modal } from "./studio-ui";

const QTYPES = [
  { v: "mcq", l: "Multiple choice (one answer)" }, { v: "multi", l: "Multiple answers" },
  { v: "truefalse", l: "True or false" }, { v: "gap", l: "Fill the gap" },
  { v: "match", l: "Matching" }, { v: "order", l: "Ordering" },
  { v: "writing", l: "Writing (teacher marked)" }, { v: "speaking", l: "Speaking (teacher marked)" },
];
const CEFR = ["A0", "A1", "A2", "B1", "B2", "C1", "C2"].map((v) => ({ v, l: v }));
const SKILLS = ["Grammar", "Vocabulary", "Reading", "Listening", "Writing", "Speaking"].map((v) => ({ v, l: v }));
function safeData(x: any) {
  if (typeof x._raw === "string") { try { return JSON.parse(x._raw); } catch { return {}; } }
  if (typeof x.data === "string") { try { return JSON.parse(x.data); } catch { return {}; } }
  return x.data ?? {};
}

export function Bank({ toast }: { toast: (m: string) => void }) {
  const [qs, setQs] = useState<any[]>([]);
  const [edit, setEdit] = useState<any>(null);
  const load = useCallback(async () => {
    const { data } = await api.get("/api/cms?what=questions");
    setQs(data.questions ?? []);
  }, []);
  useEffect(() => { void load(); }, [load]);

  return (
    <div>
      <Row>
        <h2 className="text-2xl">Question bank</h2>
        <span className="mf-mono text-xs" style={{ color: "var(--ink-3)" }}>{qs.length} questions</span>
        <button className="cta-quiet ml-auto" onClick={() => setEdit({
          type: "mcq", bank: "course", cefr: "A1", skill: "Grammar", points: 1, difficulty: 2, status: "published",
          options: [{ text: "", is_correct: true }, { text: "", is_correct: false },
            { text: "", is_correct: false }, { text: "", is_correct: false }],
        })}>+ New question</button>
      </Row>
      <p className="mf-prose mt-3 text-sm">
        Questions are tagged and reusable: one item can sit in a lesson quiz, a module exam and a
        placement paper without being written twice.
      </p>
      <div className="mt-5 overflow-x-auto">
        <table className="mf-table" style={{ minWidth: 760 }}>
          <thead><tr><th>Question</th><th>Type</th><th>CEFR</th><th>Skill</th><th>Bank</th><th>Pts</th><th></th></tr></thead>
          <tbody>{qs.map((q) => (
            <tr key={q.id}>
              <td className="text-sm">{String(q.prompt).slice(0, 80)}</td>
              <td className="text-xs">{q.type}</td>
              <td>{q.cefr ? <LevelChip level={q.cefr} /> : "-"}</td>
              <td className="text-xs">{q.skill}</td><td className="text-xs">{q.bank}</td>
              <td className="mf-mono">{q.points}</td>
              <td><button className="cta-quiet" style={{ padding: "5px 10px", fontSize: 10 }} onClick={async () => {
                const { data } = await api.get("/api/cms?what=question&id=" + q.id);
                setEdit({ ...data.question, options: data.options ?? [] });
              }}>Edit</button></td>
            </tr>))}
          </tbody>
        </table>
        {!qs.length ? <p className="mf-prose mt-4 text-sm">No questions yet.</p> : null}
      </div>
      {edit ? <QuestionModal q={edit} toast={toast} onClose={() => setEdit(null)}
        onSaved={async () => { setEdit(null); await load(); }} /> : null}
    </div>
  );
}

function QuestionModal({ q, onClose, onSaved, toast }: any) {
  const [x, setX] = useState<any>({ ...q, options: q.options ?? [] });
  const mcqLike = ["mcq", "multi", "truefalse"].includes(x.type);
  const setOpt = (i: number, patch: any) => {
    const o = x.options.map((oo: any) => ({ ...oo }));
    o[i] = { ...o[i], ...patch };
    if (patch.is_correct && x.type !== "multi") o.forEach((oo: any, j: number) => { if (j !== i) oo.is_correct = false; });
    setX({ ...x, options: o });
  };
  return (
    <Modal title={x.id ? "Edit question" : "New question"} wide onClose={onClose} onSave={async () => {
      const { ok } = await api.post("/api/cms", { action: "save_question", question: { ...x, data: safeData(x) } });
      toast(ok ? "Question saved" : "Could not save");
      if (ok) onSaved();
    }}>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Type"><Select value={x.type} onChange={(v) => setX({ ...x, type: v })} options={QTYPES} /></Field>
        <Field label="CEFR"><Select value={x.cefr ?? "A1"} onChange={(v) => setX({ ...x, cefr: v })} options={CEFR} /></Field>
        <Field label="Skill"><Select value={x.skill ?? "Grammar"} onChange={(v) => setX({ ...x, skill: v })} options={SKILLS} /></Field>
        <Field label="Bank"><Select value={x.bank ?? "course"} onChange={(v) => setX({ ...x, bank: v })}
          options={[{ v: "course", l: "Course" }, { v: "placement", l: "Placement" }, { v: "general", l: "General" }]} /></Field>
        <Field label="Topic"><Text value={x.topic} onChange={(v: string) => setX({ ...x, topic: v })} /></Field>
        <Field label="Points"><Text type="number" value={x.points ?? 1} onChange={(v: string) => setX({ ...x, points: v })} /></Field>
      </div>
      <Field label="Question"><Area rows={3} value={x.prompt} onChange={(v: string) => setX({ ...x, prompt: v })} /></Field>
      <Field label="Passage (optional)"><Area rows={3} value={x.passage} onChange={(v: string) => setX({ ...x, passage: v })} /></Field>
      {mcqLike ? (
        <Field label="Answer options" hint={x.type === "multi" ? "Tick every correct answer" : "Tick the one correct answer"}>
          <div className="grid gap-2">
            {x.options.map((o: any, i: number) => (
              <div key={i} className="flex items-center gap-2">
                <input type={x.type === "multi" ? "checkbox" : "radio"} checked={!!o.is_correct}
                  onChange={(e) => setOpt(i, { is_correct: e.target.checked })} />
                <input className="mf-field" value={o.text ?? ""} placeholder={"Option " + "ABCDEF"[i]}
                  onChange={(e) => setOpt(i, { text: e.target.value })} />
                <button className="cta-quiet" style={{ padding: "5px 9px", fontSize: 10 }}
                  onClick={() => setX({ ...x, options: x.options.filter((_: any, j: number) => j !== i) })}>x</button>
              </div>))}
            <button className="cta-quiet" style={{ alignSelf: "flex-start", padding: "6px 12px", fontSize: 11 }}
              onClick={() => setX({ ...x, options: [...x.options, { text: "", is_correct: false }] })}>+ Option</button>
          </div>
        </Field>
      ) : (
        <Field label="Answer data" hint={
          x.type === "gap" ? 'Example: {"answers":[["is"]]}'
          : x.type === "match" ? 'Example: {"left":["cat"],"pairs":[{"left":"cat","right":"animal"}]}'
          : x.type === "order" ? 'Example: {"items":["name","My","is"],"order":["My","name","is"]}'
          : 'Example: {"minWords":40}'}>
          <textarea className="mf-field mf-mono" style={{ fontSize: 12.5 }} rows={6}
            value={typeof x._raw === "string" ? x._raw : JSON.stringify(safeData(x), null, 2)}
            onChange={(e) => setX({ ...x, _raw: e.target.value })} />
        </Field>
      )}
      <Field label="Explanation shown after marking">
        <Area rows={2} value={x.explanation} onChange={(v: string) => setX({ ...x, explanation: v })} /></Field>
    </Modal>
  );
}

export function Students({ toast, isOwner }: { toast: (m: string) => void; isOwner: boolean }) {
  const [rows, setRows] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [detail, setDetail] = useState<any>(null);
  const [courses, setCourses] = useState<any[]>([]);

  const load = useCallback(async (query = "") => {
    const { data } = await api.get("/api/cms?what=students" + (query ? "&q=" + encodeURIComponent(query) : ""));
    setRows(data.students ?? []);
  }, []);
  useEffect(() => {
    void load();
    void api.get("/api/cms?what=courses").then((r) => setCourses(r.data.courses ?? []));
  }, [load]);

  return (
    <div>
      <Row>
        <h2 className="text-2xl">People</h2>
        <input className="mf-field ml-auto" style={{ width: 240 }} placeholder="Search name or email"
          value={q} onChange={(e) => { setQ(e.target.value); void load(e.target.value); }} />
      </Row>
      <div className="mt-5 overflow-x-auto">
        <table className="mf-table" style={{ minWidth: 760 }}>
          <thead><tr><th>Name</th><th>Role</th><th>Status</th><th>Level</th><th>XP</th><th>Joined</th><th></th></tr></thead>
          <tbody>{rows.map((s) => (
            <tr key={s.id}>
              <td><b>{s.name}</b><div className="text-xs" style={{ color: "var(--ink-3)" }}>{s.email}</div></td>
              <td>{isOwner && s.role !== "owner" ? (
                <select className="mf-field" style={{ width: 112, fontSize: 12, padding: "4px 6px" }} value={s.role}
                  onChange={async (e) => {
                    await api.post("/api/cms", { action: "set_user_role", userId: s.id, role: e.target.value });
                    toast("Role updated"); await load(q);
                  }}>
                  <option value="student">student</option><option value="teacher">teacher</option><option value="admin">admin</option>
                </select>) : <Pill>{s.role}</Pill>}</td>
              <td><Pill tone={s.status === "active" ? "ok" : undefined}>{s.status}</Pill></td>
              <td>{s.cefr_level ? <LevelChip level={s.cefr_level} /> : "-"}</td>
              <td className="mf-mono">{s.xp}</td>
              <td className="text-xs">{new Date(s.created_at).toLocaleDateString()}</td>
              <td><button className="cta-quiet" style={{ padding: "5px 10px", fontSize: 10 }} onClick={async () => {
                const { data } = await api.get("/api/cms?what=student&id=" + s.id);
                setDetail(data);
              }}>Open</button></td>
            </tr>))}
          </tbody>
        </table>
        {!rows.length ? <p className="mf-prose mt-4 text-sm">No accounts yet.</p> : null}
      </div>

      {detail ? (
        <Modal title={detail.user.name} wide onClose={() => setDetail(null)}>
          <p className="mf-prose text-sm">
            {detail.user.email} · joined {new Date(detail.user.created_at).toLocaleDateString()}
          </p>
          <div className="mt-5">
            <h4 className="text-lg">Enrol on a course</h4>
            <div className="mt-2"><Row>
              <select className="mf-field" style={{ width: 260 }} id="enrol-pick" defaultValue="">
                <option value="">Choose a course...</option>
                {courses.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
              </select>
              <button className="cta-quiet" onClick={async () => {
                const el = document.getElementById("enrol-pick") as HTMLSelectElement | null;
                if (!el?.value) return;
                const { ok } = await api.post("/api/cms", { action: "enroll_student", userId: detail.user.id, courseId: el.value });
                toast(ok ? "Student enrolled" : "Could not enrol");
                const { data } = await api.get("/api/cms?what=student&id=" + detail.user.id);
                setDetail(data);
              }}>Enrol</button>
            </Row></div>
          </div>
          <Section title="Courses" rows={detail.enrollments} render={(e: any) => `${e.title} - ${e.progress_pct}% (${e.status})`} />
          <Section title="Placement history" rows={detail.placements} render={(p: any) => {
            let r: any = null;
            try { r = p.result ? JSON.parse(p.result) : null; } catch { r = null; }
            return `Attempt ${p.attempt_no}: ${r ? r.level + " (" + r.percent + "%)" : p.status}`;
          }} />
          <Section title="Assessments" rows={detail.quizzes} render={(qa: any) => `${qa.title}: ${qa.pct}% ${qa.passed ? "passed" : ""}`} />
          <Section title="Certificates" rows={detail.certificates} render={(c: any) => `${c.code} - ${c.course_title}`} />
          <Section title="Recent lessons" rows={detail.progress} render={(p: any) => `${p.title} - ${p.status}`} />
          {isOwner && detail.user.role !== "owner" ? (
            <button className="cta-quiet mt-6 mr-3" onClick={async () => {
              const { ok, data } = await api.post("/api/cms", { action: "reset_code", userId: detail.user.id });
              if (ok && data?.code) window.prompt("Password reset code (valid 1 hour). Send it to " + detail.user.email + ":", data.code);
              else toast("Could not create a reset code");
            }}>Create password reset code</button>) : null}
          {isOwner && detail.user.role !== "owner" ? (
            <button className="cta-quiet mt-6" style={{ color: "var(--danger)" }} onClick={async () => {
              await api.post("/api/cms", {
                action: "set_user_status", userId: detail.user.id,
                status: detail.user.status === "active" ? "suspended" : "active",
              });
              toast("Account updated"); setDetail(null); await load(q);
            }}>{detail.user.status === "active" ? "Suspend this account" : "Reactivate this account"}</button>) : null}
        </Modal>) : null}
    </div>
  );
}
function Section({ title, rows, render }: any) {
  return (
    <div className="mt-5">
      <h4 className="text-lg">{title}</h4>
      {rows?.length ? (
        <ul className="mt-2 grid list-none gap-1.5 p-0 text-sm" style={{ color: "var(--ink-2)" }}>
          {rows.map((r: any, i: number) => <li key={i}>• {render(r)}</li>)}
        </ul>) : <p className="mt-1 text-sm" style={{ color: "var(--ink-3)" }}>Nothing yet.</p>}
    </div>
  );
}

export function Certs({ toast }: { toast: (m: string) => void }) {
  const [rows, setRows] = useState<any[]>([]);
  const load = useCallback(async () => {
    const { data } = await api.get("/api/cms?what=certificates");
    setRows(data.certificates ?? []);
  }, []);
  useEffect(() => { void load(); }, [load]);
  return (
    <div>
      <h2 className="text-2xl">Certificates</h2>
      <p className="mf-prose mt-2 text-sm">
        Issued automatically when a student completes every published lesson on a course.
        Anyone can check a code at /verify/CODE.
      </p>
      <div className="mt-5 overflow-x-auto">
        <table className="mf-table" style={{ minWidth: 700 }}>
          <thead><tr><th>Code</th><th>Student</th><th>Course</th><th>Score</th><th>Issued</th><th></th></tr></thead>
          <tbody>{rows.map((c) => (
            <tr key={c.code}>
              <td className="mf-mono text-xs">{c.code}</td>
              <td>{c.student_name}</td><td className="text-sm">{c.course_title}</td>
              <td className="mf-mono">{c.score_pct}%</td>
              <td className="text-xs">{new Date(c.issued_at).toLocaleDateString()}</td>
              <td>{c.revoked ? <Pill>revoked</Pill> : (
                <button className="cta-quiet" style={{ padding: "5px 10px", fontSize: 10, color: "var(--danger)" }}
                  onClick={async () => {
                    const reason = prompt("Reason for revoking this certificate?");
                    if (reason === null) return;
                    await api.post("/api/cms", { action: "revoke_certificate", code: c.code, reason });
                    toast("Certificate revoked"); await load();
                  }}>Revoke</button>)}</td>
            </tr>))}
          </tbody>
        </table>
        {!rows.length ? <p className="mf-prose mt-4 text-sm">None issued yet.</p> : null}
      </div>
    </div>
  );
}

const CHUNK = 10 * 1024 * 1024;   // 10 MiB parts: R2 needs equal parts ≥ 5 MiB

/** Upload any file. Small files go in one request; videos and anything over
 *  ~80 MB go up in 10 MB chunks, each retried up to 4 times, so a flaky
 *  connection never restarts a 1 GB upload from zero. */
async function uploadFile(f: File, onProgress: (pct: number) => void, signal: { cancelled: boolean }) {
  if (f.size <= 80 * 1024 * 1024 && !f.type.startsWith("video/")) {
    const form = new FormData(); form.append("file", f); form.append("title", f.name);
    const r = await fetch("/api/media", { method: "POST", body: form, credentials: "same-origin" });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d?.error === "too_large" ? "That file is too large." : "Upload failed.");
    onProgress(100); return d;
  }
  const post = (op: string, body: unknown) => fetch("/api/media?op=" + op, {
    method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify(body),
  }).then(async (r) => ({ ok: r.ok, data: await r.json().catch(() => ({})) as any }));
  const s = await post("start", { name: f.name, type: f.type || "application/octet-stream", size: f.size });
  if (!s.ok) throw new Error(s.data?.error === "too_large" ? "That file is larger than 4 GB." : "Could not start the upload.");
  const { key, uploadId } = s.data;
  const parts: { partNumber: number; etag: string }[] = [];
  const total = Math.ceil(f.size / CHUNK);
  try {
    for (let i = 0; i < total; i++) {
      if (signal.cancelled) throw new Error("Upload cancelled.");
      const blob = f.slice(i * CHUNK, Math.min(f.size, (i + 1) * CHUNK));
      let done = false, lastErr = "";
      for (let attempt = 0; attempt < 4 && !done; attempt++) {
        try {
          const r = await fetch(`/api/media?op=part&key=${encodeURIComponent(key)}&uploadId=${encodeURIComponent(uploadId)}&n=${i + 1}`,
            { method: "POST", credentials: "same-origin", body: blob });
          const d: any = await r.json().catch(() => ({}));
          if (r.ok && d?.etag) { parts.push({ partNumber: d.partNumber, etag: d.etag }); done = true; }
          else lastErr = d?.error ?? "HTTP " + r.status;
        } catch (e) { lastErr = String(e); }
        if (!done) await new Promise((res) => setTimeout(res, 1200 * (attempt + 1)));
      }
      if (!done) throw new Error(`Part ${i + 1} of ${total} failed (${lastErr}). Check your connection and try again.`);
      onProgress(Math.round(((i + 1) / total) * 97));
    }
    let fin = await post("finish", { key, uploadId, parts, title: f.name, type: f.type, size: f.size });
    if (!fin.ok) fin = await post("finish", { key, uploadId, parts, title: f.name, type: f.type, size: f.size });
    if (!fin.ok) throw new Error("The file uploaded but could not be saved. Please try again.");
    onProgress(100); return fin.data;
  } catch (e) {
    await post("abort", { key, uploadId }).catch(() => {});
    throw e;
  }
}

export function MediaTab({ toast }: { toast: (m: string) => void }) {
  const [rows, setRows] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);
  const [pct, setPct] = useState(0);
  const [err, setErr] = useState("");
  const [preview, setPreview] = useState<any>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const cancel = useRef({ cancelled: false });
  const load = useCallback(async () => {
    const { data } = await api.get("/api/media");
    setRows(data.media ?? []);
  }, []);
  useEffect(() => { void load(); }, [load]);

  async function upload() {
    const f = fileRef.current?.files?.[0];
    if (!f) { toast("Choose a file first"); return; }
    setBusy(true); setPct(0); setErr(""); cancel.current = { cancelled: false };
    try {
      await uploadFile(f, setPct, cancel.current);
      toast("Uploaded " + f.name);
      if (fileRef.current) fileRef.current.value = "";
      await load();
    } catch (e) { setErr((e as Error).message); }
    setBusy(false);
  }
  async function remove(m: any) {
    if (!window.confirm(`Delete "${m.title}"? Any lesson using this file will show an empty video slot.`)) return;
    const { ok } = await api.post("/api/media?op=delete", { id: m.id });
    toast(ok ? "Deleted" : "Could not delete"); await load();
  }
  const mb = (b: number) => (b >= 1048576 ? (b / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(b / 1024)) + " KB");
  return (
    <div>
      <Row>
        <h2 className="text-2xl">Media library</h2>
        <input ref={fileRef} type="file" className="ml-auto text-sm" accept="image/*,audio/*,video/*,application/pdf" disabled={busy} />
        <button className="cta-test" onClick={upload} disabled={busy}>{busy ? `Uploading ${pct}%` : "Upload"}</button>
        {busy ? <button className="cta-quiet" onClick={() => { cancel.current.cancelled = true; }}>Cancel</button> : null}
      </Row>
      {busy ? (
        <div className="mf-bar mt-4" style={{ maxWidth: 520 }} role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
          <i style={{ width: pct + "%", transition: "width .3s" }} />
        </div>) : null}
      {err ? <p className="mt-3 text-sm" role="alert" style={{ color: "var(--danger)" }}>{err}</p> : null}
      <p className="mf-prose mt-3 text-sm">
        Upload lesson videos (MP4 works everywhere; up to 4 GB each, sent in 10 MB pieces that retry on a weak
        connection), images, audio and PDFs. Then open a lesson in <b>Courses</b>, add a <b>Video</b> block,
        and paste the file address. Videos and PDFs can only be opened by signed-in accounts.
      </p>
      <div className="mt-5 grid gap-2">
        {rows.map((m) => (
          <Card key={m.id}>
            <Row>
              <Pill>{m.kind}</Pill>
              <b className="text-sm">{m.title}</b>
              <span className="mf-mono ml-auto text-xs" style={{ color: "var(--ink-3)" }}>{mb(m.bytes ?? 0)}</span>
              <input className="mf-field mf-mono" style={{ width: 250, fontSize: 11 }} readOnly value={m.url}
                onFocus={(e) => e.currentTarget.select()} aria-label="File address" />
              <button className="cta-quiet" style={{ padding: "6px 12px", fontSize: 12 }}
                onClick={() => { void navigator.clipboard?.writeText(m.url); toast("Address copied"); }}>Copy</button>
              {m.kind === "video" || m.kind === "image" ? (
                <button className="cta-quiet" style={{ padding: "6px 12px", fontSize: 12 }}
                  onClick={() => setPreview(preview?.id === m.id ? null : m)}>{preview?.id === m.id ? "Hide" : "Preview"}</button>) : null}
              <button className="cta-quiet" style={{ padding: "6px 12px", fontSize: 12, color: "var(--danger)" }} onClick={() => remove(m)}>Delete</button>
            </Row>
            {preview?.id === m.id ? (
              m.kind === "video"
                ? <video src={m.url} controls preload="metadata" style={{ width: "100%", maxWidth: 560, marginTop: 12, borderRadius: 10 }} />
                : <img src={m.url} alt="" style={{ maxWidth: 360, marginTop: 12, borderRadius: 10 }} />
            ) : null}
          </Card>))}
        {!rows.length ? <p className="mf-prose text-sm">No files yet. Upload your first lesson video above.</p> : null}
      </div>
    </div>
  );
}

export function Announce({ toast }: { toast: (m: string) => void }) {
  const [a, setA] = useState({ title: "", body: "" });
  return (
    <div style={{ maxWidth: 640 }}>
      <h2 className="text-2xl">Announcements</h2>
      <p className="mf-prose mt-2 text-sm">
        Sends a notice to every student. It appears on their dashboard immediately.
      </p>
      <div className="mt-5">
        <Field label="Title"><Text value={a.title} onChange={(v: string) => setA({ ...a, title: v })} /></Field>
        <Field label="Message"><Area rows={5} value={a.body} onChange={(v: string) => setA({ ...a, body: v })} /></Field>
        <button className="cta-test" onClick={async () => {
          if (!a.title.trim()) { toast("A title is required"); return; }
          const { ok, data } = await api.post("/api/cms", { action: "announce", ...a });
          toast(ok ? `Sent to ${data.sent} students` : "Could not send");
          if (ok) setA({ title: "", body: "" });
        }}>Send announcement</button>
      </div>
    </div>
  );
}
