/** Pronunciation and read-aloud, using the browser's own speech engine.
 *
 *  Why not audio files: every lesson needs a voice for vocabulary, dialogue
 *  and the "teacher reads" listening scripts. Recording ~290 lessons is not
 *  practical, and SpeechSynthesis is free, works offline, needs no licence and
 *  already ships English and Arabic voices. Nothing here ever plays on its
 *  own — every call below originates in a click.
 */
import { useCallback, useEffect, useRef, useState } from "react";

export type Voice = SpeechSynthesisVoice;
/** Announce speaking so the background music can duck. Kept as a DOM event so
 *  speech.ts stays free of any dependency on the audio layer. */
function announce(on: boolean) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(on ? "mf-speech-start" : "mf-speech-end"));
}

const synth = (): SpeechSynthesis | null =>
  typeof window === "undefined" ? null : window.speechSynthesis ?? null;

/** Emoji, flags and answer blanks should not be read aloud. */
export function stripForSpeech(text: string): string {
  return (text ?? "")
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE00}-\u{FE0F}\u{1F1E6}-\u{1F1FF}\u{200D}]/gu, " ")
    .replace(/_{2,}/g, " blank ")
    .replace(/\s{2,}/g, " ")
    .trim();
}

export function useVoices() {
  const [voices, setVoices] = useState<Voice[]>([]);
  useEffect(() => {
    const s = synth();
    if (!s) return;
    const load = () => setVoices(s.getVoices());
    load();
    s.addEventListener("voiceschanged", load);
    return () => s.removeEventListener("voiceschanged", load);
  }, []);
  return voices;
}

/** Prefer a natural-sounding voice; voiceIndex picks a different speaker. */
export function pickVoice(voices: Voice[], lang: string, index = 0): Voice | null {
  const want = lang.toLowerCase().slice(0, 2);
  const matching = voices.filter((v) => v.lang.toLowerCase().startsWith(want));
  if (!matching.length) return null;
  const ranked = [...matching].sort((a, b) => {
    const score = (v: Voice) =>
      (/natural|neural|enhanced|premium/i.test(v.name) ? 2 : 0) + (v.localService ? 1 : 0);
    return score(b) - score(a);
  });
  return ranked[index % ranked.length] ?? ranked[0];
}

export type SpeakOpts = { lang?: string; rate?: number; voiceIndex?: number; onEnd?: () => void };

/** One shared speaking channel: a new utterance stops the previous one, so two
 *  blocks can never talk over each other. */
export function useSpeech() {
  const voices = useVoices();
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const cancelled = useRef(false);
  const supported = typeof window !== "undefined" && !!window.speechSynthesis;

  const stop = useCallback(() => {
    cancelled.current = true;
    synth()?.cancel();
    setSpeakingId(null);
    announce(false);
  }, []);

  useEffect(() => () => { synth()?.cancel(); }, []);

  const speak = useCallback((text: string, id: string, opts: SpeakOpts = {}) => {
    const s = synth();
    if (!s || !text?.trim()) return;
    s.cancel();
    cancelled.current = false;
    const u = new SpeechSynthesisUtterance(stripForSpeech(text));
    u.lang = opts.lang ?? "en-GB";
    u.rate = opts.rate ?? 0.95;
    const v = pickVoice(voices, u.lang, opts.voiceIndex ?? 0);
    if (v) u.voice = v;
    u.onend = () => { setSpeakingId(null); announce(false); opts.onEnd?.(); };
    u.onerror = () => { setSpeakingId(null); announce(false); };
    setSpeakingId(id);
    announce(true);
    s.speak(u);
  }, [voices]);

  /** Speak lines in turn, each in its own voice — what makes a dialogue sound
   *  like two people rather than one narrator. */
  const speakSequence = useCallback((
    parts: { text: string; voiceIndex?: number; lang?: string }[],
    id: string,
    opts: { rate?: number; onStep?: (i: number) => void; onEnd?: () => void } = {},
  ) => {
    const s = synth();
    if (!s || !parts.length) return;
    s.cancel();
    cancelled.current = false;
    setSpeakingId(id);
    announce(true);
    let i = 0;
    const next = () => {
      if (cancelled.current) { setSpeakingId(null); announce(false); return; }
      if (i >= parts.length) { setSpeakingId(null); announce(false); opts.onEnd?.(); return; }
      const p = parts[i];
      opts.onStep?.(i);
      const u = new SpeechSynthesisUtterance(stripForSpeech(p.text));
      u.lang = p.lang ?? "en-GB";
      u.rate = opts.rate ?? 0.95;
      const v = pickVoice(voices, u.lang, p.voiceIndex ?? 0);
      if (v) u.voice = v;
      u.onend = () => { i += 1; next(); };
      u.onerror = () => { i += 1; next(); };
      s.speak(u);
    };
    next();
  }, [voices]);

  return { supported, speak, speakSequence, stop, speakingId, voices };
}
