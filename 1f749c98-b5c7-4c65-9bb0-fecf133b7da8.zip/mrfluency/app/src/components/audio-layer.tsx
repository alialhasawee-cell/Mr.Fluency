/** Part 7 — background music and Motivation One.
 *
 *  Hard rule: nothing here plays on load, ever. Music starts only after the
 *  learner turns it on, and that choice is remembered. Motivation One speaks
 *  only on a real achievement, at most once per session, and always shows its
 *  Arabic and English text so it works with the sound off.
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useSpeech } from "./speech";

const FADE_MS = 800;
const LS = { music: "mf_audio_music", vol: "mf_audio_vol", motive: "mf_audio_motivation", mute: "mf_audio_mute" };

type Clip = { id: string; theme: string; ar: string; en: string; file?: string };
type Track = { id: string; title: string; file: string; loopStart?: number; loopEnd?: number };
type Manifest = { music: Track[]; motivation: Clip[]; triggers: Record<string, string[]>; rules?: any };

export type Trigger = "lesson_complete" | "module_complete" | "quiz_passed" | "streak_milestone" | "return_after_gap";

type Ctx = {
  ready: boolean; muted: boolean; setMuted: (v: boolean) => void;
  musicOn: boolean; setMusicOn: (v: boolean) => void;
  volume: number; setVolume: (v: number) => void;
  motivationOn: boolean; setMotivationOn: (v: boolean) => void;
  tracks: Track[]; trackId: string | null; setTrackId: (id: string) => void;
  celebrate: (t: Trigger) => void;
  duck: (on: boolean) => void;
};
const AudioCtx = createContext<Ctx | null>(null);
export const useAudioLayer = () => useContext(AudioCtx);

function read(key: string, fallback: string) {
  try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; }
}
function write(key: string, val: string) { try { localStorage.setItem(key, val); } catch { /* private mode */ } }

export function AudioLayerProvider({ children }: { children: ReactNode }) {
  const [manifest, setManifest] = useState<Manifest | null>(null);
  const [musicOn, setMusicOnRaw] = useState(false);
  const [muted, setMutedRaw] = useState(false);
  const [motivationOn, setMotivationOnRaw] = useState(true);
  const [volume, setVolumeRaw] = useState(0.25);
  const [trackId, setTrackIdRaw] = useState<string | null>(null);
  const [toast, setToast] = useState<Clip | null>(null);
  const el = useRef<HTMLAudioElement | null>(null);
  const fadeTimer = useRef<number | null>(null);
  const ducked = useRef(false);
  const firedThisSession = useRef(0);
  const duckRef = useRef<((on: boolean) => void) | null>(null);
  const { speak } = useSpeech();

  // Preferences are read after mount so the server render stays identical.
  useEffect(() => {
    setMusicOnRaw(read(LS.music, "0") === "1");
    setMutedRaw(read(LS.mute, "0") === "1");
    setMotivationOnRaw(read(LS.motive, "1") === "1");
    const v = parseFloat(read(LS.vol, "0.25"));
    if (!Number.isNaN(v)) setVolumeRaw(Math.min(1, Math.max(0, v)));
  }, []);

  // The manifest is fetched lazily — only once the learner wants audio.
  useEffect(() => {
    if (manifest || (!musicOn && !motivationOn)) return;
    let live = true;
    fetch("/brand/audio/manifest.json")
      .then((r) => (r.ok ? r.json() : null))
      .then((m) => { if (live && m) setManifest(m); })
      .catch(() => { /* audio is optional; the site works without it */ });
    return () => { live = false; };
  }, [musicOn, motivationOn, manifest]);

  const tracks = manifest?.music ?? [];
  const current = useMemo(
    () => tracks.find((t) => t.id === trackId) ?? tracks[0] ?? null, [tracks, trackId]);

  const fadeTo = useCallback((target: number, done?: () => void) => {
    const a = el.current;
    if (!a) return;
    if (fadeTimer.current) window.clearInterval(fadeTimer.current);
    const from = a.volume;
    const steps = Math.max(1, Math.round(FADE_MS / 40));
    let i = 0;
    fadeTimer.current = window.setInterval(() => {
      i += 1;
      a.volume = Math.min(1, Math.max(0, from + (target - from) * (i / steps)));
      if (i >= steps) {
        if (fadeTimer.current) window.clearInterval(fadeTimer.current);
        fadeTimer.current = null;
        done?.();
      }
    }, 40);
  }, []);

  const effectiveVolume = muted ? 0 : ducked.current ? volume * 0.18 : volume;

  // Start and stop music. Never called during render, never on first paint.
  useEffect(() => {
    const a = el.current;
    if (!a || !current) return;
    if (musicOn && !muted) {
      if (a.src !== new URL(current.file, window.location.origin).href) a.src = current.file;
      a.loop = true;
      a.volume = 0;
      a.play().then(() => fadeTo(effectiveVolume)).catch(() => {
        // A browser refused playback (no gesture yet) — fall back to off
        // rather than pretending it is playing.
        setMusicOnRaw(false); write(LS.music, "0");
      });
    } else if (!a.paused) {
      fadeTo(0, () => a.pause());
    }
  }, [musicOn, muted, current, fadeTo]);

  useEffect(() => {
    const a = el.current;
    if (a && !a.paused) fadeTo(effectiveVolume);
  }, [volume, muted, fadeTo]);

  // Pause while the tab is hidden; resume only if it was playing.
  useEffect(() => {
    function onVis() {
      const a = el.current;
      if (!a) return;
      if (document.hidden) { if (!a.paused) a.pause(); }
      else if (musicOn && !muted) a.play().catch(() => {});
    }
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [musicOn, muted]);

  // Pronunciation and listening pull the music down while they play.
  useEffect(() => {
    const down = () => duckRef.current?.(true);
    const up = () => duckRef.current?.(false);
    window.addEventListener("mf-speech-start", down);
    window.addEventListener("mf-speech-end", up);
    return () => {
      window.removeEventListener("mf-speech-start", down);
      window.removeEventListener("mf-speech-end", up);
    };
  }, []);

  /** Other audio (a dialogue, a listening script) pulls the music down. */
  const duck = useCallback((on: boolean) => {
    ducked.current = on;
    const a = el.current;
    if (a && !a.paused) fadeTo(muted ? 0 : on ? volume * 0.18 : volume);
  }, [fadeTo, muted, volume]);

  useEffect(() => { duckRef.current = duck; }, [duck]);

  const setMusicOn = useCallback((v: boolean) => { setMusicOnRaw(v); write(LS.music, v ? "1" : "0"); }, []);
  const setMuted = useCallback((v: boolean) => { setMutedRaw(v); write(LS.mute, v ? "1" : "0"); }, []);
  const setMotivationOn = useCallback((v: boolean) => { setMotivationOnRaw(v); write(LS.motive, v ? "1" : "0"); }, []);
  const setVolume = useCallback((v: number) => { setVolumeRaw(v); write(LS.vol, String(v)); }, []);
  const setTrackId = useCallback((id: string) => setTrackIdRaw(id), []);

  /** Motivation One. Text always; voice only if sound is allowed. */
  const celebrate = useCallback((t: Trigger) => {
    if (!motivationOn) return;
    const max = manifest?.rules?.maxMotivationPerSession ?? 1;
    if (firedThisSession.current >= max) return;
    const clips = manifest?.motivation ?? [];
    if (!clips.length) return;
    const themes = manifest?.triggers?.[t] ?? [];
    const pool = clips.filter((c) => themes.includes(c.theme));
    const clip = (pool.length ? pool : clips)[Math.floor(Math.random() * (pool.length ? pool.length : clips.length))];
    firedThisSession.current += 1;
    setToast(clip);
    window.setTimeout(() => setToast(null), 9000);
    if (muted) return;
    duck(true);
    const restore = () => duck(false);
    if (clip.file) {
      const a = new Audio(clip.file);
      a.volume = 0.9;
      a.onended = restore; a.onerror = restore;
      a.play().catch(restore);
    } else {
      // No recording supplied: speak the two lines instead.
      speak(clip.en, "motivation-" + clip.id, { lang: "en-GB", rate: 0.95, onEnd: restore });
    }
  }, [manifest, motivationOn, muted, duck, speak]);

  const value: Ctx = {
    ready: !!manifest, muted, setMuted, musicOn, setMusicOn, volume, setVolume,
    motivationOn, setMotivationOn, tracks, trackId: current?.id ?? null, setTrackId, celebrate, duck,
  };

  return (
    <AudioCtx.Provider value={value}>
      {children}
      {/* No autoplay attribute, no preload: the element is inert until asked. */}
      <audio ref={el} preload="none" aria-hidden="true" />
      {toast ? <MotivationToast clip={toast} onClose={() => setToast(null)} /> : null}
    </AudioCtx.Provider>
  );
}

function MotivationToast({ clip, onClose }: { clip: Clip; onClose: () => void }) {
  return (
    <div role="status" aria-live="polite"
      className="fixed left-1/2 z-50 w-[min(92vw,420px)] -translate-x-1/2 rounded-xl p-4 shadow-lg"
      style={{ bottom: 22, background: "var(--surface)", border: "1px solid var(--line)", borderLeft: "3px solid var(--brass)" }}>
      <p dir="rtl" lang="ar" className="m-0 text-right text-[17px]" style={{ fontFamily: "system-ui, sans-serif" }}>{clip.ar}</p>
      <p className="m-0 mt-1.5 text-[15px]" style={{ color: "var(--ink-2)" }}>{clip.en}</p>
      <button type="button" onClick={onClose} aria-label="Dismiss"
        className="absolute right-2 top-2 text-xs"
        style={{ background: "none", border: 0, color: "var(--ink-3)", cursor: "pointer" }}>&times;</button>
    </div>);
}
