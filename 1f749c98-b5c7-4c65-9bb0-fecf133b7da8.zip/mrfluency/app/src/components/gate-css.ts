// Styles for the entrance stage (see gate.tsx).
export const GATE_CSS = `
.gt-stage{position:relative;min-height:100vh;min-height:100dvh;overflow:hidden;background:#060E22;color:#FFFFFF;
  font-family:"Public Sans","IBM Plex Sans Arabic",system-ui,sans-serif;isolation:isolate}
.gt-stage[lang=ar]{font-family:"IBM Plex Sans Arabic","Public Sans",system-ui,sans-serif}
.gt-canvas{position:absolute;inset:0;width:100%;height:100%;z-index:0}
.gt-aurora{position:absolute;inset:-20%;z-index:0;filter:blur(70px);opacity:.38;mix-blend-mode:screen}
.gt-aurora i{position:absolute;border-radius:50%;animation:gtFloat 18s ease-in-out infinite alternate}
.gt-aurora i:nth-child(1){width:46vw;height:46vw;left:8%;top:18%;background:radial-gradient(circle,#2563EB 0,transparent 65%)}
.gt-aurora i:nth-child(2){width:40vw;height:40vw;right:6%;top:30%;background:radial-gradient(circle,#F5B800 0,transparent 62%);animation-duration:22s;opacity:.55}
.gt-aurora i:nth-child(3){width:34vw;height:34vw;left:38%;bottom:0;background:radial-gradient(circle,#7C3AED 0,transparent 65%);animation-duration:26s;opacity:.5}
@keyframes gtFloat{0%{transform:translate(0,0) scale(1)}50%{transform:translate(4vw,-3vh) scale(1.12)}100%{transform:translate(-3vw,4vh) scale(.94)}}
.gt-grain{position:absolute;inset:0;z-index:1;pointer-events:none;opacity:.07;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence baseFrequency='.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='160' height='160' filter='url(%23n)'/%3E%3C/svg%3E")}
.gt-top{position:relative;z-index:3;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:16px clamp(16px,4vw,40px)}
.gt-home{display:flex;align-items:center;gap:10px;color:#FFFFFF;text-decoration:none;font-family:"Newsreader",serif;font-weight:600;font-size:18px}
.gt-lang{display:flex;padding:3px;border-radius:999px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.14)}
.gt-lang button{all:unset;cursor:pointer;padding:6px 14px;border-radius:999px;font-size:13px;font-weight:600;color:#E6ECF7}
.gt-lang button[aria-pressed=true]{background:#FFFFFF;color:#1B1917}
.gt-lang button:focus-visible,.gt-card:focus-visible,.gt-btn:focus-visible,.gt-link:focus-visible{outline:2px solid #FFD54A;outline-offset:3px}
.gt-content{position:relative;z-index:2;padding:0 clamp(16px,4vw,40px) 56px}
.gt-eyebrow{font-family:"IBM Plex Mono",monospace;font-size:14px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;color:#FFD54A}
.gt-stage[lang=ar] .gt-eyebrow{letter-spacing:0;font-family:inherit;font-size:14px}
.gt-h1{font-family:"Public Sans",sans-serif;font-weight:900;line-height:1.02;letter-spacing:-.03em;margin:0;font-size:clamp(2.8rem,8vw,6.4rem);text-shadow:0 8px 40px rgba(0,0,0,.6)}
.gt-stage[lang=ar] .gt-h1{font-family:"IBM Plex Sans Arabic",sans-serif;font-weight:700;letter-spacing:0;line-height:1.2}
.gt-h1 .w{display:inline-block;opacity:0;transform:translateY(.5em) rotate(4deg);filter:blur(8px);animation:gtWord .9s cubic-bezier(.2,.8,.2,1) forwards}
@keyframes gtWord{to{opacity:1;transform:none;filter:none}}
.gt-gold{background:linear-gradient(100deg,#FFE58A 0%,#F5B800 40%,#FFF3C4 55%,#F59E0B 80%);-webkit-background-clip:text;background-clip:text;color:transparent;
  background-size:220% 100%;animation:gtShine 6s linear infinite}
.gt-h1 .w.gt-gold{animation:gtWord .9s cubic-bezier(.2,.8,.2,1) forwards,gtShine 6s linear 1s infinite}
@keyframes gtShine{to{background-position:-220% 0}}
.gt-lead{max-width:44ch;color:#FFFFFF;font-size:clamp(1.15rem,2vw,1.45rem);text-shadow:0 2px 16px rgba(0,0,0,.7);line-height:1.6;margin:18px auto 0}
.gt-fade{opacity:0;animation:gtFade .9s ease forwards}
@keyframes gtFade{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
.gt-cards{display:grid;gap:22px;grid-template-columns:repeat(auto-fit,minmax(min(100%,280px),1fr));max-width:1080px;margin:40px auto 0}
.gt-card{position:relative;display:block;text-align:start;text-decoration:none;color:inherit;border-radius:22px;padding:28px 26px 24px;
  background:linear-gradient(160deg,rgba(14,26,56,.82),rgba(6,14,34,.7));border:1px solid rgba(255,255,255,.2);
  backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);transition:transform .35s cubic-bezier(.2,.8,.2,1),border-color .35s,box-shadow .35s;
  transform-style:preserve-3d;cursor:pointer;overflow:hidden}
.gt-card::before{content:"";position:absolute;inset:-1px;border-radius:inherit;padding:1px;opacity:0;transition:opacity .35s;
  background:conic-gradient(from var(--gt-a,0deg),#FFD54A,#2563EB,#FFE58A,#FFD54A);
  -webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask-composite:exclude;animation:gtSpin 4s linear infinite}
@property --gt-a{syntax:"<angle>";inherits:false;initial-value:0deg}
@keyframes gtSpin{to{--gt-a:360deg}}
.gt-card:hover,.gt-card:focus-visible{transform:translateY(-6px);box-shadow:0 30px 60px -20px rgba(0,0,0,.7),0 0 0 1px rgba(255,213,74,.2)}
.gt-card:hover::before,.gt-card:focus-visible::before{opacity:1}
.gt-card .glow{position:absolute;width:260px;height:260px;border-radius:50%;pointer-events:none;opacity:0;transition:opacity .3s;
  background:radial-gradient(circle,rgba(255,213,74,.28),transparent 60%);transform:translate(-50%,-50%);left:var(--mx,50%);top:var(--my,50%)}
.gt-card:hover .glow{opacity:1}
.gt-ico{width:58px;height:58px;border-radius:16px;display:grid;place-items:center;margin-bottom:18px}
.gt-card h2{font-family:"Public Sans",sans-serif;font-size:2rem;font-weight:900;margin:0}
.gt-stage[lang=ar] .gt-card h2{font-family:inherit;font-weight:700;font-size:1.6rem}
.gt-card p{color:#E6ECF7;font-size:1.05rem;line-height:1.55;margin:8px 0 18px}
.gt-go{display:inline-flex;align-items:center;gap:8px;font-weight:600;font-size:.95rem;color:#FFE58A}
.gt-go svg{transition:transform .3s}.gt-card:hover .gt-go svg{transform:translateX(5px)}
.gt-stage[dir=rtl] .gt-go svg{transform:scaleX(-1)}.gt-stage[dir=rtl] .gt-card:hover .gt-go svg{transform:scaleX(-1) translateX(5px)}
.gt-marquee{position:relative;z-index:2;margin:52px calc(-1*clamp(16px,4vw,40px)) 0;overflow:hidden;
  mask-image:linear-gradient(90deg,transparent,#000 12%,#000 88%,transparent);-webkit-mask-image:linear-gradient(90deg,transparent,#000 12%,#000 88%,transparent)}
.gt-track{display:flex;gap:14px;width:max-content;animation:gtMarq 38s linear infinite}
.gt-stage[dir=rtl] .gt-track{animation-direction:reverse}
.gt-track span{white-space:nowrap;padding:10px 18px;border-radius:999px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);font-size:14px;color:#E6ECF7}
.gt-track b{color:#FFD54A;font-weight:600;margin-inline-end:6px}
@keyframes gtMarq{to{transform:translateX(-50%)}}
.gt-panel{max-width:440px;margin:24px auto 0;border-radius:22px;padding:30px 26px;background:linear-gradient(160deg,rgba(255,255,255,.1),rgba(255,255,255,.03));
  border:1px solid rgba(255,255,255,.14);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);box-shadow:0 40px 80px -30px rgba(0,0,0,.8)}
.gt-field{display:block;margin-bottom:14px}.gt-field span{display:block;font-size:13px;font-weight:600;color:#E6ECF7;margin-bottom:6px}
.gt-field input,.gt-select{width:100%;box-sizing:border-box;padding:13px 14px;border-radius:12px;border:1px solid rgba(255,255,255,.18);background:rgba(10,8,7,.55);
  color:#FFFFFF;font:inherit;font-size:16px;transition:border-color .2s,box-shadow .2s}
.gt-select option{color:#1B1917}
.gt-field input:focus,.gt-select:focus{outline:none;border-color:#FFD54A;box-shadow:0 0 0 3px rgba(255,213,74,.2)}
.gt-btn{all:unset;display:block;box-sizing:border-box;width:100%;text-align:center;cursor:pointer;padding:14px 18px;border-radius:12px;font-weight:700;font-size:16px;
  color:#1B1917;background:linear-gradient(100deg,#FFE58A,#F5B800 60%,#FFD54A);background-size:200% 100%;transition:background-position .5s,transform .15s}
.gt-btn:hover{background-position:100% 0}.gt-btn:active{transform:scale(.98)}.gt-btn[disabled]{opacity:.55;cursor:wait}
.gt-err{background:rgba(196,72,86,.16);border:1px solid rgba(196,72,86,.5);color:#FFD6DA;border-radius:10px;padding:10px 12px;font-size:14px;margin-bottom:14px}
.gt-ok{background:rgba(63,125,104,.18);border:1px solid rgba(63,125,104,.55);color:#D4F2E5;border-radius:10px;padding:10px 12px;font-size:14px;margin-bottom:14px}
.gt-tabs{display:grid;grid-template-columns:1fr 1fr;padding:4px;border-radius:14px;background:rgba(0,0,0,.35);margin-bottom:20px}
.gt-tabs button{all:unset;cursor:pointer;text-align:center;padding:10px;border-radius:10px;font-weight:600;font-size:14px;color:#D5DEEE}
.gt-tabs button[aria-selected=true]{background:rgba(255,255,255,.12);color:#fff}
.gt-link{color:#FFE58A;text-decoration:underline;text-underline-offset:3px;background:none;border:0;cursor:pointer;font:inherit;padding:0}
.gt-skip{position:absolute;z-index:6;bottom:22px;inset-inline-end:22px}
.gt-intro{position:fixed;inset:0;z-index:5;display:grid;place-items:center;background:#040A1A;transition:opacity .8s ease,visibility .8s}
.gt-intro.done{opacity:0;visibility:hidden}
.gt-door path{fill:none;stroke:#FFD54A;stroke-width:2.5;stroke-linecap:round;stroke-dasharray:900;stroke-dashoffset:900;animation:gtDraw 1.5s cubic-bezier(.6,0,.2,1) forwards}
.gt-door path.light{stroke:none;stroke-dasharray:none;stroke-dashoffset:0;opacity:0;animation:gtLight 1.2s ease 1.3s forwards}
.gt-door .logo{opacity:0;transform-origin:120px 160px;animation:gtLogo 1s cubic-bezier(.2,.8,.2,1.2) 1.7s forwards}
.gt-door .rays{opacity:0;transform-origin:120px 200px;animation:gtRays 2.2s ease 1.5s forwards}
@keyframes gtDraw{to{stroke-dashoffset:0}}
@keyframes gtLight{to{opacity:1}}
@keyframes gtLogo{from{opacity:0;transform:scale(.4)}to{opacity:1;transform:scale(1)}}
@keyframes gtRays{0%{opacity:0;transform:scale(.6) rotate(-8deg)}40%{opacity:.9}100%{opacity:.55;transform:scale(1.25) rotate(6deg)}}
.gt-intro-word{margin-top:18px;font-family:"Newsreader",serif;font-size:clamp(1.6rem,4vw,2.4rem);color:#FFFFFF;opacity:0;animation:gtFade .8s ease 2.3s forwards;text-align:center}
.gt-intro-word small{display:block;font-family:"IBM Plex Sans Arabic",sans-serif;font-size:.7em;color:#FFD54A;margin-top:6px}
.gt-chip{display:inline-flex;align-items:center;gap:10px;padding:8px 8px 8px 16px;border-radius:999px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.16);font-size:14px}
.gt-chip a{color:#1B1917;background:#FFE58A;border-radius:999px;padding:6px 12px;text-decoration:none;font-weight:700}
.gt-word-cycle{display:inline-grid;vertical-align:bottom}
.gt-word-cycle span{grid-area:1/1;opacity:0;animation:gtCycle 12s infinite}
.gt-word-cycle span:nth-child(2){animation-delay:3s}.gt-word-cycle span:nth-child(3){animation-delay:6s}.gt-word-cycle span:nth-child(4){animation-delay:9s}
@keyframes gtCycle{0%{opacity:0;transform:translateY(40%)}4%,22%{opacity:1;transform:none}26%,100%{opacity:0;transform:translateY(-40%)}}
.gt-card[data-look=placement] .gt-ico{animation:gtPulse 2.2s ease-in-out infinite}
@keyframes gtPulse{0%,100%{box-shadow:0 0 0 0 rgba(255,213,74,.6)}50%{box-shadow:0 0 0 14px rgba(255,213,74,0)}}
.gt-card[data-look=owner]::after{content:"";position:absolute;inset:0;background:linear-gradient(100deg,transparent 25%,rgba(255,255,255,.14) 50%,transparent 75%);transform:translateX(-120%);transition:transform .9s ease;pointer-events:none}
.gt-card[data-look=owner]:hover::after{transform:translateX(120%)}
.gt-card[data-look=guest]:hover .gt-ico{transform:rotate(-10deg) scale(1.12)}
.gt-ico{transition:transform .45s cubic-bezier(.2,.8,.2,1.4)}
.gt-bigarrow{margin:26px auto 0;display:grid;place-items:center}
.gt-panel{background:linear-gradient(160deg,rgba(14,26,56,.9),rgba(6,14,34,.85))!important}
@media (prefers-reduced-motion: reduce){
  .gt-card[data-look=placement] .gt-ico{animation:none}
  .gt-stage *,.gt-stage *::before{animation-duration:.001s!important;animation-delay:0s!important;animation-iteration-count:1!important;transition:none!important}
  .gt-track{animation:none!important;flex-wrap:wrap;width:auto;justify-content:center}
  .gt-word-cycle span{opacity:0!important}.gt-word-cycle span:first-child{opacity:1!important}
}
`;
