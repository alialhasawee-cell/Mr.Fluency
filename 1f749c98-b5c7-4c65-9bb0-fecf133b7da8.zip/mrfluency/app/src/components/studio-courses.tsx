import { useCallback, useEffect, useState } from "react";
import { LevelChip } from "./brand";
import { api, Spinner } from "./session";
import { Field, Text, Area, Select, Card, Row, Pill, Modal, BLOCK_TEMPLATES, BLOCK_KINDS } from "./studio-ui";

const safe = (s: any) => { try { return typeof s === "string" ? JSON.parse(s) : (s ?? {}); } catch { return {}; } };

export function Overview() {
  const [d, setD] = useState<any>(null);
  useEffect(() => { void api.get("/api/cms?what=overview").then((r) => setD(r.data)); }, []);
  if (!d) return <Spinner />;
  const c = d.counts ?? {};
  const tiles: [string, any][] = [
    ["Students", c.students], ["Active (30d)", c.activeStudents], ["New (30d)", c.newRegistrations],
    ["Courses", c.courses], ["Lessons", c.lessons], ["Quizzes", c.quizzes],
    ["Questions", c.questions], ["Enrolments", c.enrollments], ["Completions", c.completions],
    ["Certificates", c.certificates], ["Placement tests", c.placements], ["Media files", c.media],
  ];
  const maxLvl = Math.max(1, ...(d.levels ?? []).map((x: any) => x.n ?? 0));
  return (
    <div>
      <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {tiles.map(([k, v]) => (
          <div key={k} className="mf-card p-4">
            <div className="mf-label">{k}</div>
            <div className="text-3xl" style={{ fontFamily: "var(--display)" }}>{v ?? 0}</div>
          </div>))}
      </div>
      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card>
          <h3 className="text-xl">Placement level distribution</h3>
          <div className="mt-4 grid gap-2">
            {(d.levels ?? []).length ? (d.levels ?? []).map((l: any) => (
              <div key={l.lvl ?? "x"} className="flex items-center gap-3">
                <span style={{ width: 54 }}>{l.lvl ? <LevelChip level={l.lvl} /> : "-"}</span>
                <span className="mf-bar flex-1"><i style={{ width: Math.round((l.n / maxLvl) * 100) + "%" }} /></span>
                <span className="mf-mono text-sm">{l.n}</span>
              </div>)) : <p className="mf-prose text-sm">No completed placement tests yet.</p>}
          </div>
          <p className="mt-4 text-sm" style={{ color: "var(--ink-2)" }}>
            Average quiz score: <b>{d.avgQuiz != null ? Math.round(d.avgQuiz) + "%" : "not yet"}</b>
          </p>
        </Card>
        <Card>
          <h3 className="text-xl">Most popular courses</h3>
          <div className="mt-4 grid gap-2">
            {(d.popular ?? []).map((p: any) => (
              <div key={p.title} className="flex items-center gap-3">
                <span className="flex-1 text-sm">{p.title}</span><span className="mf-mono text-sm">{p.n}</span>
              </div>))}
            {!(d.popular ?? []).length ? <p className="mf-prose text-sm">Nothing yet.</p> : null}
          </div>
        </Card>
      </div>
      <div className="mt-6"><Card>
        <h3 className="text-xl">Recent registrations</h3>
        <div className="mt-3 overflow-x-auto">
          <table className="mf-table"><thead><tr><th>Student</th><th>Level</th><th>XP</th><th>Joined</th></tr></thead>
            <tbody>{(d.recentStudents ?? []).map((s: any) => (
              <tr key={s.id}><td><b>{s.name}</b><div className="text-xs" style={{ color: "var(--ink-3)" }}>{s.email}</div></td>
                <td>{s.cefr_level ?? "-"}</td><td className="mf-mono">{s.xp}</td>
                <td className="text-xs">{new Date(s.created_at).toLocaleDateString()}</td></tr>))}
            </tbody></table>
        </div>
      </Card></div>
    </div>
  );
}

export function Courses({ toast }: { toast: (m: string) => void }) {
  const [courses, setCourses] = useState<any[]>([]);
  const [sel, setSel] = useState("");
  const [tree, setTree] = useState<any>(null);
  const [edit, setEdit] = useState<any>(null);
  const [lessonEdit, setLessonEdit] = useState("");

  const loadCourses = useCallback(async () => {
    const { data } = await api.get("/api/cms?what=courses");
    setCourses(data.courses ?? []);
  }, []);
  const loadTree = useCallback(async (id: string) => {
    if (!id) { setTree(null); return; }
    const { data } = await api.get("/api/cms?what=tree&courseId=" + id);
    setTree(data);
  }, []);
  useEffect(() => { void loadCourses(); }, [loadCourses]);
  useEffect(() => { void loadTree(sel); }, [sel, loadTree]);

  const save = async (action: string, payload: any, label: string) => {
    const { ok } = await api.post("/api/cms", { action, ...payload });
    toast(ok ? label + " saved" : "Could not save");
    await loadCourses();
    if (sel) await loadTree(sel);
  };

  return (
    <div>
      <Row>
        <div style={{ minWidth: 260 }}>
          <Select value={sel} onChange={setSel}
            options={[{ v: "", l: "Choose a course..." }, ...courses.map((c) => ({ v: c.id, l: c.title + (c.status === "draft" ? " (draft)" : "") }))]} />
        </div>
        <button className="cta-quiet" onClick={() => setEdit({ status: "draft", access: "open", instructor: "Ali Abdulkareem Mohammed Alhasawee" })}>+ New course</button>
        {sel ? <button className="cta-quiet" onClick={() => setEdit(courses.find((c) => c.id === sel))}>Edit details</button> : null}
      </Row>

      {!sel ? (
        <div className="mt-6 grid gap-3">
          {courses.map((c) => (
            <Card key={c.id}>
              <Row>
                <b className="text-lg" style={{ fontFamily: "var(--display)" }}>{c.title}</b>
                <Pill tone={c.status === "published" ? "ok" : undefined}>{c.status}</Pill>
                <span className="mf-mono ml-auto text-xs" style={{ color: "var(--ink-3)" }}>
                  {c.levels} levels · {c.modules} modules · {c.lessons} lessons
                </span>
                <button className="cta-quiet" style={{ padding: "6px 12px", fontSize: 10 }} onClick={() => setSel(c.id)}>Open</button>
              </Row>
            </Card>))}
          {!courses.length ? <p className="mf-prose">No courses yet. Create one to begin.</p> : null}
        </div>) : null}

      {tree ? (
        <div className="mt-6">
          <Row>
            <h2 className="text-2xl">{tree.course.title}</h2>
            <Pill tone={tree.course.status === "published" ? "ok" : undefined}>{tree.course.status}</Pill>
            <button className="cta-quiet ml-auto" style={{ padding: "7px 13px", fontSize: 10 }}
              onClick={() => save("set_status", { kind: "course", id: tree.course.id, status: tree.course.status === "published" ? "draft" : "published" }, "Course")}>
              {tree.course.status === "published" ? "Unpublish" : "Publish"}
            </button>
            <button className="cta-quiet" style={{ padding: "7px 13px", fontSize: 10 }}
              onClick={() => { const cefr = prompt("CEFR level (A0 to C2)?", "A1"); if (cefr) void save("save_level", { level: { course_id: sel, cefr, title: cefr + " - " + tree.course.title, status: "published", sort: tree.levels.length } }, "Level"); }}>
              + Level
            </button>
          </Row>
          <div className="mt-5 grid gap-5">
            {tree.levels.map((lvl: any) => (
              <Card key={lvl.id}>
                <Row>
                  <LevelChip level={lvl.cefr} />
                  <b className="text-lg">{lvl.title}</b>
                  <Pill tone={lvl.status === "published" ? "ok" : undefined}>{lvl.status}</Pill>
                  <button className="cta-quiet ml-auto" style={{ padding: "6px 11px", fontSize: 10 }}
                    onClick={() => save("set_status", { kind: "level", id: lvl.id, status: lvl.status === "published" ? "draft" : "published" }, "Level")}>
                    {lvl.status === "published" ? "Unpublish" : "Publish"}
                  </button>
                  <button className="cta-quiet" style={{ padding: "6px 11px", fontSize: 10 }}
                    onClick={() => { const title = prompt("Module title?"); if (title) void save("save_module", { module: { level_id: lvl.id, course_id: sel, title, status: "published", sort: lvl.modules.length, code: "M" + (lvl.modules.length + 1) } }, "Module"); }}>
                    + Module
                  </button>
                </Row>
                <div className="mt-4 grid gap-3">
                  {lvl.modules.map((m: any) => (
                    <div key={m.id} className="rounded-lg p-4" style={{ background: "var(--surface-2)", border: "1px solid var(--line)" }}>
                      <Row>
                        <span className="mf-mono text-xs" style={{ color: "var(--ink-3)" }}>{m.code}</span>
                        <b>{m.title}</b>
                        <Pill tone={m.status === "published" ? "ok" : undefined}>{m.status}</Pill>
                        <button className="cta-quiet ml-auto" style={{ padding: "5px 10px", fontSize: 10 }}
                          onClick={() => save("set_status", { kind: "module", id: m.id, status: m.status === "published" ? "draft" : "published" }, "Module")}>
                          {m.status === "published" ? "Unpublish" : "Publish"}
                        </button>
                        <button className="cta-quiet" style={{ padding: "5px 10px", fontSize: 10 }}
                          onClick={() => { const title = prompt("Lesson title?"); if (title) void save("save_lesson", { lesson: { module_id: m.id, title, status: "published", sort: m.lessons.length } }, "Lesson"); }}>
                          + Lesson
                        </button>
                      </Row>
                      <ol className="mt-3 grid list-none gap-1.5 p-0">
                        {m.lessons.map((l: any, i: number) => (
                          <li key={l.id} className="flex flex-wrap items-center gap-3 rounded-md px-3 py-2"
                            style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
                            <span className="mf-mono text-xs" style={{ color: "var(--ink-3)" }}>{i + 1}</span>
                            <span className="min-w-[140px] flex-1 text-sm">{l.title}</span>
                            <Pill tone={l.status === "published" ? "ok" : undefined}>{l.status}</Pill>
                            <button className="cta-quiet" style={{ padding: "5px 10px", fontSize: 10 }} onClick={() => setLessonEdit(l.id)}>Edit content</button>
                            <button className="cta-quiet" style={{ padding: "5px 10px", fontSize: 10 }}
                              onClick={() => save("duplicate_lesson", { lessonId: l.id }, "Lesson copy")}>Duplicate</button>
                          </li>))}
                        {!m.lessons.length ? <li className="text-sm" style={{ color: "var(--ink-3)" }}>No lessons yet.</li> : null}
                      </ol>
                    </div>))}
                  {!lvl.modules.length ? <p className="text-sm" style={{ color: "var(--ink-3)" }}>No modules yet.</p> : null}
                </div>
              </Card>))}
          </div>
        </div>) : null}

      {edit ? <CourseModal course={edit} toast={toast} onClose={() => setEdit(null)}
        onSaved={async () => { setEdit(null); await loadCourses(); }} /> : null}
      {lessonEdit ? <LessonModal lessonId={lessonEdit} toast={toast}
        onClose={() => { setLessonEdit(""); void loadTree(sel); }} /> : null}
    </div>
  );
}

function CourseModal({ course, onClose, onSaved, toast }: any) {
  const [c, setC] = useState<any>({ ...course });
  return (
    <Modal title={course.id ? "Edit course" : "New course"} onClose={onClose} onSave={async () => {
      const { ok, data } = await api.post("/api/cms", { action: "save_course", course: c });
      toast(ok ? "Course saved" : data?.error === "title_required" ? "A title is required" : "Could not save");
      if (ok) onSaved();
    }}>
      <Field label="Title"><Text value={c.title} onChange={(v: string) => setC({ ...c, title: v })} /></Field>
      <Field label="Subtitle"><Text value={c.subtitle} onChange={(v: string) => setC({ ...c, subtitle: v })} /></Field>
      <Field label="Description"><Area value={c.description} rows={4} onChange={(v: string) => setC({ ...c, description: v })} /></Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Category"><Select value={c.category ?? "general"} onChange={(v) => setC({ ...c, category: v })}
          options={[{ v: "general", l: "General English" }, { v: "business", l: "Business English" },
            { v: "writing", l: "Email and Writing" }, { v: "ielts", l: "IELTS" }, { v: "specialist", l: "Specialist" }]} /></Field>
        <Field label="Placement goal" hint="Which placement result recommends this course">
          <Select value={c.goal ?? "general"} onChange={(v) => setC({ ...c, goal: v })}
            options={[{ v: "general", l: "general" }, { v: "business", l: "business" }, { v: "writing", l: "writing" }, { v: "ielts", l: "ielts" }]} /></Field>
        <Field label="Status"><Select value={c.status ?? "draft"} onChange={(v) => setC({ ...c, status: v })}
          options={[{ v: "draft", l: "Draft" }, { v: "published", l: "Published" }, { v: "archived", l: "Archived" }]} /></Field>
        <Field label="Access"><Select value={c.access ?? "open"} onChange={(v) => setC({ ...c, access: v })}
          options={[{ v: "open", l: "Open to all students" }, { v: "invite", l: "Invitation only" }, { v: "paid", l: "Paid (payments not enabled yet)" }]} /></Field>
        <Field label="Accent colour" hint="Any CSS colour value"><Text value={c.color} onChange={(v: string) => setC({ ...c, color: v })} /></Field>
        <Field label="Instructor"><Text value={c.instructor} onChange={(v: string) => setC({ ...c, instructor: v })} /></Field>
      </div>
    </Modal>
  );
}

function LessonModal({ lessonId, onClose, toast }: any) {
  const [lesson, setLesson] = useState<any>(null);
  const [blocks, setBlocks] = useState<any[]>([]);
  const [editing, setEditing] = useState<any>(null);

  const load = useCallback(async () => {
    const { data } = await api.get("/api/cms?what=lesson&id=" + lessonId);
    setLesson(data.lesson);
    setBlocks((data.blocks ?? []).map((b: any) => ({ ...b, data: safe(b.data) })));
  }, [lessonId]);
  useEffect(() => { void load(); }, [load]);

  const saveLesson = async () => {
    const { ok } = await api.post("/api/cms", {
      action: "save_lesson", lesson: { ...lesson, completion_rule: safe(lesson.completion_rule) },
    });
    toast(ok ? "Lesson saved" : "Could not save");
  };
  const saveBlock = async (b: any) => {
    const { ok } = await api.post("/api/cms", { action: "save_block", block: { ...b, lesson_id: lessonId } });
    toast(ok ? "Block saved" : "Could not save block");
    setEditing(null);
    await load();
  };
  const delBlock = async (id: string) => {
    if (!confirm("Delete this block?")) return;
    await api.post("/api/cms", { action: "delete_block", id });
    await load();
  };
  const move = async (i: number, d: number) => {
    const c = [...blocks]; const j = i + d;
    if (j < 0 || j >= c.length) return;
    [c[i], c[j]] = [c[j], c[i]];
    setBlocks(c);
    await api.post("/api/cms", { action: "reorder", kind: "block", ids: c.map((x) => x.id) });
  };

  if (!lesson) return <Modal title="Lesson" onClose={onClose}><Spinner /></Modal>;
  const rule = safe(lesson.completion_rule);

  return (
    <Modal title={"Lesson - " + lesson.title} onClose={onClose} onSave={saveLesson} saveLabel="Save lesson" wide>
      <Field label="Title"><Text value={lesson.title} onChange={(v: string) => setLesson({ ...lesson, title: v })} /></Field>
      <Field label="Objective" hint="Shown to the student at the top of the lesson">
        <Area value={lesson.objective} rows={2} onChange={(v: string) => setLesson({ ...lesson, objective: v })} /></Field>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Minutes"><Text type="number" value={lesson.duration_min} onChange={(v: string) => setLesson({ ...lesson, duration_min: v })} /></Field>
        <Field label="Status"><Select value={lesson.status} onChange={(v) => setLesson({ ...lesson, status: v })}
          options={[{ v: "draft", l: "Draft" }, { v: "published", l: "Published" }]} /></Field>
        <Field label="Unlocking"><Select value={lesson.unlock_rule} onChange={(v) => setLesson({ ...lesson, unlock_rule: v })}
          options={[{ v: "previous_lesson", l: "After the previous lesson" }, { v: "none", l: "Always open" }]} /></Field>
      </div>
      <Field label="Completion requires" hint="A lesson is never completed just by opening it">
        <Select value={rule.quiz ? "quiz" : "blocks"} onChange={(v) =>
          setLesson({ ...lesson, completion_rule: JSON.stringify({ blocks: true, quiz: v === "quiz", minQuizPct: rule.minQuizPct ?? 0 }) })}
          options={[{ v: "blocks", l: "All required blocks marked done" }, { v: "quiz", l: "Required blocks AND a passing quiz" }]} />
      </Field>

      <div className="mt-6 border-t pt-5" style={{ borderColor: "var(--line)" }}>
        <Row>
          <h4 className="text-lg">Content blocks</h4>
          <select className="mf-field ml-auto" style={{ width: 210 }} value=""
            onChange={(e) => { if (!e.target.value) return;
              setEditing({ kind: e.target.value, sort: blocks.length, required: 0, data: BLOCK_TEMPLATES[e.target.value] ?? {} }); }}>
            <option value="">+ Add a block...</option>
            {BLOCK_KINDS.map((k) => <option key={k} value={k}>{k}</option>)}
          </select>
        </Row>
        <div className="mt-4 grid gap-2">
          {blocks.map((b, i) => (
            <div key={b.id} className="flex flex-wrap items-center gap-3 rounded-md px-3 py-2"
              style={{ background: "var(--surface-2)", border: "1px solid var(--line)" }}>
              <span className="mf-mono text-xs" style={{ color: "var(--ink-3)" }}>{i + 1}</span>
              <b className="text-sm">{b.kind}</b>
              {b.required === 1 ? <Pill tone="warn">required</Pill> : null}
              <span className="min-w-[70px] flex-1 truncate text-xs" style={{ color: "var(--ink-3)" }}>
                {String(b.data?.text ?? b.data?.title ?? b.data?.prompt ?? b.data?.instructions ?? "").slice(0, 60)}
              </span>
              <button className="cta-quiet" style={{ padding: "4px 9px", fontSize: 10 }} onClick={() => move(i, -1)}>up</button>
              <button className="cta-quiet" style={{ padding: "4px 9px", fontSize: 10 }} onClick={() => move(i, 1)}>down</button>
              <button className="cta-quiet" style={{ padding: "4px 9px", fontSize: 10 }} onClick={() => setEditing(b)}>Edit</button>
              <button className="cta-quiet" style={{ padding: "4px 9px", fontSize: 10, color: "var(--danger)" }} onClick={() => delBlock(b.id)}>x</button>
            </div>))}
          {!blocks.length ? <p className="text-sm" style={{ color: "var(--ink-3)" }}>No blocks yet - add one above.</p> : null}
        </div>
      </div>

      {editing ? <BlockModal block={editing} onClose={() => setEditing(null)} onSave={saveBlock} /> : null}
    </Modal>
  );
}

function BlockModal({ block, onClose, onSave }: any) {
  const [b, setB] = useState<any>({ ...block, data: block.data ?? {} });
  const [raw, setRaw] = useState(JSON.stringify(block.data ?? {}, null, 2));
  const [bad, setBad] = useState("");
  const simple = ["heading", "text", "callout"].includes(b.kind);
  return (
    <Modal title={(b.id ? "Edit " : "New ") + b.kind + " block"} onClose={onClose} wide onSave={() => {
      let data = b.data;
      if (!simple) {
        try { data = JSON.parse(raw); }
        catch { setBad("That is not valid content - check the commas and quotation marks."); return; }
      }
      onSave({ ...b, data });
    }}>
      <Row>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={b.required === 1}
            onChange={(e) => setB({ ...b, required: e.target.checked ? 1 : 0 })} />
          Required to complete the lesson
        </label>
      </Row>
      <div className="mt-4">
        {simple ? (
          <Field label={b.kind === "heading" ? "Heading text" : "Text"}>
            <Area rows={b.kind === "heading" ? 2 : 8} value={b.data.text ?? ""}
              onChange={(v: string) => setB({ ...b, data: { ...b.data, text: v } })} />
          </Field>
        ) : (
          <Field label="Block content" hint="A template is filled in when you add a block - edit the values, keep the structure.">
            <textarea className="mf-field mf-mono" style={{ fontSize: 12.5 }} rows={16} value={raw}
              onChange={(e) => { setRaw(e.target.value); setBad(""); }} />
          </Field>
        )}
      </div>
      {bad ? <p className="text-sm" style={{ color: "var(--danger)" }}>{bad}</p> : null}
    </Modal>
  );
}
