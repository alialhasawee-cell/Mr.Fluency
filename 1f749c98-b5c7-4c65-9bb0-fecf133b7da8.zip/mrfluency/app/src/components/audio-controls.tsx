/** The one discoverable audio control: a header button that opens the panel.
 *  Everything is off until touched here. */
import { useEffect, useRef, useState } from "react";
import { useAudioLayer } from "./audio-layer";

export function AudioButton() {
  const a = useAudioLayer();
  const [open, setOpen] = useState(false);
  const wrap = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    function onDoc(e: MouseEvent) {
      if (wrap.current && !wrap.current.contains(e.target as Node)) setOpen(false);
    }
    function onKey(e: KeyboardEvent) { if (e.key === "Escape") setOpen(false); }
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("mousedown", onDoc); document.removeEventListener("keydown", onKey); };
  }, [open]);

  if (!a) return null;
  const active = a.musicOn && !a.muted;

  return (
    <div ref={wrap} className="relative">
      <button type="button" onClick={() => setOpen(!open)}
        aria-expanded={open} aria-haspopup="dialog"
        aria-label={active ? "Sound settings — music playing" : "Sound settings"}
        title="Sound"
        className="grid h-9 w-9 place-items-center rounded-md"
        style={{
          border: "1px solid var(--line)",
          background: active ? "var(--garnet-soft)" : "transparent",
          color: a.muted ? "var(--ink-3)" : active ? "var(--garnet)" : "var(--ink-2)", cursor: "pointer",
        }}>
        <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
          <path d="M4 9v6h4l5 4V5L8 9H4z" fill="currentColor" />
          {a.muted
            ? <path d="M16 9l5 6M21 9l-5 6" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
            : <path d="M16 8.5a5 5 0 0 1 0 7" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />}
        </svg>
      </button>

      {open ? (
        <div role="dialog" aria-label="Sound settings"
          className="absolute right-0 z-50 mt-2 w-[290px] rounded-xl p-4 shadow-lg"
          style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
          <div className="mf-eyebrow mb-3">Sound</div>

          <Row label="Mute everything">
            <Toggle on={a.muted} onChange={a.setMuted} label="Mute everything" />
          </Row>

          <Row label="Background music" hint={a.tracks.length ? undefined : "No tracks installed yet"}>
            <Toggle on={a.musicOn} onChange={a.setMusicOn} disabled={a.muted || !a.tracks.length} label="Background music" />
          </Row>

          {a.musicOn && a.tracks.length ? (
            <>
              <label className="mt-3 block text-xs" style={{ color: "var(--ink-3)" }}>
                Volume
                <input type="range" min={0} max={1} step={0.05} value={a.volume}
                  onChange={(e) => a.setVolume(Number(e.target.value))}
                  className="mt-1 w-full" aria-label="Music volume" />
              </label>
              {a.tracks.length > 1 ? (
                <label className="mt-2 block text-xs" style={{ color: "var(--ink-3)" }}>
                  Track
                  <select value={a.trackId ?? ""} onChange={(e) => a.setTrackId(e.target.value)}
                    className="mt-1 w-full rounded-md px-2 py-1.5 text-sm"
                    style={{ border: "1px solid var(--line)", background: "var(--surface)", color: "var(--ink)" }}>
                    {a.tracks.map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}
                  </select>
                </label>) : null}
            </>) : null}

          <Row label="Encouragement prompts" hint="Arabic and English, after you finish something">
            <Toggle on={a.motivationOn} onChange={a.setMotivationOn} disabled={a.muted} label="Encouragement prompts" />
          </Row>

          <p className="mt-3 mb-0 text-xs" style={{ color: "var(--ink-3)" }}>
            Nothing plays until you switch it on, and your choice is remembered on this device.
          </p>
        </div>) : null}
    </div>
  );
}

function Row({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="mt-3 flex items-start gap-3 first:mt-0">
      <span className="flex-1 text-sm">
        {label}
        {hint ? <span className="mt-0.5 block text-xs" style={{ color: "var(--ink-3)" }}>{hint}</span> : null}
      </span>
      {children}
    </div>);
}

function Toggle({ on, onChange, disabled, label }: { on: boolean; onChange: (v: boolean) => void; disabled?: boolean; label: string }) {
  return (
    <button type="button" role="switch" aria-checked={on} aria-label={label} disabled={disabled}
      onClick={() => onChange(!on)}
      className="relative rounded-full"
      style={{
        width: 42, height: 24, flex: "none", cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.45 : 1,
        background: on ? "var(--garnet)" : "var(--surface-2)",
        border: "1px solid " + (on ? "var(--garnet)" : "var(--line)"),
        transition: "background .18s",
      }}>
      <span style={{
        position: "absolute", top: 2, left: on ? 20 : 2, width: 18, height: 18, borderRadius: "50%",
        background: on ? "#fff" : "var(--ink-3)", transition: "left .18s",
      }} />
    </button>);
}
