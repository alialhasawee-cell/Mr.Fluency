import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { Shell } from "../../components/shell";
import { BlockView, type Block } from "../../components/blocks";
import { api, useSession, Spinner, ErrorNote } from "../../components/session";
import { useAudioLayer } from "../../components/audio-layer";

export const Route = createFileRoute("/learn/$lessonId")({
  head: () => ({ meta: [{ name: "robots", content: "noindex" }] }),
  component: LessonPlayer,
});

function LessonPlayer() {
  const { lessonId } = Route.useParams();
  const { user, loading } = useSession();
  const router = useRouter();
  const [state, setState] = useState<any>(null);
  const [err, setErr] = useState<string>("");
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState<any>(null);

  const load = useCallback(async () => {
    setErr("");
    await api.post("/api/lms", { action: "start_lesson", lessonId });
    const { ok, status, data } = await api.get("/api/lms?what=lesson&id=" + encodeURIComponent(lessonId));
    if (!ok) {
      setErr(status === 403
        ? (data?.reason === "not_enrolled" ? "You are not enrolled on this course yet."
          : typeof data?.reason === "string" ? data.reason : "This lesson is locked.")
        : "This lesson could not be opened.");
      return;
    }
    setState(data);
  }, [lessonId]);

  useEffect(() => { if (user) void load(); }, [user, load]);
  useEffect(() => { if (!loading && !user) router.navigate({ to: "/login" }); }, [loading, user, router]);

  const checks: Record<string, boolean> = (() => {
    try { return JSON.parse(state?.progress?.checks ?? "{}"); } catch { return {}; }
  })();

  async function markDone(blockId: string) {
    setSaving(true);
    const { data } = await api.post("/api/lms", { action: "check_off", lessonId, key: "block:" + blockId });
    setSaving(false);
    if (data?.checks) setState((s: any) => ({ ...s, progress: { ...(s.progress ?? {}), checks: JSON.stringify(data.checks) } }));
  }
  const audio = useAudioLayer();

  async function finish() {
    setSaving(true);
    const { data } = await api.post("/api/lms", { action: "complete_lesson", lessonId });
    setSaving(false);
    setResult(data);
    if (data?.completed) { audio?.celebrate(data.certificate ? "module_complete" : "lesson_complete"); void load(); }
  }

  if (loading || (!state && !err)) return <Shell><Wrap><Spinner label="Opening your lesson…" /></Wrap></Shell>;
  if (err) return (
    <Shell><Wrap>
      <ErrorNote onRetry={load}>{err}</ErrorNote>
      <Link to="/dashboard" className="cta-quiet mt-6">Back to my learning</Link>
    </Wrap></Shell>
  );

  const lesson = state.lesson;
  const blocks: Block[] = lesson?.blocks ?? [];
  const required = blocks.filter((b) => b.required === 1);
  const doneCount = required.filter((b) => checks["block:" + b.id]).length;
  const isDone = state.progress?.status === "completed";

  return (
    <Shell>
      <Wrap>
        <div className="flex flex-wrap items-center gap-3">
          <Link to="/dashboard" className="mf-link text-sm">← My learning</Link>
          {isDone ? <span className="chip-contact" style={{ padding: "5px 12px", color: "var(--ok)" }}>✓ Completed</span> : null}
        </div>
        <div className="mf-eyebrow mt-6 mb-2">Lesson</div>
        <h1 className="text-4xl">{lesson.title}</h1>
        {lesson.objective ? (
          <p className="mf-prose mt-3"><b>Objective.</b> {lesson.objective}</p>
        ) : null}
        {required.length ? (
          <div className="mt-6">
            <div className="mf-bar" style={{ maxWidth: 420 }}>
              <i style={{ width: Math.round((doneCount / required.length) * 100) + "%" }} />
            </div>
            <p className="mf-mono mt-2 text-xs" style={{ color: "var(--ink-3)" }}>
              {doneCount} of {required.length} required steps done · about {lesson.duration_min} min
            </p>
          </div>
        ) : null}

        <div className="mt-8 grid gap-5">
          {blocks.map((b) => (
            <BlockView key={b.id} block={b} done={!!checks["block:" + b.id]}
              onDone={isDone ? undefined : markDone} />
          ))}
        </div>

        {lesson.quiz ? (
          <div className="mf-card mt-6 p-6" style={{ borderLeft: "3px solid var(--garnet)" }}>
            <div className="mf-eyebrow mb-2">Assessment</div>
            <h2 className="text-2xl">{lesson.quiz.title}</h2>
            <p className="mf-prose mt-2 text-sm">
              Pass mark {lesson.quiz.pass_pct}%. Questions must be answered in order and cannot be skipped.
            </p>
            <Link to="/quiz/$quizId" params={{ quizId: lesson.quiz.id }} className="cta-test mt-4">Take the quiz</Link>
          </div>
        ) : null}

        <div className="mt-10 border-t pt-8" style={{ borderColor: "var(--line)" }}>
          {result && !result.completed ? (
            <div className="mf-note mb-4">
              Not finished yet — still to do: {(result.missing ?? []).join(", ")}.
            </div>
          ) : null}
          {result?.completed ? (
            <div className="mf-note mb-4" style={{ borderColor: "var(--ok)", background: "var(--surface-2)" }}>
              <b>Lesson completed.</b> Your progress is saved.
              {result.certificate ? ` Certificate ${result.certificate} has been issued.` : ""}
            </div>
          ) : null}
          <div className="flex flex-wrap gap-3">
            <button className="cta-test" onClick={finish} disabled={saving || isDone}>
              {isDone ? "✓ Lesson complete" : saving ? "Saving…" : "Mark lesson complete"}
            </button>
            <Link to="/dashboard" className="cta-quiet">Back to my learning</Link>
          </div>
        </div>
      </Wrap>
    </Shell>
  );
}
function Wrap({ children }: { children: React.ReactNode }) {
  return <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">{children}</div>;
}
