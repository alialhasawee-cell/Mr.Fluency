import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell, Section } from "../components/shell";
import { DoorArt, Staircase, CourseGlyph, LevelChip } from "../components/brand";
import { COURSES, PROFILE, LEVEL_INFO } from "../lib/courses";
import { SITE } from "../lib/site";

export const Route = createFileRoute("/academy")({
  head: () => ({
    links: [{ rel: "canonical", href: SITE + "/academy" }],
  }),
  component: Home,
});

const STATS = [
  { v: "14+", k: "Years teaching", s: "English language teaching and professional training" },
  { v: "8,000+", k: "Students taught", s: "Academic, IELTS, careers, business and everyday English" },
  { v: "A0–C2", k: "Levels covered", s: "The full CEFR ladder, absolute beginner to proficient" },
  { v: "4", k: "Programmes", s: "General, Business, Email Writing and IELTS" },
];

const STEPS = [
  { n: "01", t: "Give your name and email", d: "The email is only used to identify your attempt and send you the result. Nothing else." },
  { n: "02", t: "Read the six rules", d: "No skipping, a timer on every question, and you may stop and resume whenever you need to." },
  { n: "03", t: "Answer, level by level", d: "The test begins at A1 and climbs. Each section is eight questions drawn at random from that level." },
  { n: "04", t: "It stops at your ceiling", d: "When a section becomes too difficult the test ends there. A beginner answers 8 questions; a C2 candidate answers 48." },
  { n: "05", t: "Read your report", d: "Your CEFR level, section-by-section scores, skill breakdown, the programme you should join and where in it to start." },
];

function Home() {
  return (
    <Shell>
      <section className="mx-auto grid max-w-6xl items-center gap-10 px-4 pb-4 pt-12 sm:px-6 sm:pt-16 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
        <div>
          <div className="mf-eyebrow mb-4">Mr. Fluency · Basra, Iraq</div>
          <h1 className="text-[2.6rem] leading-[1.06] sm:text-[3.4rem]">
            Find out exactly how good your English is.
          </h1>
          <p className="mf-prose mt-5 text-lg">
            A professional CEFR placement test, A0 through C2, that takes between five and
            twenty-five minutes and tells you the truth — then shows you which programme to
            join and precisely where in it to start.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link to="/placement" className="cta-test">Take the placement test</Link>
            <Link to="/courses" className="cta-quiet">See the programmes</Link>
          </div>
          <p className="mt-6 text-sm" style={{ color: "var(--ink-3)" }}>
            Free. No account needed. Two attempts, and you can stop and resume at any point.
          </p>
        </div>
        <div className="flex justify-center lg:justify-end"><DoorArt /></div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <div className="grid gap-px overflow-hidden rounded-xl sm:grid-cols-2 lg:grid-cols-4"
          style={{ background: "var(--line)", border: "1px solid var(--line)" }}>
          {STATS.map((s) => (
            <div key={s.k} className="p-5" style={{ background: "var(--surface)" }}>
              <div className="mf-label">{s.k}</div>
              <div className="mf-mono text-3xl" style={{ fontFamily: "var(--display)", lineHeight: 1.1 }}>{s.v}</div>
              <p className="mt-1.5 text-[13px]" style={{ color: "var(--ink-2)" }}>{s.s}</p>
            </div>
          ))}
        </div>
      </section>

      <Section eyebrow="Programmes" title="Four ways to study"
        lead="Every programme is mapped to the CEFR ladder, so you always know which step you are on and what the next one asks of you.">
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {COURSES.map((c) => (
            <Link key={c.id} to="/courses" hash={c.id}
              className="mf-card flex gap-4 p-6 no-underline transition-colors hover:border-[color:var(--brass)]"
              style={{ borderLeft: "3px solid " + c.color, color: "var(--ink)" }}>
              <span style={{ color: c.color, flex: "none" }}><CourseGlyph id={c.id} /></span>
              <div className="min-w-0">
                <h3 className="text-xl">{c.name}</h3>
                <p className="mt-1.5 text-sm" style={{ color: "var(--ink-2)" }}>{c.aim}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {c.levels.map((l) => <LevelChip key={l} level={l} />)}
                </div>
                <p className="mf-mono mt-3 text-xs" style={{ color: "var(--ink-3)" }}>
                  {c.modules.length} modules · {c.modules.reduce((s, m) => s + m.hours, 0)} guided hours
                </p>
              </div>
            </Link>
          ))}
        </div>
      </Section>

      <div style={{ background: "var(--surface)", borderTop: "1px solid var(--line)", borderBottom: "1px solid var(--line)" }}>
        <Section eyebrow="How the placement test works" title="Five steps, in this order"
          lead="The test is adaptive: it climbs one level at a time and stops when it finds your ceiling. That is what makes it short for a beginner and thorough for an advanced candidate.">
          <ol className="mt-8 grid list-none gap-4 p-0 md:grid-cols-2 lg:grid-cols-3">
            {STEPS.map((s) => (
              <li key={s.n} className="flex gap-4 rounded-xl p-5" style={{ background: "var(--chalk)", border: "1px solid var(--line)" }}>
                <span className="mf-mono text-sm font-semibold" style={{ color: "var(--brass)" }}>{s.n}</span>
                <div>
                  <b className="block text-[15px]">{s.t}</b>
                  <p className="mt-1.5 text-sm" style={{ color: "var(--ink-2)" }}>{s.d}</p>
                </div>
              </li>
            ))}
            <li className="flex flex-col justify-center gap-3 rounded-xl p-5"
              style={{ background: "var(--garnet-soft)", border: "1px solid color-mix(in srgb, var(--garnet) 25%, transparent)" }}>
              <b className="text-[15px]">Ready when you are.</b>
              <p className="text-sm" style={{ color: "var(--ink-2)" }}>
                Your progress is saved, so closing the page does not lose your answers or spend an attempt.
              </p>
              <Link to="/placement" className="cta-test" style={{ alignSelf: "flex-start", padding: "11px 20px", fontSize: 15 }}>
                Start now
              </Link>
            </li>
          </ol>
        </Section>
      </div>

      <Section eyebrow="The ladder" title="Where the test places you"
        lead="Seven steps from absolute beginner to proficient. Your result names the step you are standing on, and your programme starts at the module built for it.">
        <div className="mt-8 grid gap-8 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
          <div className="mf-card p-6"><Staircase /></div>
          <dl className="grid gap-3">
            {["A1", "B1", "C1"].map((L) => (
              <div key={L} className="mf-card p-5">
                <dt className="flex items-center gap-2.5">
                  <LevelChip level={L} />
                  <span className="text-lg" style={{ fontFamily: "var(--display)" }}>{LEVEL_INFO[L].name}</span>
                </dt>
                <dd className="mt-2 text-sm" style={{ color: "var(--ink-2)" }}>{LEVEL_INFO[L].can}</dd>
              </div>
            ))}
          </dl>
        </div>
      </Section>

      <section className="mx-auto max-w-6xl px-4 pb-4 sm:px-6">
        <div className="rounded-2xl px-6 py-12 text-center sm:px-12"
          style={{ background: "var(--ink)", color: "var(--chalk)" }}>
          <p className="mf-eyebrow" style={{ color: "var(--brass)" }}>{PROFILE.motto}</p>
          <h2 className="mx-auto mt-4 max-w-2xl text-3xl sm:text-4xl" style={{ color: "var(--chalk)" }}>
            Twenty-five minutes now saves you a term in the wrong class.
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-base" style={{ color: "#C9C2B8" }}>
            Most students who come to me have studied English for years and still cannot say
            what their level is. The test answers that first, before anyone pays for anything.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/placement" className="cta-test">Take the placement test</Link>
            <Link to="/about" className="cta-quiet" style={{ borderColor: "var(--chalk)", color: "var(--chalk)" }}>
              Meet Mr. Fluency
            </Link>
          </div>
        </div>
      </section>
    </Shell>
  );
}
