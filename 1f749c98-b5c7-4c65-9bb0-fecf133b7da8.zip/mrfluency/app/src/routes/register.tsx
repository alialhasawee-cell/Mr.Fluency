import { createFileRoute, redirect } from "@tanstack/react-router";

// Kept so older links keep working: every sign-in now happens at /guest
// (parents and students) or /owner (the academy owner).
export const Route = createFileRoute("/register")({
  beforeLoad: () => { throw redirect({ to: "/guest", search: { mode: "signup" } }); },
});
