import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell } from "../components/shell";
import { LevelChip } from "../components/brand";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Teacher area — Mr. Fluency" }, { name: "robots", content: "noindex" }] }),
  component: Admin,
});

const fmt = (ms: number) => (ms ? new Date(ms).toLocaleString() : "—");

function Admin() {
  const [pass, setPass] = useState("");
  const [data, setData] = useState<any>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function load(action?: string, ckey?: string) {
    setBusy(true); setErr("");
    const r = await fetch("/api/admin", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ pass, action, ckey }),
    });
    const d = await r.json().catch(() => ({}));
    setBusy(false);
    if (!r.ok) {
      setErr(d?.error === "not_configured"
        ? "The teacher area has no passphrase set yet."
        : "That passphrase was not accepted.");
      return;
    }
    setData(d);
  }

  if (!data) return (
    <Shell>
      <div className="mx-auto max-w-md px-4 py-20 sm:px-6">
        <div className="mf-eyebrow mb-3">Teacher area</div>
        <h1 className="text-3xl">Sign in</h1>
        <p className="mf-prose mt-3 text-sm">
          Results, attempts and enquiries for Mr. Fluency only.
        </p>
        <div className="mf-card mt-6 p-6">
          <label className="block"><span className="mf-label">Passphrase</span>
            <input className="mf-field" id="a-pass" type="password" value={pass} autoComplete="current-password"
              onChange={(e) => setPass(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") void load(); }} /></label>
          {err ? <p className="mt-3 text-sm" style={{ color: "var(--danger)" }}>{err}</p> : null}
          <button className="cta-test mt-5 w-full justify-center" onClick={() => load()} disabled={busy}>
            {busy ? "Checking…" : "Open"}
          </button>
        </div>
      </div>
    </Shell>
  );

  const live = data.attempts.filter((a: any) => a.status === "IN_PROGRESS" || a.status === "PAUSED");
  const done = data.attempts.filter((a: any) => a.status === "COMPLETED");

  return (
    <Shell>
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <div className="flex flex-wrap items-end gap-4 border-b pb-4" style={{ borderColor: "var(--line)" }}>
          <div><div className="mf-eyebrow mb-2">Teacher area</div><h1 className="text-3xl">Placement results</h1></div>
          <button className="cta-quiet ml-auto" onClick={() => load()} disabled={busy}>
            {busy ? "Refreshing…" : "Refresh"}
          </button>
        </div>

        <div className="mt-6 grid gap-3 sm:grid-cols-4">
          {[["Completed", done.length], ["Live now", live.length],
            ["Candidates", data.candidates.length], ["Enquiries", data.enquiries.length]].map(([k, v]) => (
            <div key={k as string} className="mf-card p-4">
              <div className="mf-label">{k as string}</div>
              <div className="text-3xl" style={{ fontFamily: "var(--display)" }}>{v as number}</div>
            </div>
          ))}
        </div>

        <h2 className="mt-10 text-2xl">Attempts</h2>
        <div className="mf-card mt-3 overflow-x-auto">
          <table className="mf-table" style={{ minWidth: 820 }}>
            <thead><tr><th>Candidate</th><th>Attempt</th><th>Status</th><th>Level</th><th>Score</th><th>Pauses</th><th>Updated</th></tr></thead>
            <tbody>
              {data.attempts.map((a: any) => {
                const res = a.result ? JSON.parse(a.result) : null;
                return (
                  <tr key={a.id}>
                    <td><b>{a.name}</b><div className="text-xs" style={{ color: "var(--ink-3)" }}>{a.email ?? "no email"}</div></td>
                    <td className="mf-mono">{a.attempt_no}</td>
                    <td className="text-xs">{a.status}</td>
                    <td>{res ? <LevelChip level={res.level} /> : "—"}</td>
                    <td className="mf-mono">{res ? res.percent + "%" : "—"}</td>
                    <td className="mf-mono">{a.pause_count}</td>
                    <td className="text-xs">{fmt(a.updated_at)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <h2 className="mt-10 text-2xl">Candidates &amp; attempts remaining</h2>
        <div className="mf-card mt-3 overflow-x-auto">
          <table className="mf-table" style={{ minWidth: 640 }}>
            <thead><tr><th>Candidate</th><th>Used</th><th>Extra granted</th><th></th></tr></thead>
            <tbody>
              {data.candidates.map((c: any) => (
                <tr key={c.ckey}>
                  <td><b>{c.name}</b><div className="text-xs" style={{ color: "var(--ink-3)" }}>{c.email ?? ""}</div></td>
                  <td className="mf-mono">{c.used} of {2 + c.extra_attempts}</td>
                  <td className="mf-mono">{c.extra_attempts}</td>
                  <td><button className="cta-quiet" style={{ padding: "7px 12px", fontSize: 10 }}
                    onClick={() => load("grant", c.ckey)} disabled={busy}>Grant another attempt</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <h2 className="mt-10 text-2xl">Enquiries</h2>
        <div className="mt-3 grid gap-3">
          {data.enquiries.length === 0 ? <p className="mf-prose text-sm">No enquiries yet.</p> : null}
          {data.enquiries.map((e: any) => (
            <div key={e.id} className="mf-card p-5">
              <div className="flex flex-wrap items-baseline gap-3">
                <b>{e.name}</b>
                <span className="text-xs" style={{ color: "var(--ink-3)" }}>{e.email} {e.phone}</span>
                <span className="mf-mono ml-auto text-xs" style={{ color: "var(--ink-3)" }}>{fmt(e.at)}</span>
              </div>
              <p className="mt-2 text-sm" style={{ color: "var(--ink-2)" }}>{e.message}</p>
            </div>
          ))}
        </div>

        <h2 className="mt-10 text-2xl">Audit trail</h2>
        <div className="mf-card mt-3 overflow-x-auto">
          <table className="mf-table" style={{ minWidth: 560 }}>
            <thead><tr><th>Time</th><th>Event</th><th>Candidate</th><th>Detail</th></tr></thead>
            <tbody>
              {data.trail.map((t: any, i: number) => (
                <tr key={i}>
                  <td className="mf-mono whitespace-nowrap text-xs">{fmt(t.at)}</td>
                  <td className="mf-mono text-xs">{t.event}</td>
                  <td className="text-xs">{t.ckey ?? "—"}</td>
                  <td className="text-xs" style={{ color: "var(--ink-2)" }}>{t.detail ?? ""}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Shell>
  );
}
