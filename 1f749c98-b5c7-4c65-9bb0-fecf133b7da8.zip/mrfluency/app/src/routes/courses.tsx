import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell, Section } from "../components/shell";
import { CourseGlyph, LevelChip } from "../components/brand";
import { api, Spinner } from "../components/session";
import { COURSES } from "../lib/courses";
import { Reveal, WordField } from "../components/motion";
import { LEVEL_LOOK } from "../components/levels";
import { SITE } from "../lib/site";

export const Route = createFileRoute("/courses")({
  head: () => ({
    meta: [
      { title: "Courses — Mr. Fluency" },
      { name: "description", content: "General English, Business English, Email & Business Writing and IELTS Preparation — 28 modules mapped to the CEFR ladder from A0 to C2." },
    ],
    links: [{ rel: "canonical", href: SITE + "/courses" }],
  }),
  component: Courses,
});

const LIVE: Record<string, string> = { gen: "general-english", biz: "business-english", email: "email-writing" };

const LEVELS_OF: Record<string, string[]> = { "general-english": ["A1", "A2", "B1", "B2", "C1"], "business-english": ["B1", "B2", "C1"], "email-writing": ["B1", "B2"] };

function Courses() {
  return (
    <Shell>
      <div className="relative overflow-hidden"><WordField />
      <Section eyebrow="Programmes" title="Four programmes, 28 modules"
        lead="Every module names its level, its guided hours and the language it covers, so you can see exactly what you are buying and how long it takes. Nothing here is a mystery box.">
        <div className="mt-4 flex flex-wrap gap-2">
          {COURSES.map((c) => (
            <a key={c.id} href={"#" + c.id} className="chip-contact" style={{ padding: "8px 14px" }}>
              <span style={{ color: c.color }}><CourseGlyph id={c.id} size={20} /></span>
              <span className="text-sm font-semibold">{c.name}</span>
            </a>
          ))}
        </div>
      </Section></div>

      <LiveCatalogue />

      {COURSES.map((c, i) => (
        <section key={c.id} id={c.id}
          className="mx-auto max-w-6xl scroll-mt-24 px-4 pb-16 sm:px-6"
          style={i % 2 === 1 ? undefined : undefined}>
          <Reveal index={i + 3}>
          <div className="mf-card hoverable overflow-hidden" style={{ borderLeft: "4px solid " + c.color }}>
            <div className="flex flex-wrap items-start gap-5 p-6 sm:p-8">
              <span style={{ color: c.color, flex: "none" }}><CourseGlyph id={c.id} size={48} /></span>
              <div className="min-w-[240px] flex-1">
                <div className="mf-eyebrow">{c.tag}</div>
                <h2 className="mt-1.5 text-3xl">{c.name}</h2>
                <p className="mf-prose mt-3">{c.aim}</p>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {c.levels.map((l) => <LevelChip key={l} level={l} />)}
              </div>
            </div>

            <div className="overflow-x-auto border-t" style={{ borderColor: "var(--line)" }}>
              <table className="mf-table" style={{ minWidth: 640 }}>
                <thead>
                  <tr><th>Code</th><th>Module</th><th>Level</th><th>Hours</th><th>Language focus</th></tr>
                </thead>
                <tbody>
                  {c.modules.map((m) => (
                    <tr key={m.code}>
                      <td className="mf-mono text-xs" style={{ color: "var(--ink-3)" }}>{m.code}</td>
                      <td className="font-semibold">{m.title}</td>
                      <td><LevelChip level={m.level} /></td>
                      <td className="mf-mono">{m.hours}</td>
                      <td style={{ color: "var(--ink-2)", fontSize: 13 }}>{m.focus}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex flex-wrap gap-8 border-t p-6 sm:p-8" style={{ borderColor: "var(--line)" }}>
              <div className="min-w-[240px] flex-1">
                <div className="mf-eyebrow mb-3">On completion you can</div>
                <ul className="m-0 grid list-none gap-2 p-0">
                  {c.outcomes.map((o) => (
                    <li key={o} className="flex gap-2.5 text-sm" style={{ color: "var(--ink-2)" }}>
                      <span style={{ color: c.color }}>▸</span>{o}
                    </li>
                  ))}
                </ul>
              </div>
              {c.bands ? (
                <div>
                  <div className="mf-eyebrow mb-3">Indicative IELTS band</div>
                  <div className="flex flex-wrap gap-2">
                    {c.bands.map((b) => (
                      <span key={b.cefr} className="mf-mono rounded-md px-3 py-1.5 text-xs"
                        style={{ background: "var(--surface-2)", border: "1px solid var(--line)" }}>
                        {b.cefr} → {b.band}
                      </span>
                    ))}
                  </div>
                </div>
              ) : null}
              <div className="flex flex-wrap gap-3 self-end">
                {LIVE[c.id] ? (
                  <Link to="/course/$slug" params={{ slug: LIVE[c.id] }} className="cta-test" style={{ padding: "12px 22px", fontSize: 16 }}>
                    Open {c.name} →
                  </Link>
                ) : (
                  <Link to="/contact" className="cta-resume" style={{ padding: "12px 22px", fontSize: 16 }}>
                    Coming soon — ask Mr. Ali to join
                  </Link>
                )}
                <Link to="/placement" className="cta-quiet">Placement test first</Link>
              </div>
            </div>
          </div>
          </Reveal>
        </section>
      ))}
    </Shell>
  );
}

/** The courses that actually exist in the database, right now. Published
 *  courses only — the server decides what is public, not this component. */
function LiveCatalogue() {
  const [state, setState] = useState<{ loading: boolean; courses: any[] }>({ loading: true, courses: [] });
  useEffect(() => {
    let live = true;
    api.get("/api/lms?what=catalogue").then((r) => {
      if (!live) return;
      setState({ loading: false, courses: Array.isArray(r.data?.courses) ? r.data.courses : [] });
    }).catch(() => live && setState({ loading: false, courses: [] }));
    return () => { live = false; };
  }, []);

  if (state.loading) {
    return <Section tight eyebrow="Open now" title="Available in the platform"><div className="mt-6"><Spinner /></div></Section>;
  }
  if (!state.courses.length) return null;

  return (
    <Section tight eyebrow="Open now" title="Available in the platform"
      lead="These courses are live in the learning platform. Create a free account, enrol, and start the first lesson straight away.">
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {state.courses.map((c: any) => (
          <Reveal key={c.id} variant="zoom"><Link to="/course/$slug" params={{ slug: c.slug }}
            className="mf-card block p-6 no-underline" style={{ color: "var(--ink)" }}>
            <div className="flex items-start gap-4">
              <span style={{ color: "var(--brass)", flex: "none" }}><CourseGlyph id={c.slug} size={36} /></span>
              <div className="min-w-0">
                <h3 className="text-2xl">{c.title}</h3>
                {c.summary ? <p className="mf-prose mt-2 text-sm">{c.summary}</p> : null}
                <div className="mf-mono mt-3 text-xs" style={{ color: "var(--ink-3)" }}>
                  {c.levels} level{c.levels === 1 ? "" : "s"} · {c.modules} module{c.modules === 1 ? "" : "s"} · {c.lessons} lesson{c.lessons === 1 ? "" : "s"}
                </div>
              </div>
            </div>
          </Link>
          {LEVELS_OF[c.slug] ? (
            <div className="mt-3 grid gap-2" style={{ gridTemplateColumns: `repeat(${LEVELS_OF[c.slug].length}, minmax(0,1fr))` }}>
              {LEVELS_OF[c.slug].map((lv, k) => (
                <Reveal key={lv} index={k + 1}>
                  <Link to="/level/$slug/$cefr" params={{ slug: c.slug, cefr: lv }} className="mf-mini-level" style={{ background: LEVEL_LOOK[lv].grad }}>{lv}</Link>
                </Reveal>
              ))}
            </div>
          ) : null}
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
