import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell, Section } from "../components/shell";
import { Monogram, DoorArt, ContactRow } from "../components/brand";
import { PROFILE } from "../lib/courses";
import { SITE } from "../lib/site";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Mr. Fluency — Ali Alhasawee" },
      { name: "description", content: "Ali Alhasawee: IELTS Instructor, Senior English Educator, Linguist, Course Designer and Training Advisor in Basra, Iraq, with over 14 years of experience and more than 8,000 students taught." },
    ],
    links: [{ rel: "canonical", href: SITE + "/about" }],
  }),
  component: About,
});

const METHOD = [
  { n: "01", t: "Communicate", d: "Language is used from the first lesson, not stored up for later." },
  { n: "02", t: "Think", d: "Meaning first — learners work out the rule rather than receive it." },
  { n: "03", t: "Practice", d: "Repeated, purposeful use in situations the learner will actually meet." },
  { n: "04", t: "Make mistakes", d: "Errors are evidence of learning and the material for the next lesson." },
  { n: "05", t: "Receive feedback", d: "Specific, immediate correction against a clear standard." },
  { n: "06", t: "Build confidence", d: "Real-world tasks until performance no longer depends on preparation." },
];

function About() {
  return (
    <Shell>
      <section className="mx-auto grid max-w-6xl items-center gap-10 px-4 pb-6 pt-12 sm:px-6 sm:pt-16 lg:grid-cols-[1.1fr_0.9fr]">
        <div>
          <div className="mf-eyebrow mb-4">Meet Mr. Fluency</div>
          <h1 className="text-[2.4rem] leading-[1.08] sm:text-[3.2rem]">{PROFILE.name}</h1>
          <p className="mt-3 text-lg" style={{ fontFamily: "var(--display)", color: "var(--ink-2)" }}>
            {PROFILE.title}
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            {PROFILE.roles.map((r) => (
              <span key={r} className="rounded-full px-3 py-1 text-xs font-semibold"
                style={{ background: "var(--surface-2)", border: "1px solid var(--line)", color: "var(--ink-2)" }}>{r}</span>
            ))}
          </div>
          <blockquote className="mt-7 border-l-[3px] pl-4 text-2xl"
            style={{ borderColor: "var(--brass)", fontFamily: "var(--display)", fontStyle: "italic" }}>
            “{PROFILE.quote}”
          </blockquote>
        </div>
        <div className="flex justify-center lg:justify-end"><DoorArt /></div>
      </section>

      <Section tight>
        <div className="grid gap-6 lg:grid-cols-[1.4fr_0.6fr]">
          <div className="mf-card p-7">
            <h2 className="text-2xl">Who I am</h2>
            <p className="mf-prose mt-4">
              Mr. Ali Alhasawee is an experienced IELTS Instructor, Senior English Educator, Linguist,
              Course Designer and Training Advisor from Basra, Iraq, with over 14 years of experience
              in English language teaching and professional training.
            </p>
            <p className="mf-prose mt-4">
              With a background in English Literature, international teacher training, and professional
              experience across education, aviation, contracts, translation and corporate environments,
              Mr. Alhasawee brings a practical and professional approach to language learning.
            </p>
            <p className="mf-prose mt-4">
              He has taught and trained more than 8,000 students, helping learners improve their English
              for academic study, IELTS, careers, business, professional communication and everyday life.
            </p>
          </div>
          <div className="mf-card flex flex-col items-center p-7 text-center">
            <Monogram size={140} />
            <h3 className="mt-3 text-xl">{PROFILE.name}</h3>
            <p className="mf-label mt-1">Mr. Fluency</p>
            <Link to="/contact" className="cta-quiet mt-5">Get in touch</Link>
          </div>
        </div>
      </Section>

      <div style={{ background: "var(--surface)", borderTop: "1px solid var(--line)", borderBottom: "1px solid var(--line)" }}>
        <Section eyebrow="Teaching philosophy" title="More than just English">
          <p className="mf-prose mt-4">
            Mr. Fluency's teaching philosophy combines Communicative Language Teaching (CLT) with a
            Principled Eclectic approach, selecting the most effective techniques according to each
            learner's needs, level and goals.
          </p>
          <p className="mf-prose mt-4">
            His courses are designed to move students beyond memorising vocabulary and grammar.
            Learners are encouraged to communicate, think, practice, make mistakes, receive feedback,
            and build real-world confidence.
          </p>
          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {METHOD.map((m) => (
              <div key={m.n} className="flex gap-3 rounded-xl p-5"
                style={{ background: "var(--chalk)", border: "1px solid var(--line)" }}>
                <span className="mf-mono text-xs font-semibold" style={{ color: "var(--brass)" }}>{m.n}</span>
                <div>
                  <b className="block text-[15px]">{m.t}</b>
                  <p className="mt-1 text-sm" style={{ color: "var(--ink-2)" }}>{m.d}</p>
                </div>
              </div>
            ))}
          </div>
        </Section>
      </div>

      <Section>
        <div className="mf-card p-8 text-center">
          <p className="mf-prose mx-auto text-lg">
            Whether your goal is a higher IELTS score, confident communication, success at work,
            study abroad, or simply becoming fluent in English, Mr. Fluency provides practical
            learning designed to help you take the next step.
          </p>
          <p className="mt-6 text-3xl" style={{ fontFamily: "var(--display)", color: "var(--brass)" }}>
            {PROFILE.motto}
          </p>
          <p className="mt-3 text-sm" style={{ color: "var(--ink-2)" }}>
            Welcome to Mr. Fluency — where English becomes your key to new opportunities.
          </p>
          <div className="mt-8"><ContactRow /></div>
        </div>
      </Section>
    </Shell>
  );
}
