import { createFileRoute } from "@tanstack/react-router";
import { bindings } from "../../lib/bindings.server";

// Teacher-only data. The passphrase is a deployment secret, never in source,
// and is compared in constant time so the endpoint cannot be probed by timing.
function constantEquals(a: string, b: string) {
  const enc = new TextEncoder();
  const x = enc.encode(a), y = enc.encode(b);
  let diff = x.length ^ y.length;
  for (let i = 0; i < Math.max(x.length, y.length); i++) diff |= (x[i] ?? 0) ^ (y[i] ?? 0);
  return diff === 0;
}
export const Route = createFileRoute("/api/admin")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let b: any;
        try { b = await request.json(); } catch { return Response.json({ error: "bad_request" }, { status: 400 }); }
        const env = bindings() as Record<string, any>;
        const secret = typeof env.ADMIN_PASSPHRASE === "string" ? env.ADMIN_PASSPHRASE : "";
        if (!secret) return Response.json({ error: "not_configured" }, { status: 503 });
        const pass = typeof b?.pass === "string" ? b.pass : "";
        if (!constantEquals(pass, secret)) {
          await new Promise((r) => setTimeout(r, 400));
          return Response.json({ error: "denied" }, { status: 401 });
        }
        const d = bindings().DB;
        if (!d) return Response.json({ error: "unavailable" }, { status: 503 });

        if (b?.action === "grant" && typeof b?.ckey === "string") {
          await d.prepare("UPDATE candidates SET extra_attempts = extra_attempts + 1 WHERE ckey=?").bind(b.ckey).run();
          await d.prepare("INSERT INTO audit (id,attempt_id,ckey,event,detail,at) VALUES (?,?,?,?,?,?)")
            .bind(crypto.randomUUID(), null, b.ckey, "ADMIN_RESET_ATTEMPT", null, Date.now()).run();
        }
        const attempts = (await d.prepare(
          `SELECT id,ckey,name,email,goal,attempt_no,status,bi,qi,pause_count,total_paused_ms,
           created_at,updated_at,completed_at,result FROM attempts ORDER BY updated_at DESC LIMIT 200`).all()).results;
        const enquiries = (await d.prepare("SELECT * FROM enquiries ORDER BY at DESC LIMIT 100").all()).results;
        const trail = (await d.prepare("SELECT event,ckey,detail,at FROM audit ORDER BY at DESC LIMIT 200").all()).results;
        const candidates = (await d.prepare(
          `SELECT c.ckey,c.name,c.email,c.extra_attempts,
           (SELECT COUNT(*) FROM attempts a WHERE a.ckey=c.ckey AND a.status IN ('COMPLETED','EXPIRED')) AS used
           FROM candidates c ORDER BY c.created_at DESC LIMIT 200`).all()).results;
        return Response.json({ ok: true, attempts, enquiries, trail, candidates },
          { headers: { "cache-control": "no-store" } });
      },
    },
  },
});
