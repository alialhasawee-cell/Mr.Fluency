import { createFileRoute } from "@tanstack/react-router";
import { currentUser } from "../../lib/auth.server";
import { listAlerts, markAlertsRead, testAlert, alertChannels } from "../../lib/alerts.server";

const json = (b: unknown, s = 200) => Response.json(b, { status: s, headers: { "cache-control": "no-store" } });

async function owner(request: Request) {
  const u = await currentUser(request);
  return u && (u.role === "owner" || u.role === "admin") ? u : null;
}

export const Route = createFileRoute("/api/alerts")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        if (!(await owner(request))) return json({ error: "forbidden" }, 403);
        const out = await listAlerts(150);
        return json({ ...out, channels: alertChannels() });
      },
      POST: async ({ request }) => {
        if (!(await owner(request))) return json({ error: "forbidden" }, 403);
        let b: any; try { b = await request.json(); } catch { return json({ error: "bad_request" }, 400); }
        if (b?.action === "read") { await markAlertsRead(Array.isArray(b.ids) ? b.ids.map(String) : []); return json({ ok: true }); }
        if (b?.action === "read_all") { await markAlertsRead(); return json({ ok: true }); }
        if (b?.action === "test") { const result = await testAlert(); return json({ ok: true, result }); }
        return json({ error: "unknown_action" }, 400);
      },
    },
  },
});
