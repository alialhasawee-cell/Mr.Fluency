import { createFileRoute } from "@tanstack/react-router";
import { requireRole, db } from "../../lib/auth.server";
import { bindings } from "../../lib/bindings.server";

const json = (b: unknown, s = 200) => Response.json(b, { status: s, headers: { "cache-control": "no-store" } });
const MAX_SMALL = 90 * 1024 * 1024;           // single-request uploads (Workers body limit is ~100 MB)
const MAX_LARGE = 4 * 1024 * 1024 * 1024;     // chunked uploads: up to 4 GB per file
const KINDS: Record<string, string> = {
  "image/": "image", "audio/": "audio", "video/": "video",
  "application/pdf": "pdf", "application/json": "animation",
};
function kindOf(mime: string) {
  for (const [k, v] of Object.entries(KINDS)) if (mime === k || mime.startsWith(k)) return v;
  return "document";
}
const extOf = (name: string) => (name.split(".").pop() ?? "bin").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 8) || "bin";
const okKey = (k: unknown): k is string => typeof k === "string" && /^media\/[a-z]+\/[0-9a-f-]{36}\.[a-z0-9]{1,8}$/.test(k);

async function recordMedia(input: {
  key: string; title: string; mime: string; bytes: number; userId: string;
  description?: string; courseId?: string | null; lessonId?: string | null; duration?: number | null;
}) {
  // Idempotent: a retried "finish" after a network blip returns the same row.
  const existing = await db().prepare("SELECT id,url,kind FROM media WHERE storage_key=?").bind(input.key).first<any>();
  if (existing) return existing as { id: string; url: string; kind: string };
  const id = crypto.randomUUID(), kind = kindOf(input.mime), url = "/api/file/" + input.key;
  await db().prepare(
    `INSERT INTO media (id,title,description,kind,url,storage_key,mime,bytes,duration_s,alt,course_id,
     lesson_id,created_by,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .bind(id, input.title.slice(0, 160), (input.description ?? "").slice(0, 1000), kind, url, input.key, input.mime,
      input.bytes, input.duration || null, "", input.courseId || null, input.lessonId || null, input.userId, Date.now()).run();
  return { id, url, kind };
}

export const Route = createFileRoute("/api/media")({
  server: {
    handlers: {
      // Media listing is staff-only; students reach files through a lesson.
      GET: async ({ request }) => {
        const g = await requireRole(request, "teacher");
        if ("error" in g) return json(g, g.status);
        const kind = new URL(request.url).searchParams.get("kind");
        const rows = kind
          ? (await db().prepare("SELECT * FROM media WHERE kind=? ORDER BY created_at DESC LIMIT 200").bind(kind).all()).results
          : (await db().prepare("SELECT * FROM media ORDER BY created_at DESC LIMIT 200").all()).results;
        return json({ media: rows });
      },

      POST: async ({ request }) => {
        const g = await requireRole(request, "admin");
        if ("error" in g) return json(g, g.status);
        const store = bindings().STORAGE;
        if (!store) return json({ error: "storage_unavailable" }, 503);
        const url = new URL(request.url);
        const op = url.searchParams.get("op");

        // ---- chunked (multipart) upload for large lesson videos ----
        if (op === "start") {
          const b: any = await request.json().catch(() => ({}));
          const size = Number(b?.size) || 0;
          const mime = String(b?.type || "application/octet-stream").slice(0, 100);
          if (size <= 0) return json({ error: "empty_file" }, 400);
          if (size > MAX_LARGE) return json({ error: "too_large" }, 413);
          const key = `media/${kindOf(mime)}/${crypto.randomUUID()}.${extOf(String(b?.name ?? ""))}`;
          const mpu = await store.createMultipartUpload(key, { httpMetadata: { contentType: mime } });
          return json({ key, uploadId: mpu.uploadId });
        }
        if (op === "part") {
          const key = url.searchParams.get("key"), uploadId = url.searchParams.get("uploadId") ?? "";
          const n = Number(url.searchParams.get("n"));
          if (!okKey(key) || !uploadId || !(n >= 1 && n <= 10000)) return json({ error: "bad_request" }, 400);
          const body = await request.arrayBuffer();
          if (!body.byteLength || body.byteLength > 60 * 1024 * 1024) return json({ error: "bad_chunk" }, 400);
          try {
            const part = await store.resumeMultipartUpload(key, uploadId).uploadPart(n, body);
            return json({ partNumber: part.partNumber, etag: part.etag });
          } catch (e) {
            return json({ error: "part_failed", message: String((e as Error)?.message ?? e).slice(0, 200) }, 502);
          }
        }
        if (op === "finish") {
          const b: any = await request.json().catch(() => ({}));
          if (!okKey(b?.key) || !b?.uploadId || !Array.isArray(b?.parts) || !b.parts.length) return json({ error: "bad_request" }, 400);
          const parts = b.parts.map((p: any) => ({ partNumber: Number(p.partNumber), etag: String(p.etag) }))
            .sort((a: any, z: any) => a.partNumber - z.partNumber);
          try {
            await store.resumeMultipartUpload(b.key, String(b.uploadId)).complete(parts);
          } catch (e) {
            // If a previous finish completed the object but the response was lost, carry on.
            if (!(await store.head(b.key))) return json({ error: "complete_failed", message: String((e as Error)?.message ?? e).slice(0, 200) }, 502);
          }
          const head = await store.head(b.key);
          const row = await recordMedia({
            key: b.key, title: String(b?.title ?? "Untitled"), mime: head?.httpMetadata?.contentType ?? String(b?.type ?? ""),
            bytes: (head?.size ?? Number(b?.size)) || 0, userId: g.user.id, description: String(b?.description ?? ""),
            courseId: b?.course_id ? String(b.course_id) : null, lessonId: b?.lesson_id ? String(b.lesson_id) : null,
            duration: Number(b?.duration_s) || null,
          });
          return json({ ok: true, ...row });
        }
        if (op === "abort") {
          const b: any = await request.json().catch(() => ({}));
          if (okKey(b?.key) && b?.uploadId) {
            try { await store.resumeMultipartUpload(b.key, String(b.uploadId)).abort(); } catch { /* already gone */ }
          }
          return json({ ok: true });
        }
        if (op === "delete") {
          const b: any = await request.json().catch(() => ({}));
          const row = await db().prepare("SELECT id,storage_key FROM media WHERE id=?").bind(String(b?.id ?? "")).first<any>();
          if (!row) return json({ error: "not_found" }, 404);
          if (row.storage_key) await store.delete(row.storage_key);
          await db().prepare("DELETE FROM media WHERE id=?").bind(row.id).run();
          return json({ ok: true });
        }

        // ---- simple single-request upload (images, PDFs, short clips) ----
        const form = await request.formData();
        const file = form.get("file");
        if (!(file instanceof File)) return json({ error: "missing_file" }, 400);
        if (file.size > MAX_SMALL) return json({ error: "too_large" }, 413);
        const mime = file.type || "application/octet-stream";
        const key = `media/${kindOf(mime)}/${crypto.randomUUID()}.${extOf(file.name)}`;
        await store.put(key, await file.arrayBuffer(), { httpMetadata: { contentType: mime } });
        const row = await recordMedia({
          key, title: String(form.get("title") ?? file.name), mime, bytes: file.size, userId: g.user.id,
          description: String(form.get("description") ?? ""), courseId: String(form.get("course_id") ?? "") || null,
          lessonId: String(form.get("lesson_id") ?? "") || null, duration: Number(form.get("duration_s")) || null,
        });
        return json({ ok: true, ...row });
      },
    },
  },
});
