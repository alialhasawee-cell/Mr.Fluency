import { createFileRoute } from "@tanstack/react-router";
import { requireUser } from "../../lib/auth.server";
import { startQuiz, quizState, answerQuiz, pauseQuiz, resumeQuiz } from "../../lib/quiz.server";

const json = (b: unknown, s = 200) => Response.json(b, { status: s, headers: { "cache-control": "no-store" } });
const S = (v: unknown, m = 60) => (typeof v === "string" ? v.trim().slice(0, m) : "");

export const Route = createFileRoute("/api/quiz")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const g = await requireUser(request);
        if ("error" in g) return json(g, g.status);
        const id = S(new URL(request.url).searchParams.get("attempt") ?? "");
        if (!id) return json({ error: "no_attempt" }, 400);
        const out = await quizState(g.user.id, id);
        return "error" in out ? json(out, 404) : json(out);
      },
      POST: async ({ request }) => {
        const g = await requireUser(request);
        if ("error" in g) return json(g, g.status);
        let b: any;
        try { b = await request.json(); } catch { return json({ error: "bad_request" }, 400); }
        const action = String(b?.action ?? "");

        if (action === "start") {
          const out = await startQuiz(g.user.id, S(b?.quizId), ["owner", "admin", "teacher"].includes(g.user.role));
          if ("error" in out) return json(out, 400);
          return json(await quizState(g.user.id, out.attemptId));
        }
        const attempt = S(b?.attemptId);
        if (!attempt) return json({ error: "no_attempt" }, 400);

        if (action === "answer") {
          const out = await answerQuiz(g.user.id, attempt, S(b?.questionId), b?.response);
          if ("error" in out) return json(out, 409);
          return json(await quizState(g.user.id, attempt));
        }
        if (action === "pause") {
          const out = await pauseQuiz(g.user.id, attempt);
          if ("error" in out) return json(out, 409);
          return json(await quizState(g.user.id, attempt));
        }
        if (action === "resume") {
          const out = await resumeQuiz(g.user.id, attempt);
          if ("error" in out) return json(out, 409);
          return json(await quizState(g.user.id, attempt));
        }
        return json({ error: "unknown_action" }, 400);
      },
    },
  },
});
