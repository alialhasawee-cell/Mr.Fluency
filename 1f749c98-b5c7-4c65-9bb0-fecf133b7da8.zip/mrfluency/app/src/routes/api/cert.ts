import { createFileRoute } from "@tanstack/react-router";
import { verifyCode } from "../../lib/certificates.server";

// Public, read-only, rate-friendly: takes a code, answers valid or not.
// It deliberately exposes no account, email or course-progress data.
export const Route = createFileRoute("/api/cert")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const code = new URL(request.url).searchParams.get("code") ?? "";
        if (!code) return Response.json({ valid: false, reason: "no_code" }, { status: 400 });
        return Response.json(await verifyCode(code), { headers: { "cache-control": "no-store" } });
      },
    },
  },
});
