import { createFileRoute } from "@tanstack/react-router";
import { requireRole, db, hashPassword, normEmail, validEmail, beginReset } from "../../lib/auth.server";
import {
  upsertCourse, upsertLevel, upsertModule, upsertLesson, upsertBlock,
  upsertQuestion, upsertQuiz, setStatus, reorder, removeBlock, duplicateLesson,
} from "../../lib/cms.server";
import { courseTree, catalogue, enroll } from "../../lib/lms.server";

const json = (b: unknown, s = 200) => Response.json(b, { status: s, headers: { "cache-control": "no-store" } });
const S = (v: unknown, m = 80) => (typeof v === "string" ? v.trim().slice(0, m) : "");

export const Route = createFileRoute("/api/cms")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const g = await requireRole(request, "admin");
        if ("error" in g) return json(g, g.status);
        const url = new URL(request.url);
        const what = url.searchParams.get("what") ?? "overview";

        if (what === "overview") {
          const one = async (sql: string, ...a: any[]) =>
            (await db().prepare(sql).bind(...a).first<{ n: number }>())?.n ?? 0;
          const since = Date.now() - 30 * 864e5;
          return json({
            counts: {
              students: await one("SELECT COUNT(*) AS n FROM users WHERE role='student'"),
              activeStudents: await one("SELECT COUNT(*) AS n FROM users WHERE role='student' AND last_active > ?", since),
              newRegistrations: await one("SELECT COUNT(*) AS n FROM users WHERE created_at > ?", since),
              courses: await one("SELECT COUNT(*) AS n FROM courses"),
              lessons: await one("SELECT COUNT(*) AS n FROM lessons"),
              quizzes: await one("SELECT COUNT(*) AS n FROM quizzes"),
              questions: await one("SELECT COUNT(*) AS n FROM questions"),
              enrollments: await one("SELECT COUNT(*) AS n FROM enrollments WHERE status='active'"),
              completions: await one("SELECT COUNT(*) AS n FROM enrollments WHERE status='completed'"),
              certificates: await one("SELECT COUNT(*) AS n FROM certificates WHERE revoked=0"),
              placements: await one("SELECT COUNT(*) AS n FROM attempts WHERE status='COMPLETED'"),
              media: await one("SELECT COUNT(*) AS n FROM media"),
            },
            avgQuiz: (await db().prepare(
              "SELECT AVG(pct) AS a FROM quiz_attempts WHERE status='COMPLETED'").first<{ a: number | null }>())?.a ?? null,
            levels: (await db().prepare(
              `SELECT json_extract(result,'$.level') AS lvl, COUNT(*) AS n FROM attempts
               WHERE status='COMPLETED' AND result IS NOT NULL GROUP BY lvl`).all()).results,
            popular: (await db().prepare(
              `SELECT c.title, COUNT(e.id) AS n FROM courses c LEFT JOIN enrollments e ON e.course_id=c.id
               GROUP BY c.id ORDER BY n DESC LIMIT 6`).all()).results,
            recentStudents: (await db().prepare(
              `SELECT id,name,email,cefr_level,xp,created_at,last_active FROM users WHERE role='student'
               ORDER BY created_at DESC LIMIT 12`).all()).results,
          });
        }
        if (what === "courses") return json({ courses: await catalogue(true) });
        if (what === "tree") return json(await courseTree(S(url.searchParams.get("courseId") ?? "", 60), true));
        if (what === "lesson") {
          const id = S(url.searchParams.get("id") ?? "", 60);
          const lesson = await db().prepare("SELECT * FROM lessons WHERE id=?").bind(id).first<any>();
          const blocks = (await db().prepare(
            "SELECT * FROM lesson_blocks WHERE lesson_id=? ORDER BY sort").bind(id).all()).results;
          return json({ lesson, blocks });
        }
        if (what === "questions") {
          const bank = url.searchParams.get("bank");
          const rows = (await db().prepare(
            `SELECT id,bank,type,cefr,skill,topic,difficulty,prompt,points,status FROM questions
             ${bank ? "WHERE bank=?" : ""} ORDER BY created_at DESC LIMIT 300`)
            .bind(...(bank ? [bank] : [])).all()).results;
          return json({ questions: rows });
        }
        if (what === "question") {
          const id = S(url.searchParams.get("id") ?? "", 60);
          const q = await db().prepare("SELECT * FROM questions WHERE id=?").bind(id).first<any>();
          const options = (await db().prepare(
            "SELECT * FROM question_options WHERE question_id=? ORDER BY sort").bind(id).all()).results;
          return json({ question: q, options });
        }
        if (what === "students") {
          const q = S(url.searchParams.get("q") ?? "", 60);
          const rows = q
            ? (await db().prepare(
                `SELECT id,name,email,role,status,cefr_level,xp,created_at,last_active FROM users
                 WHERE name LIKE ? OR email LIKE ? ORDER BY created_at DESC LIMIT 100`)
                .bind("%" + q + "%", "%" + q + "%").all()).results
            : (await db().prepare(
                `SELECT id,name,email,role,status,cefr_level,xp,created_at,last_active FROM users
                 ORDER BY created_at DESC LIMIT 100`).all()).results;
          return json({ students: rows });
        }
        if (what === "student") {
          const id = S(url.searchParams.get("id") ?? "", 60);
          const user = await db().prepare(
            "SELECT id,name,email,phone,role,status,cefr_level,xp,created_at,last_active FROM users WHERE id=?")
            .bind(id).first<any>();
          if (!user) return json({ error: "not_found" }, 404);
          return json({
            user,
            enrollments: (await db().prepare(
              `SELECT e.*, c.title FROM enrollments e JOIN courses c ON c.id=e.course_id WHERE e.user_id=?`)
              .bind(id).all()).results,
            quizzes: (await db().prepare(
              `SELECT qa.*, q.title FROM quiz_attempts qa JOIN quizzes q ON q.id=qa.quiz_id
               WHERE qa.user_id=? ORDER BY qa.updated_at DESC LIMIT 40`).bind(id).all()).results,
            placements: (await db().prepare(
              `SELECT attempt_no,status,result,completed_at FROM attempts WHERE user_id=? OR email=?
               ORDER BY created_at DESC LIMIT 10`).bind(id, user.email).all()).results,
            certificates: (await db().prepare("SELECT * FROM certificates WHERE user_id=?").bind(id).all()).results,
            progress: (await db().prepare(
              `SELECT p.*, l.title FROM progress p JOIN lessons l ON l.id=p.lesson_id WHERE p.user_id=?
               ORDER BY p.updated_at DESC LIMIT 60`).bind(id).all()).results,
          });
        }
        if (what === "certificates") {
          return json({ certificates: (await db().prepare(
            "SELECT * FROM certificates ORDER BY issued_at DESC LIMIT 200").all()).results });
        }
        if (what === "search") {
          const q = "%" + S(url.searchParams.get("q") ?? "", 60) + "%";
          return json({
            students: (await db().prepare(
              "SELECT id,name,email FROM users WHERE name LIKE ? OR email LIKE ? LIMIT 10").bind(q, q).all()).results,
            courses: (await db().prepare("SELECT id,title,slug FROM courses WHERE title LIKE ? LIMIT 10").bind(q).all()).results,
            lessons: (await db().prepare("SELECT id,title,course_id FROM lessons WHERE title LIKE ? LIMIT 10").bind(q).all()).results,
            questions: (await db().prepare("SELECT id,prompt,cefr,skill FROM questions WHERE prompt LIKE ? LIMIT 10").bind(q).all()).results,
            certificates: (await db().prepare("SELECT code,student_name,course_title FROM certificates WHERE code LIKE ? OR student_name LIKE ? LIMIT 10").bind(q, q).all()).results,
          });
        }
        return json({ error: "unknown" }, 400);
      },

      POST: async ({ request }) => {
        const g = await requireRole(request, "admin");
        if ("error" in g) return json(g, g.status);
        let b: any;
        try { b = await request.json(); } catch { return json({ error: "bad_request" }, 400); }
        const a = String(b?.action ?? "");
        const actor = g.user.id;
        const call = async (fn: Promise<any>) => { const r = await fn; return "error" in r ? json(r, 400) : json(r); };

        switch (a) {
          case "batch": {
            // Several saves in one request (course import tool). Items run in order;
            // the first failure stops the batch and is reported with its index.
            const items = Array.isArray(b?.items) ? b.items.slice(0, 120) : [];
            const fns: Record<string, (a: string, x: any) => Promise<any>> = {
              level: upsertLevel, module: upsertModule, lesson: upsertLesson, block: upsertBlock,
              question: upsertQuestion, quiz: upsertQuiz, course: upsertCourse,
            };
            const ids: string[] = [];
            for (let i = 0; i < items.length; i++) {
              const fn = fns[String(items[i]?.kind)];
              if (!fn) return json({ error: "bad_kind", index: i }, 400);
              const r = await fn(actor, items[i].data ?? {});
              if (r && "error" in r) return json({ ...r, index: i }, 400);
              ids.push(r.id);
            }
            return json({ ok: true, ids });
          }
          case "save_course": return call(upsertCourse(actor, b.course ?? {}));
          case "save_level": return call(upsertLevel(actor, b.level ?? {}));
          case "save_module": return call(upsertModule(actor, b.module ?? {}));
          case "save_lesson": return call(upsertLesson(actor, b.lesson ?? {}));
          case "save_block": return call(upsertBlock(actor, b.block ?? {}));
          case "save_question": return call(upsertQuestion(actor, b.question ?? {}));
          case "save_quiz": return call(upsertQuiz(actor, b.quiz ?? {}));
          case "set_status": return call(setStatus(actor, S(b?.kind, 20), S(b?.id, 60), S(b?.status, 20)));
          case "reorder": return call(reorder(actor, S(b?.kind, 20), Array.isArray(b?.ids) ? b.ids : []));
          case "delete_block": return call(removeBlock(S(b?.id, 60)));
          case "duplicate_lesson": return call(duplicateLesson(actor, S(b?.lessonId, 60)));
          case "enroll_student":
            return call(enroll(S(b?.userId, 60), S(b?.courseId, 60), { source: "admin", levelId: S(b?.levelId, 60) || undefined }));
          case "set_user_status": {
            if (g.user.role !== "owner") return json({ error: "forbidden" }, 403);
            const target = S(b?.userId, 60);
            const t = await db().prepare("SELECT role FROM users WHERE id=?").bind(target).first<any>();
            if (!t || t.role === "owner") return json({ error: "protected" }, 403);
            await db().prepare("UPDATE users SET status=?, updated_at=? WHERE id=?")
              .bind(S(b?.status, 20) === "suspended" ? "suspended" : "active", Date.now(), target).run();
            return json({ ok: true });
          }
          case "reset_code": {
            // Owner creates a one-hour password reset code to send to a student or parent.
            if (g.user.role !== "owner") return json({ error: "forbidden" }, 403);
            const t = await db().prepare("SELECT email, role FROM users WHERE id=?").bind(S(b?.userId, 60)).first<any>();
            if (!t || t.role === "owner") return json({ error: "protected" }, 403);
            const r = await beginReset(t.email);
            return json({ ok: true, code: (r as any).token ?? null });
          }
          case "set_user_role": {
            // Only the owner may grant roles, and the owner role itself is not grantable here.
            if (g.user.role !== "owner") return json({ error: "forbidden" }, 403);
            const role = S(b?.role, 20);
            if (!["student", "teacher", "admin"].includes(role)) return json({ error: "bad_role" }, 400);
            await db().prepare("UPDATE users SET role=?, updated_at=? WHERE id=? AND role != 'owner'")
              .bind(role, Date.now(), S(b?.userId, 60)).run();
            return json({ ok: true });
          }
          case "create_student": {
            if (!validEmail(normEmail(b?.email))) return json({ error: "email_invalid" }, 400);
            const id = crypto.randomUUID(), t = Date.now();
            await db().prepare(
              `INSERT INTO users (id,email,name,password_hash,role,status,email_verified,xp,streak_days,created_at,updated_at)
               VALUES (?,?,?,?,'student','active',1,0,0,?,?)`)
              .bind(id, normEmail(b.email), S(b?.name, 80) || "Student",
                await hashPassword(S(b?.password, 200) || crypto.randomUUID()), t, t).run();
            return json({ ok: true, id });
          }
          case "revoke_certificate": {
            await db().prepare("UPDATE certificates SET revoked=1, revoked_reason=? WHERE code=?")
              .bind(S(b?.reason, 200), S(b?.code, 40)).run();
            return json({ ok: true });
          }
          case "announce": {
            await db().prepare(
              "INSERT INTO announcements (id,title,body,audience,created_by,created_at) VALUES (?,?,?,?,?,?)")
              .bind(crypto.randomUUID(), S(b?.title, 160), S(b?.body, 4000), S(b?.audience, 20) || "all", actor, Date.now()).run();
            const users = (await db().prepare("SELECT id FROM users WHERE role='student'").all()).results as any[];
            for (const u of users) {
              await db().prepare(
                "INSERT INTO notifications (id,user_id,kind,title,body,created_at) VALUES (?,?,?,?,?,?)")
                .bind(crypto.randomUUID(), u.id, "announcement", S(b?.title, 120), S(b?.body, 400), Date.now()).run();
            }
            return json({ ok: true, sent: users.length });
          }
          default: return json({ error: "unknown_action" }, 400);
        }
      },
    },
  },
});
