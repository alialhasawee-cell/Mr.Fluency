import { createFileRoute } from "@tanstack/react-router";
import { currentUser, requireUser } from "../../lib/auth.server";
import {
  catalogue, courseBySlug, courseTree, lessonWithBlocks, enroll, enrollmentsFor, isEnrolled,
  accessMap, placedLevel, canOpenLesson, startLesson, checkOff, tryCompleteLesson, dashboardFor, progressFor,
} from "../../lib/lms.server";
import { issueIfEarned } from "../../lib/certificates.server";

const json = (b: unknown, s = 200) => Response.json(b, { status: s, headers: { "cache-control": "no-store" } });
const S = (v: unknown, m = 80) => (typeof v === "string" ? v.trim().slice(0, m) : "");

export const Route = createFileRoute("/api/lms")({
  server: {
    handlers: {
      // Public reads: the catalogue and a course outline. Never lesson content.
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const what = url.searchParams.get("what") ?? "catalogue";
        const user = await currentUser(request);
        const staff = !!user && (user.role === "owner" || user.role === "admin");

        if (what === "catalogue") return json({ courses: await catalogue(staff) });
        if (what === "course") {
          const slug = S(url.searchParams.get("slug") ?? "", 60);
          const c = await courseBySlug(slug, staff);
          if (!c) return json({ error: "not_found" }, 404);
          const tree = await courseTree(c.id, staff);
          const enrolled = user ? await isEnrolled(user.id, c.id) : false;
          const access = user && enrolled ? await accessMap(user.id, c.id) : null;
          const placed = user ? (access?.placed ?? await placedLevel(user.id)) : null;
          return json({ course: c, tree, enrolled, access: access?.map ?? null, levels: access?.levels ?? null, placed, done: access?.done ?? [] });
        }
        if (what === "dashboard") {
          const g = await requireUser(request);
          if ("error" in g) return json(g, g.status);
          return json(await dashboardFor(g.user));
        }
        if (what === "lesson") {
          const g = await requireUser(request);
          if ("error" in g) return json(g, g.status);
          const id = S(url.searchParams.get("id") ?? "", 60);
          const isStaff = g.user.role === "owner" || g.user.role === "admin" || g.user.role === "teacher";
          const gate = await canOpenLesson(g.user.id, id, isStaff);
          if (!gate.ok) return json({ error: "locked", reason: gate.reason }, 403);
          // Staff see the teacher notes for the lesson they are about to teach;
          // students never receive them at all.
          const lesson = await lessonWithBlocks(id, isStaff);
          const prog = await progressFor(g.user.id, gate.courseId!);
          const mine = prog.find((p) => p.lesson_id === id);
          return json({ lesson, progress: mine ?? null });
        }
        if (what === "my_courses") {
          const g = await requireUser(request);
          if ("error" in g) return json(g, g.status);
          return json({ courses: await enrollmentsFor(g.user.id) });
        }
        return json({ error: "unknown" }, 400);
      },

      POST: async ({ request }) => {
        const g = await requireUser(request);
        if ("error" in g) return json(g, g.status);
        let b: any;
        try { b = await request.json(); } catch { return json({ error: "bad_request" }, 400); }
        const action = String(b?.action ?? "");

        if (action === "enroll") {
          const isStaffUser = ["owner", "admin", "teacher"].includes(g.user.role);
          if (!isStaffUser && !(await placedLevel(g.user.id))) {
            return json({ error: "placement_required", message: "Take the placement test first." }, 403);
          }
          const out = await enroll(g.user.id, S(b?.courseId, 60), { levelId: S(b?.levelId, 60) || undefined });
          return "error" in out ? json(out, 400) : json(out);
        }
        if (action === "start_lesson") {
          const out = await startLesson(g.user.id, S(b?.lessonId, 60));
          return "error" in out ? json(out, 403) : json(out);
        }
        if (action === "check_off") {
          const gate = await canOpenLesson(g.user.id, S(b?.lessonId, 60));
          if (!gate.ok) return json({ error: "locked" }, 403);
          const out = await checkOff(g.user.id, S(b?.lessonId, 60), S(b?.key, 60), Number(b?.seconds) || 0);
          return "error" in out ? json(out, 400) : json(out);
        }
        if (action === "complete_lesson") {
          const gate = await canOpenLesson(g.user.id, S(b?.lessonId, 60));
          if (!gate.ok) return json({ error: "locked" }, 403);
          const out = await tryCompleteLesson(g.user.id, S(b?.lessonId, 60));
          if ("error" in out) return json(out, 400);
          if (out.completed && gate.courseId) {
            const cert = await issueIfEarned(g.user.id, gate.courseId);
            return json({ ...out, certificate: cert.issued ? cert.code : null });
          }
          return json(out);
        }
        return json({ error: "unknown_action" }, 400);
      },
    },
  },
});
