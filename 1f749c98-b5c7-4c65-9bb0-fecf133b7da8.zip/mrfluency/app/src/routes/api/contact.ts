import { createFileRoute } from "@tanstack/react-router";
import { bindings } from "../../lib/bindings.server";
import { alertOwner } from "../../lib/alerts.server";

const str = (v: unknown, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");

export const Route = createFileRoute("/api/contact")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let b: any;
        try { b = await request.json(); } catch { return Response.json({ error: "bad_request" }, { status: 400 }); }
        const name = str(b?.name, 80);
        const message = str(b?.message, 2000);
        if (!name || !message) return Response.json({ error: "name_and_message_required" }, { status: 400 });
        const d = bindings().DB;
        if (!d) return Response.json({ error: "unavailable" }, { status: 503 });
        await d.prepare("INSERT INTO enquiries (id,name,email,phone,goal,message,at) VALUES (?,?,?,?,?,?,?)")
          .bind(crypto.randomUUID(), name, str(b?.email, 120) || null, str(b?.phone, 40) || null,
            str(b?.goal, 40) || null, message, Date.now()).run();
        await alertOwner("enquiry", "New question from " + name, [
          "Name: " + name,
          str(b?.email, 120) ? "Email: " + str(b?.email, 120) : "",
          str(b?.phone, 40) ? "Phone: " + str(b?.phone, 40) : "",
          str(b?.goal, 40) ? "About: " + str(b?.goal, 40) : "",
          "",
          message,
        ], "/studio");
        return Response.json({ ok: true });
      },
    },
  },
});
