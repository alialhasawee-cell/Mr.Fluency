import { createFileRoute } from "@tanstack/react-router";
import { bindings } from "../../../lib/bindings.server";
import { currentUser } from "../../../lib/auth.server";

// Serves an uploaded object out of R2. Keys are opaque UUIDs written by the
// upload route, so nothing here trusts a caller-supplied path beyond the prefix.
// Images stay public (course thumbnails, share cards); lesson videos, audio and
// PDFs need a signed-in account. Byte ranges are honoured so videos can seek and
// play on iPhone/Safari, which refuses video served without Range support.
export const Route = createFileRoute("/api/file/$")({
  server: {
    handlers: {
      GET: async ({ params, request }) => {
        const key = String((params as any)._splat ?? "");
        if (!key.startsWith("media/") || key.includes("..")) return new Response("Not found", { status: 404 });
        const store = bindings().STORAGE;
        if (!store) return new Response("Storage unavailable", { status: 503 });

        const isPublic = key.startsWith("media/image/");
        if (!isPublic && !(await currentUser(request))) {
          return new Response("Please sign in to watch this lesson.", { status: 401 });
        }
        const cache = isPublic ? "public, max-age=31536000, immutable" : "private, max-age=3600";

        const head = await store.head(key);
        if (!head) return new Response("Not found", { status: 404 });
        const size = head.size;
        const type = head.httpMetadata?.contentType ?? "application/octet-stream";
        const base = { "content-type": type, "accept-ranges": "bytes", "cache-control": cache, etag: head.httpEtag };

        const range = request.headers.get("range");
        const m = range ? /^bytes=(\d*)-(\d*)$/.exec(range.trim()) : null;
        if (m && (m[1] || m[2])) {
          let start: number, end: number;
          if (m[1] === "") { const n = Number(m[2]); start = Math.max(0, size - n); end = size - 1; }
          else { start = Number(m[1]); end = m[2] ? Math.min(Number(m[2]), size - 1) : size - 1; }
          if (start >= size || start > end) {
            return new Response(null, { status: 416, headers: { "content-range": `bytes */${size}` } });
          }
          const obj = await store.get(key, { range: { offset: start, length: end - start + 1 } });
          if (!obj) return new Response("Not found", { status: 404 });
          return new Response(obj.body as any, {
            status: 206,
            headers: { ...base, "content-range": `bytes ${start}-${end}/${size}`, "content-length": String(end - start + 1) },
          });
        }
        const obj = await store.get(key);
        if (!obj) return new Response("Not found", { status: 404 });
        return new Response(obj.body as any, { headers: { ...base, "content-length": String(size) } });
      },
    },
  },
});
