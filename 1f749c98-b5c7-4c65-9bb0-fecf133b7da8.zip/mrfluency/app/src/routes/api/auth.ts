import { createFileRoute } from "@tanstack/react-router";
import {
  registerStudent, login, destroySession, currentUser, cookieValue, sessionCookie, clearedCookie,
  SESSION_COOKIE, ensureOwner, beginReset, completeReset, createSession, db,
} from "../../lib/auth.server";
import { alertOwner } from "../../lib/alerts.server";

const json = (b: unknown, s = 200, h?: Record<string, string>) =>
  Response.json(b, { status: s, headers: { "cache-control": "no-store", ...(h ?? {}) } });

export const Route = createFileRoute("/api/auth")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        await ensureOwner().catch(() => {});
        const u = await currentUser(request);
        return json({ user: u });
      },
      POST: async ({ request }) => {
        let b: any;
        try { b = await request.json(); } catch { return json({ error: "bad_request" }, 400); }
        const action = String(b?.action ?? "");
        const ua = request.headers.get("user-agent") ?? "";
        await ensureOwner().catch(() => {});

        if (action === "register") {
          const out = await registerStudent(b);
          if ("error" in out) return json(out, 400);
          const { token } = await createSession(out.userId, ua);
          const u = await db().prepare("SELECT id,email,name,role,cefr_level,xp FROM users WHERE id=?")
            .bind(out.userId).first<any>();
          await alertOwner("registration", "New registration: " + (u?.name ?? "student"), [
            "Name: " + (u?.name ?? ""),
            "Email: " + (u?.email ?? ""),
            "Registered as: " + (String(b?.goal ?? "") === "parent" ? "Parent" : "Student"),
            b?.phone ? "Phone: " + String(b.phone).slice(0, 40) : "",
            "Time: " + new Date().toUTCString(),
            "Next step for them: placement test.",
          ], "/studio");
          return json({ ok: true, user: u }, 200, { "set-cookie": sessionCookie(token) });
        }
        if (action === "login") {
          const out = await login(String(b?.email ?? ""), String(b?.password ?? ""), ua);
          if ("error" in out) {
            const msg = out.error === "rate_limited"
              ? "Too many attempts. Please wait a few minutes and try again."
              : out.error === "suspended" ? "This account is suspended."
              : "That email and password do not match.";
            return json({ error: out.error, message: msg }, out.error === "rate_limited" ? 429 : 401);
          }
          return json({ ok: true, user: out.user }, 200, { "set-cookie": sessionCookie(out.token!) });
        }
        if (action === "owner_login") {
          // Only the owner account may use this door. Any other account, even
          // with a correct password, gets the same generic refusal and no session.
          const out = await login(String(b?.email ?? ""), String(b?.password ?? ""), ua);
          if ("error" in out) return json({ error: out.error }, out.error === "rate_limited" ? 429 : 401);
          if (out.user.role !== "owner") {
            await destroySession(out.token!);
            return json({ error: "bad_credentials" }, 401);
          }
          return json({ ok: true, user: out.user }, 200, { "set-cookie": sessionCookie(out.token!) });
        }
        if (action === "logout") {
          const t = cookieValue(request, SESSION_COOKIE);
          if (t) await destroySession(t);
          return json({ ok: true }, 200, { "set-cookie": clearedCookie() });
        }
        if (action === "reset_request") {
          // The code is never returned to the requester (that would let anyone
          // take over any account). The owner reads it in the studio and sends it.
          await beginReset(String(b?.email ?? ""));
          return json({ ok: true });
        }
        if (action === "reset_complete") {
          const out = await completeReset(String(b?.token ?? ""), String(b?.password ?? ""));
          return "error" in out ? json(out, 400) : json(out);
        }
        if (action === "update_profile") {
          const u = await currentUser(request);
          if (!u) return json({ error: "unauthenticated" }, 401);
          await db().prepare("UPDATE users SET name=?, phone=?, goal=?, updated_at=? WHERE id=?")
            .bind(String(b?.name ?? u.name).slice(0, 80), String(b?.phone ?? "").slice(0, 40) || null,
              String(b?.goal ?? "").slice(0, 30) || null, Date.now(), u.id).run();
          return json({ ok: true });
        }
        return json({ error: "unknown_action" }, 400);
      },
    },
  },
});
