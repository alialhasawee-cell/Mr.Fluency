import { createFileRoute } from "@tanstack/react-router";
import { bindings } from "../../lib/bindings.server";
import { currentUser } from "../../lib/auth.server";

// OWNER ONLY. Lets the owner copy the whole academy (database rows + uploaded
// media) to another host, e.g. their own Cloudflare account via GitHub Actions.
// Session tables are never exported. Read-only: nothing here changes data.
const SKIP = new Set(["sessions_auth", "login_attempts", "_cf_KV", "d1_migrations", "sqlite_sequence"]);
const json = (b: unknown, s = 200) => Response.json(b, { status: s, headers: { "cache-control": "no-store" } });

export const Route = createFileRoute("/api/export")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const u = await currentUser(request);
        if (!u || u.role !== "owner") return json({ error: "forbidden" }, 403);
        const { DB, STORAGE } = bindings();
        if (!DB) return json({ error: "database_unavailable" }, 503);
        const url = new URL(request.url);
        const what = url.searchParams.get("what") ?? "";

        if (what === "tables") {
          const r = await DB.prepare("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all<any>();
          return json({ tables: (r.results ?? []).filter((t) => !SKIP.has(t.name)) });
        }
        if (what === "rows") {
          const table = url.searchParams.get("table") ?? "";
          const ok = await DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").bind(table).first();
          if (!ok || SKIP.has(table)) return json({ error: "unknown_table" }, 400);
          const offset = Math.max(0, Number(url.searchParams.get("offset") ?? 0) | 0);
          const limit = Math.min(500, Math.max(1, Number(url.searchParams.get("limit") ?? 500) | 0));
          const r = await DB.prepare(`SELECT * FROM "${table}" LIMIT ? OFFSET ?`).bind(limit, offset).all();
          return json({ rows: r.results ?? [] });
        }
        if (what === "objects") {
          if (!STORAGE) return json({ error: "storage_unavailable" }, 503);
          const cursor = url.searchParams.get("cursor") ?? undefined;
          const r = await STORAGE.list({ cursor, limit: 1000, include: ["httpMetadata"] } as any);
          return json({
            objects: r.objects.map((o: any) => ({ key: o.key, size: o.size, type: o.httpMetadata?.contentType ?? null })),
            cursor: r.truncated ? r.cursor : null,
          });
        }
        if (what === "object") {
          if (!STORAGE) return json({ error: "storage_unavailable" }, 503);
          const key = url.searchParams.get("key") ?? "";
          const o = await STORAGE.get(key);
          if (!o) return json({ error: "not_found" }, 404);
          return new Response(o.body as any, {
            headers: { "content-type": o.httpMetadata?.contentType ?? "application/octet-stream", "cache-control": "no-store" },
          });
        }
        return json({ error: "unknown" }, 400);
      },
    },
  },
});
