import { createFileRoute } from "@tanstack/react-router";
import { startAttempt, stateOf, submit, pause, resume, statusFor } from "../../lib/placement.server";

const COOKIE = "mf_attempt";
const json = (body: unknown, status = 200, extra?: Record<string, string>) =>
  Response.json(body, { status, headers: { "cache-control": "no-store", ...(extra ?? {}) } });
const setCookie = (id: string) =>
  `${COOKIE}=${id}; Path=/; Max-Age=2592000; HttpOnly; Secure; SameSite=Lax`;
function cookieAttempt(request: Request): string | null {
  const raw = request.headers.get("cookie") ?? "";
  const m = raw.match(/(?:^|;\s*)mf_attempt=([A-Za-z0-9-]{10,60})/);
  return m ? m[1] : null;
}
const str = (v: unknown, max = 200) => (typeof v === "string" ? v.slice(0, max) : "");

export const Route = createFileRoute("/api/test")({
  server: {
    handlers: {
      // Resume path: the browser sends nothing, the cookie identifies the attempt.
      GET: async ({ request }) => {
        const id = new URL(request.url).searchParams.get("id") ?? cookieAttempt(request);
        if (!id) return json({ status: "NONE" });
        const st = await stateOf(id);
        if ("error" in st) return json({ status: "NONE" });
        return json(st);
      },
      POST: async ({ request }) => {
        let body: any;
        try { body = await request.json(); } catch { return json({ error: "bad_request" }, 400); }
        const action = str(body?.action, 20);

        if (action === "status") {
          try {
            return json(await statusFor(str(body?.name, 80), str(body?.email, 120)));
          } catch { return json({ error: "unavailable" }, 503); }
        }

        if (action === "start") {
          const out = await startAttempt({
            name: str(body?.name, 80), email: str(body?.email, 120), goal: str(body?.goal, 20),
          });
          if ("error" in out) return json(out, 400);
          const st = await stateOf(out.attemptId);
          return json({ ...st, resumed: out.resumed }, 200, { "set-cookie": setCookie(out.attemptId) });
        }

        // Every action below acts on the attempt named by the cookie, falling
        // back to an explicit id so a student can finish on another device.
        const id = str(body?.attemptId, 60) || cookieAttempt(request) || "";
        if (!id) return json({ error: "no_session" }, 400);

        if (action === "answer") {
          const out = await submit(id, str(body?.itemId, 40), Number(body?.choice));
          if ("error" in out) return json(out, 409);
          return json(await stateOf(id));
        }
        if (action === "pause") {
          const out = await pause(id);
          if ("error" in out) return json(out, 409);
          return json(await stateOf(id));
        }
        if (action === "resume") {
          const out = await resume(id);
          if ("error" in out) return json(out, 409);
          return json(await stateOf(id), 200, { "set-cookie": setCookie(id) });
        }
        return json({ error: "unknown_action" }, 400);
      },
    },
  },
});
