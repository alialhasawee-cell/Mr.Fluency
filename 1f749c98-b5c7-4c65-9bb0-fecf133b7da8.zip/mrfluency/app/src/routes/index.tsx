import { createFileRoute, Link } from "@tanstack/react-router";
import { Fragment, useEffect, useState, type PointerEvent, type ReactNode } from "react";
import { LangProvider, Stage, useLang, t, useReducedMotion } from "../components/gate";
import { Reveal, BigArrow } from "../components/motion";
import { useSession } from "../components/session";
import { SITE } from "../lib/site";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [{ title: "Mr. Fluency Academy — Welcome · أكاديمية مستر فلونسي" }],
    links: [{ rel: "canonical", href: SITE + "/" }],
  }),
  component: () => <LangProvider><Entrance /></LangProvider>,
});

const FAMILIES: [string, string][] = [
  ["General English", "الإنجليزية العامة"], ["IELTS", "آيلتس"], ["Business English", "إنجليزية الأعمال"],
  ["Email Writing", "كتابة البريد الإلكتروني"], ["Creative AI", "الذكاء الاصطناعي الإبداعي"],
  ["HR", "الموارد البشرية"], ["Marketing", "التسويق"],
];

function Intro({ onDone }: { onDone: () => void }) {
  const { lang } = useLang();
  const [gone, setGone] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => { setGone(true); setTimeout(onDone, 800); }, 3600);
    return () => clearTimeout(id);
  }, [onDone]);
  const skip = () => { setGone(true); setTimeout(onDone, 400); };
  return (
    <div className={"gt-intro" + (gone ? " done" : "")} aria-hidden={gone}>
      <div style={{ display: "grid", justifyItems: "center" }}>
        <svg className="gt-door" width="240" height="300" viewBox="0 0 240 300" role="img" aria-label="Mr. Fluency">
          <defs>
            <radialGradient id="gtL" cx="50%" cy="60%" r="60%">
              <stop offset="0" stopColor="#FBE7B5" stopOpacity=".95" /><stop offset=".55" stopColor="#D39A35" stopOpacity=".35" />
              <stop offset="1" stopColor="#8C2F39" stopOpacity="0" />
            </radialGradient>
          </defs>
          <g className="rays" stroke="#E0B25A" strokeWidth="1" opacity=".5">
            {Array.from({ length: 18 }, (_, i) => {
              const a = (i / 18) * Math.PI * 2;
              return <line key={i} x1={120 + Math.cos(a) * 90} y1={200 + Math.sin(a) * 90}
                x2={120 + Math.cos(a) * 150} y2={200 + Math.sin(a) * 150} />;
            })}
          </g>
          <path className="light" d="M40 290 V120 A80 80 0 0 1 200 120 V290 Z" fill="url(#gtL)" />
          <path d="M40 290 V120 A80 80 0 0 1 200 120 V290" />
          <path d="M20 290 H220" style={{ animationDelay: ".4s" }} />
          <image className="logo" href="/brand/mf-logo.webp" x="72" y="112" width="96" height="99" />
        </svg>
        <div className="gt-intro-word">Mr. Fluency Academy<small>أكاديمية مستر فلونسي</small></div>
      </div>
      <button className="gt-link gt-skip" onClick={skip}>{t(lang, "Skip intro", "تخطي المقدمة")}</button>
    </div>
  );
}

function Card({ to, tone, icon, title, body, go, look, index }: {
  to: "/guest" | "/owner" | "/placement"; tone: string; icon: ReactNode; title: string; body: string; go: string; look: string; index: number;
}) {
  function move(e: PointerEvent<HTMLAnchorElement>) {
    const r = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - r.left, y = e.clientY - r.top;
    e.currentTarget.style.setProperty("--mx", x + "px"); e.currentTarget.style.setProperty("--my", y + "px");
    e.currentTarget.style.transform = `translateY(-6px) perspective(900px) rotateX(${(0.5 - y / r.height) * 6}deg) rotateY(${(x / r.width - 0.5) * 8}deg)`;
  }
  return (
    <Reveal index={index} variant={(["flip", "zoom", "swing"] as const)[index % 3]} delay={0.15 + index * 0.18}>
    <Link to={to} className="gt-card" data-look={look} onPointerMove={move} onPointerLeave={(e) => { e.currentTarget.style.transform = ""; }}>
      <span className="glow" />
      <div className="gt-ico" style={{ background: tone }}>{icon}</div>
      <h2>{title}</h2>
      <p>{body}</p>
      <span className="gt-go">{go}
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
      </span>
    </Link>
    </Reveal>
  );
}

function Entrance() {
  const { lang } = useLang();
  const reduced = useReducedMotion();
  const { user } = useSession();
  const [intro, setIntro] = useState<"pending" | "play" | "done">("pending");
  useEffect(() => {
    let seen = false;
    try { seen = sessionStorage.getItem("mf_intro") === "1"; sessionStorage.setItem("mf_intro", "1"); } catch { /* ignore */ }
    setIntro(seen || window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "done" : "play");
  }, []);
  const ready = intro !== "play";
  const words = lang === "ar"
    ? ["تحدّث بثقة", "اكتب باحتراف", "انجح في الآيلتس", "تقدّم في عملك"]
    : ["Speak with confidence", "Write like a pro", "Pass your IELTS", "Grow your career"];
  const title = lang === "ar" ? ["أكاديمية", "مستر", "فلونسي"] : ["Mr.", "Fluency", "Academy"];
  const d = (s: number) => ({ animationDelay: (reduced ? 0 : s) + "s" });

  return (
    <Stage>
      {intro === "play" ? <Intro onDone={() => setIntro("done")} /> : null}
      <main key={intro} style={{ position: "relative", zIndex: 1, textAlign: "center", paddingTop: "clamp(24px,6vh,72px)" }}>
        {ready ? (
          <>
            <div className="gt-eyebrow gt-fade" style={d(0.05)}>
              {t(lang, "Basra · Iraq — English that opens doors", "البصرة · العراق — إنجليزية تفتح الأبواب")}
            </div>
            <h1 className="gt-h1" style={{ marginTop: 18 }}>
              {title.map((w, i) => (
                <Fragment key={w + lang}><span className={"w" + (i === 1 ? " gt-gold" : "")} style={{ ...d(0.15 + i * 0.14), marginInline: "0.07em" }}>{w}</span>{i < title.length - 1 ? " " : null}</Fragment>
              ))}
            </h1>
            <p className="gt-lead gt-fade" style={d(0.6)}>
              <span className="gt-word-cycle" style={{ color: "#F6D98E", fontWeight: 600 }}>
                {words.map((w) => <span key={w}>{w}</span>)}
              </span>
              <br />
              {t(lang, "Video lessons, a question after every lesson, and a final exam — for students and their parents.",
                "دروس فيديو، وسؤال بعد كل درس، واختبار نهائي — للطلاب وأولياء أمورهم.")}
            </p>

            {user ? (
              <div className="gt-fade" style={{ ...d(0.8), marginTop: 26 }}>
                <span className="gt-chip">
                  {t(lang, "Signed in as", "مسجّل الدخول باسم")} <b>{user.name}</b>
                  <Link to={user.role === "student" ? "/courses" : "/studio"}>{t(lang, "Continue", "متابعة")}</Link>
                </span>
              </div>
            ) : null}

            <div className="gt-bigarrow gt-fade" style={d(0.75)}><BigArrow size={72} /></div>
            <div className="gt-cards">
              <Card index={0} look="guest" to="/guest" tone="linear-gradient(135deg,#FFD54A,#F59E0B)"
                icon={<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 5.5C4.5 4 8 4 12 6c4-2 7.5-2 10-.5V19c-2.5-1.5-6-1.5-10 .5-4-2-7.5-2-10-.5z" /><path d="M12 6v13.5" /></svg>}
                title={t(lang, "Guest", "ضيف")}
                body={t(lang, "For parents and students. Create a free account, take the placement test, then watch the lessons, answer the quizzes and sit the final exam.",
                  "لأولياء الأمور والطلاب. أنشئ حساباً مجانياً، قدّم اختبار تحديد المستوى، ثم شاهد الدروس وأجب عن الاختبارات وقدّم الاختبار النهائي.")}
                go={t(lang, "Enter as a guest", "الدخول كضيف")} />
              <Card index={1} look="placement" to="/placement" tone="linear-gradient(135deg,#22D3EE,#2563EB)"
                icon={<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 20h4V10H4zM10 20h4V4h-4zM16 20h4v-7h-4z" /></svg>}
                title={t(lang, "Placement test", "اختبار تحديد المستوى")}
                body={t(lang, "The first step for every student. Find your level from A1 to C1 — your result is sent automatically to Mr. Ali.",
                  "الخطوة الأولى لكل طالب. اعرف مستواك من A1 إلى C1 — تُرسل نتيجتك تلقائياً إلى الأستاذ علي.")}
                go={t(lang, "Start the test", "ابدأ الاختبار")} />
              <Card index={2} look="owner" to="/owner" tone="linear-gradient(135deg,#1E3A8A,#0F172A)"
                icon={<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#FFD54A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="8" cy="15" r="4" /><path d="M10.8 12.2 20 3M16 7l3 3M14 9l2 2" /></svg>}
                title={t(lang, "Owner", "المالك")}
                body={t(lang, "Mr. Ali only. Manage courses, upload lesson videos, read placement results and answer every question.",
                  "للأستاذ علي فقط. إدارة الدورات، رفع فيديوهات الدروس، قراءة نتائج تحديد المستوى والرد على كل سؤال.")}
                go={t(lang, "Owner sign-in", "دخول المالك")} />
            </div>

            <div className="gt-marquee gt-fade" style={d(1.1)} aria-label={t(lang, "Course families", "مجالات الدورات")}>
              <div className="gt-track">
                {[...FAMILIES, ...FAMILIES].map(([en, ar], i) => (
                  <span key={i} aria-hidden={i >= FAMILIES.length}><b>✦</b>{t(lang, en, ar)}</span>
                ))}
              </div>
            </div>

            <p className="gt-fade" style={{ ...d(1.3), marginTop: 30, fontSize: 14, color: "#C7D2E6" }}>
              <Link to="/app" className="gt-link">{t(lang, "📱 Download the Android app", "📱 حمّل تطبيق أندرويد")}</Link>
              {" · "}
              <Link to="/academy" className="gt-link">{t(lang, "About the academy & free placement test", "عن الأكاديمية واختبار تحديد المستوى المجاني")}</Link>
            </p>
          </>
        ) : null}
      </main>
    </Stage>
  );
}
