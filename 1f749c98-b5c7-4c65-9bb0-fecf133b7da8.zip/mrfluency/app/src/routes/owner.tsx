import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { LangProvider, Stage, useLang, t, Field } from "../components/gate";
import { api, useSession } from "../components/session";

export const Route = createFileRoute("/owner")({
  head: () => ({ meta: [{ title: "Owner sign-in — Mr. Fluency" }, { name: "robots", content: "noindex" }] }),
  component: () => <LangProvider><OwnerLogin /></LangProvider>,
});

function OwnerLogin() {
  const { lang } = useLang();
  const { refresh } = useSession();
  const router = useRouter();
  const [f, setF] = useState({ email: "", password: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(""); setBusy(true);
    const { ok, status } = await api.post("/api/auth", { action: "owner_login", ...f });
    setBusy(false);
    if (!ok) {
      return setErr(status === 429
        ? t(lang, "Too many attempts. Please wait a few minutes.", "محاولات كثيرة. انتظر بضع دقائق ثم حاول مجدداً.")
        : t(lang, "This sign-in is for the academy owner only, or the email and password do not match.",
          "هذا الدخول مخصّص لمالك الأكاديمية فقط، أو أن البريد وكلمة المرور غير متطابقين."));
    }
    await refresh();
    router.navigate({ to: "/studio" });
  }

  return (
    <Stage>
      <main style={{ paddingTop: "clamp(16px,6vh,64px)" }}>
        <div style={{ textAlign: "center" }} className="gt-fade">
          <div className="gt-eyebrow">{t(lang, "Owner only", "للمالك فقط")}</div>
          <h1 className="gt-h1" style={{ fontSize: "clamp(2.2rem,5vw,3.4rem)", marginTop: 12 }}>
            <span className="gt-gold">{t(lang, "Welcome back", "أهلاً بعودتك")}</span>
          </h1>
        </div>
        <form className="gt-panel gt-fade" style={{ animationDelay: ".15s" }} onSubmit={submit}>
          <Field label={t(lang, "Owner email", "بريد المالك")} type="email" autoComplete="username" required dir="ltr"
            value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
          <Field label={t(lang, "Password", "كلمة المرور")} type="password" autoComplete="current-password" required dir="ltr"
            value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
          {err ? <div className="gt-err" role="alert">{err}</div> : null}
          <button className="gt-btn" disabled={busy}>{busy ? t(lang, "Checking…", "جارٍ التحقق…") : t(lang, "Open the studio", "افتح لوحة الإدارة")}</button>
          <p style={{ fontSize: 13, color: "#A99F8E", marginTop: 16, lineHeight: 1.5 }}>
            {t(lang, "Parents and students: please use the guest entrance.", "أولياء الأمور والطلاب: يرجى استخدام دخول الضيوف.")}{" "}
            <Link to="/guest" className="gt-link">{t(lang, "Guest entrance", "دخول الضيوف")}</Link>
          </p>
        </form>
      </main>
    </Stage>
  );
}
