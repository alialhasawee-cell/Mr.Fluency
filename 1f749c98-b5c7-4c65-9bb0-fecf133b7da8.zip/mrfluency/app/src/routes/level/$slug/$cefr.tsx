import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { Shell } from "../../../components/shell";
import { api, useSession, Spinner, ErrorNote } from "../../../components/session";
import { Reveal, BigArrow } from "../../../components/motion";
import { LEVEL_LOOK, PlacementGate } from "../../../components/levels";

export const Route = createFileRoute("/level/$slug/$cefr")({
  head: ({ params }) => ({ meta: [{ title: `${params.cefr} — General English — Mr. Fluency` }] }),
  component: LevelPage,
});

function LevelPage() {
  const { slug, cefr } = Route.useParams();
  const { user } = useSession();
  const [d, setD] = useState<any>(null);
  const [err, setErr] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  const load = useCallback(async () => {
    setErr(false);
    const { ok, data } = await api.get("/api/lms?what=course&slug=" + encodeURIComponent(slug));
    if (!ok) return setErr(true);
    setD(data);
  }, [slug]);
  useEffect(() => { void load(); }, [load, user]);

  async function join() {
    setBusy(true); setMsg("");
    const { ok, data } = await api.post("/api/lms", { action: "enroll", courseId: d.course.id });
    setBusy(false);
    if (ok) void load(); else setMsg(data?.message ?? "Could not start the course.");
  }

  if (!d && !err) return <Shell><Wrap><Spinner /></Wrap></Shell>;
  if (err) return <Shell><Wrap><ErrorNote onRetry={load}>This level could not be loaded.</ErrorNote></Wrap></Shell>;

  const { course, tree, enrolled, access, levels, placed, done } = d;
  const all = tree?.levels ?? [];
  const idx = all.findIndex((l: any) => l.cefr === cefr);
  const lvl = all[idx];
  if (!lvl) return <Shell><Wrap><ErrorNote onRetry={load}>Level {cefr} was not found.</ErrorNote></Wrap></Shell>;
  const look = LEVEL_LOOK[lvl.cefr] ?? LEVEL_LOOK.A1;
  const prev = all[idx - 1], next = all[idx + 1];
  const staff = !!user && user.role !== "student";
  const st = levels?.[lvl.id];
  const doneSet = new Set(done ?? []);
  const lessonsAll = lvl.modules.flatMap((m: any) => m.lessons);
  const doneCount = lessonsAll.filter((l: any) => doneSet.has(l.id)).length;
  const pct = lessonsAll.length ? Math.round((doneCount / lessonsAll.length) * 100) : 0;

  return (
    <Shell>
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(180deg, rgba(0,0,0,.15), transparent)" }}>
        <Wrap>
          <Link to="/course/$slug" params={{ slug }} className="mf-link" style={{ fontSize: 16 }}>← {course.title}: all levels</Link>
          <div className="mt-6 flex flex-wrap items-center gap-6">
            <Reveal variant="zoom">
              <div className="mf-level-badge" style={{ background: look.grad }}>{lvl.cefr}</div>
            </Reveal>
            <Reveal variant="slide-r" delay={0.1} className="min-w-[240px] flex-1">
              <div style={{ color: look.color, fontWeight: 800, letterSpacing: ".1em", textTransform: "uppercase" }}>{look.name}</div>
              <h1 className="mf-hero-title" style={{ fontSize: "clamp(2rem,5vw,3.6rem)" }}>{lvl.title}</h1>
              {lvl.summary ? <p className="mf-prose mt-2" style={{ fontSize: 19 }}>{lvl.summary}</p> : null}
            </Reveal>
          </div>

          {enrolled && !staff ? (
            <Reveal variant="rise" delay={0.2}>
              <div className="mt-6">
                <div className="mb-2 flex justify-between" style={{ fontWeight: 700 }}><span>Your progress in {lvl.cefr}</span><span>{doneCount}/{lessonsAll.length} lessons · {pct}%</span></div>
                <div className="mf-bar" style={{ height: 12, borderRadius: 8 }}><i style={{ width: pct + "%" }} /></div>
              </div>
            </Reveal>
          ) : null}

          <div className="mt-8">
            {staff ? <p style={{ color: "var(--ink-3)" }}>Staff view — every lesson is open for you.</p> : <PlacementGate placed={placed} signedIn={!!user} />}
          </div>
          {user && placed && !enrolled && !staff ? (
            <div className="mt-6 flex flex-wrap items-center gap-4">
              <BigArrow dir="right" size={48} />
              <button className="cta-test" style={{ fontSize: 19, padding: "16px 30px" }} onClick={join} disabled={busy}>{busy ? "Starting…" : "Start this course"}</button>
              {msg ? <span style={{ color: "#FCA5A5" }}>{msg}</span> : null}
            </div>
          ) : null}
          {st && !st.open && placed && !staff ? (
            <div className="mf-card mt-6 p-5" style={{ borderColor: "#F59E0B" }}>🔒 <b>{st.reason}</b></div>
          ) : null}

          <div className="mt-12 grid gap-6">
            {lvl.modules.map((m: any, mi: number) => {
              const isFinal = !m.lessons.length;
              return (
                <Reveal key={m.id} index={mi + 2}>
                  <div className="mf-card mf-chapter p-6" style={{ ["--lv" as any]: look.color }}>
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="mf-chapter-num" style={{ background: isFinal ? "linear-gradient(135deg,#B91C1C,#F43F5E)" : look.grad }}>{isFinal ? "★" : mi + 1}</span>
                      <div className="min-w-[200px] flex-1">
                        <div style={{ color: look.color, fontSize: 13, fontWeight: 800, letterSpacing: ".1em", textTransform: "uppercase" }}>{isFinal ? "Final exam" : "Chapter " + (mi + 1)}</div>
                        <h2 className="text-2xl">{m.title}</h2>
                      </div>
                    </div>
                    {m.summary ? <p className="mt-3" style={{ color: "var(--ink-2)", fontSize: 17 }}>{m.summary}</p> : null}
                    <ol className="mt-4 grid list-none gap-2 p-0">
                      {m.lessons.map((l: any, i: number) => {
                        const open = staff || (enrolled && access?.[l.id]?.open);
                        const complete = doneSet.has(l.id);
                        return (
                          <li key={l.id} className="mf-lesson-row">
                            <span className="mf-lesson-dot" style={{ background: complete ? "#16A34A" : "transparent", borderColor: complete ? "#16A34A" : look.color }}>{complete ? "✓" : i + 1}</span>
                            <span className="min-w-[160px] flex-1" style={{ fontSize: 17, fontWeight: 600 }}>{l.title}</span>
                            {open ? (
                              <Link to="/learn/$lessonId" params={{ lessonId: l.id }} className="cta-test" style={{ padding: "9px 18px", fontSize: 15 }}>{complete ? "Review" : "Open ▶"}</Link>
                            ) : (
                              <span style={{ color: "var(--ink-3)", fontSize: 14 }}>🔒 {enrolled ? (access?.[l.id]?.reason ?? "Locked") : placed ? "Start the course to open" : "Placement test first"}</span>
                            )}
                          </li>
                        );
                      })}
                      {m.quizzes?.map((q: any) => (
                        <li key={q.id} className="mf-lesson-row" style={{ background: "rgba(244,63,94,.12)", borderColor: "rgba(244,63,94,.45)" }}>
                          <span className="mf-lesson-dot" style={{ borderColor: "#FB7185" }}>✎</span>
                          <span className="min-w-[160px] flex-1" style={{ fontSize: 17, fontWeight: 700 }}>{q.kind === "final_exam" ? "Final exam" : "Chapter test"} — {q.title}</span>
                          {enrolled || staff ? (
                            <Link to="/quiz/$quizId" params={{ quizId: q.id }} className="cta-quiet" style={{ padding: "9px 16px" }}>Start</Link>
                          ) : <span style={{ color: "var(--ink-3)", fontSize: 14 }}>🔒</span>}
                        </li>
                      ))}
                    </ol>
                  </div>
                </Reveal>
              );
            })}
          </div>

          <div className="mt-12 flex flex-wrap justify-between gap-4">
            {prev ? <Link to="/level/$slug/$cefr" params={{ slug, cefr: prev.cefr }} className="cta-quiet">← Level {prev.cefr}</Link> : <span />}
            {next ? <Link to="/level/$slug/$cefr" params={{ slug, cefr: next.cefr }} className="cta-test">Level {next.cefr} →</Link> : null}
          </div>
        </Wrap>
      </section>
    </Shell>
  );
}
function Wrap({ children }: { children: React.ReactNode }) {
  return <div className="relative z-10 mx-auto max-w-5xl px-4 py-12 sm:px-6">{children}</div>;
}
