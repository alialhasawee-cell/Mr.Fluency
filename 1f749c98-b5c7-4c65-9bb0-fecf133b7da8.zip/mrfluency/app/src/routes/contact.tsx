import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell, Section } from "../components/shell";
import { ContactRow, Monogram } from "../components/brand";
import { GOALS, PROFILE } from "../lib/courses";
import { SITE } from "../lib/site";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Mr. Fluency" },
      { name: "description", content: "Contact Ali Alhasawee (Mr. Fluency) in Basra, Iraq about English courses, Business English, Email Writing and IELTS preparation." },
    ],
    links: [{ rel: "canonical", href: SITE + "/contact" }],
  }),
  component: Contact,
});

function Contact() {
  const [f, setF] = useState({ name: "", email: "", phone: "", goal: "general", message: "" });
  const [state, setState] = useState<"idle" | "busy" | "done" | "error">("idle");

  async function send() {
    if (!f.name.trim() || !f.message.trim()) { setState("error"); return; }
    setState("busy");
    const r = await fetch("/api/contact", {
      method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(f),
    });
    setState(r.ok ? "done" : "error");
  }

  return (
    <Shell>
      <Section eyebrow="Contact" title={"Questions? Talk to " + PROFILE.fullName}
        lead="Every question and enquiry goes directly to Mr. Ali. WhatsApp is fastest — or send the form below and it reaches his email and WhatsApp instantly.">
        <div className="mt-8"><ContactRow /></div>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1.3fr_0.7fr]">
          <div className="mf-card p-6 sm:p-8">
            <h2 className="text-2xl">Send a message</h2>
            {state === "done" ? (
              <div className="mf-note mt-5">
                <b>Thank you.</b> Your message has been sent directly to {PROFILE.fullName}. He will reply to you personally.
                If it is urgent, send the same message on WhatsApp to {PROFILE.phoneDisplay}.
              </div>
            ) : (
              <>
                <div className="mt-5 grid gap-4 sm:grid-cols-2">
                  <label className="block"><span className="mf-label">Your name (required)</span>
                    <input className="mf-field" id="c-name" value={f.name} autoComplete="name"
                      onChange={(e) => setF({ ...f, name: e.target.value })} /></label>
                  <label className="block"><span className="mf-label">Email</span>
                    <input className="mf-field" id="c-email" type="email" value={f.email} autoComplete="email"
                      onChange={(e) => setF({ ...f, email: e.target.value })} /></label>
                  <label className="block"><span className="mf-label">Phone or WhatsApp</span>
                    <input className="mf-field" id="c-phone" value={f.phone} autoComplete="tel"
                      onChange={(e) => setF({ ...f, phone: e.target.value })} /></label>
                  <label className="block"><span className="mf-label">What do you need English for?</span>
                    <select className="mf-field" id="c-goal" value={f.goal}
                      onChange={(e) => setF({ ...f, goal: e.target.value })}>
                      {GOALS.map((g) => <option key={g.id} value={g.id}>{g.label}</option>)}
                    </select></label>
                </div>
                <label className="mt-4 block"><span className="mf-label">Your message (required)</span>
                  <textarea className="mf-field" id="c-msg" rows={5} value={f.message}
                    onChange={(e) => setF({ ...f, message: e.target.value })}
                    placeholder="Tell me your goal, your deadline if you have one, and when you can study." /></label>
                {state === "error" ? (
                  <p className="mt-3 text-sm" style={{ color: "var(--danger)" }}>
                    Please enter at least your name and a message, then try again.
                  </p>
                ) : null}
                <button className="cta-test mt-5" onClick={send} disabled={state === "busy"}>
                  {state === "busy" ? "Sending…" : "Send message"}
                </button>
              </>
            )}
          </div>

          <div className="mf-card flex flex-col items-center p-7 text-center">
            <Monogram size={130} />
            <h3 className="mt-3 text-xl">{PROFILE.name}</h3>
            <p className="mt-1 text-sm" style={{ color: "var(--ink-2)" }}>{PROFILE.title}</p>
            <p className="mf-label mt-4">Based in</p>
            <p className="text-sm font-semibold">{PROFILE.city}</p>
            <p className="mt-6 text-lg" style={{ fontFamily: "var(--display)", fontStyle: "italic", color: "var(--brass)" }}>
              “{PROFILE.quote}”
            </p>
          </div>
        </div>
      </Section>
    </Shell>
  );
}
