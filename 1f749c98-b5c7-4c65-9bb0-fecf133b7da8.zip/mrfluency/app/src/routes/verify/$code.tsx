import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell } from "../../components/shell";
import { LogoLockup, LevelChip } from "../../components/brand";
import { api, Spinner } from "../../components/session";

export const Route = createFileRoute("/verify/$code")({
  head: ({ params }) => ({
    meta: [{ title: `Verify certificate ${params.code} — Mr. Fluency` },
      { name: "description", content: "Check whether a Mr. Fluency certificate of completion is genuine." }],
  }),
  component: Verify,
});

function Verify() {
  const { code } = Route.useParams();
  const [d, setD] = useState<any>(null);
  useEffect(() => { void (async () => {
    const { data } = await api.get("/api/cert?code=" + encodeURIComponent(code));
    setD(data);
  })(); }, [code]);

  if (!d) return <Shell><div className="mx-auto max-w-2xl px-4 py-16 sm:px-6"><Spinner label="Checking this certificate…" /></div></Shell>;

  const c = d.certificate;
  return (
    <Shell>
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <div className="mf-eyebrow mb-3">Certificate verification</div>
        <h1 className="text-3xl">{code}</h1>

        {d.valid ? (
          <div className="mf-card mt-8 overflow-hidden" style={{ borderTop: "4px solid var(--garnet)" }}>
            <div className="p-8 text-center">
              <div className="flex justify-center"><LogoLockup width={116} /></div>
              <p className="mf-eyebrow mt-4">Mr. Fluency Academy</p>
              <h2 className="mt-2 text-3xl">Certificate of Completion</h2>
              <p className="mf-prose mx-auto mt-6 text-sm">This certifies that</p>
              <p className="text-3xl" style={{ fontFamily: "var(--display)" }}>{c.student_name}</p>
              <p className="mf-prose mx-auto mt-4 text-sm">successfully completed</p>
              <p className="text-2xl" style={{ fontFamily: "var(--display)" }}>{c.course_title}</p>
              <div className="mt-6 flex flex-wrap items-center justify-center gap-5">
                {c.cefr ? <span><span className="mf-label">Level</span><LevelChip level={c.cefr} /></span> : null}
                <span><span className="mf-label">Final score</span>
                  <b className="mf-mono text-lg">{c.score_pct}%</b></span>
                <span><span className="mf-label">Issued</span>
                  <b className="text-sm">{new Date(c.issued_at).toLocaleDateString()}</b></span>
              </div>
              <p className="mt-6 text-sm" style={{ color: "var(--ink-2)" }}>
                Instructor: <b style={{ color: "var(--ink)" }}>{c.instructor}</b>
              </p>
            </div>
            <div className="px-6 py-4 text-center" style={{ background: "var(--ok)", color: "#fff" }}>
              <b>✓ This certificate is valid.</b>
            </div>
          </div>
        ) : (
          <div className="mf-card mt-8 p-8 text-center" style={{ borderTop: "4px solid var(--danger)" }}>
            <h2 className="text-2xl">
              {d.reason === "revoked" ? "This certificate has been revoked" : "No certificate with this code"}
            </h2>
            <p className="mf-prose mx-auto mt-3 text-sm">
              {d.reason === "revoked"
                ? "It was issued but has since been withdrawn. Contact Mr. Fluency if you believe this is an error."
                : "Check the code and try again. Certificate codes look like MF-2026-000001."}
            </p>
          </div>
        )}
        <p className="mt-8 text-center text-sm">
          <Link to="/" className="mf-link">Mr. Fluency</Link> — English placement testing and courses, Basra, Iraq.
        </p>
      </div>
    </Shell>
  );
}
