import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { LangProvider, Stage, useLang, t, Field } from "../components/gate";
import { api, useSession } from "../components/session";

export const Route = createFileRoute("/guest")({
  head: () => ({ meta: [{ title: "Guest entrance — Mr. Fluency" }] }),
  validateSearch: (s: Record<string, unknown>): { mode?: "signin" | "signup" } =>
    (s.mode === "signin" || s.mode === "signup" ? { mode: s.mode } : {}),
  component: () => <LangProvider><Guest /></LangProvider>,
});

const ERR: Record<string, [string, string]> = {
  name_required: ["Please enter your name.", "يرجى إدخال الاسم."],
  email_invalid: ["Please enter a valid email address.", "يرجى إدخال بريد إلكتروني صحيح."],
  email_taken: ["An account already uses this email — sign in instead.", "يوجد حساب بهذا البريد — سجّل الدخول بدلاً من ذلك."],
  password_weak: ["Password needs at least 8 characters with a letter and a number.", "كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي حرفاً ورقماً."],
  rate_limited: ["Too many attempts. Please wait a few minutes.", "محاولات كثيرة. انتظر بضع دقائق."],
  suspended: ["This account is paused. Please contact Mr. Fluency.", "هذا الحساب موقوف. يرجى التواصل مع مستر فلونسي."],
};

function Guest() {
  const { lang } = useLang();
  const initial = Route.useSearch().mode ?? "signup";
  const { user, refresh } = useSession();
  const router = useRouter();
  const [mode, setMode] = useState<"signup" | "signin">(initial);
  const [f, setF] = useState({ name: "", who: "student", email: "", phone: "", password: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [reset, setReset] = useState(false);
  const [notice, setNotice] = useState("");
  const [code, setCode] = useState("");

  useEffect(() => { setMode(initial); }, [initial]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(""); setNotice(""); setBusy(true);
    if (reset && code.trim()) {
      const r = await api.post("/api/auth", { action: "reset_complete", token: code.trim(), password: f.password });
      setBusy(false);
      if (!r.ok) return setErr(r.data?.error === "password_weak"
        ? t(lang, ERR.password_weak[0], ERR.password_weak[1])
        : t(lang, "That code is wrong or has expired. Ask Mr. Fluency for a new one.", "الرمز غير صحيح أو منتهي الصلاحية. اطلب رمزاً جديداً من مستر فلونسي."));
      setReset(false); setCode(""); setMode("signin");
      return setNotice(t(lang, "Password changed. You can sign in now.", "تم تغيير كلمة المرور. يمكنك تسجيل الدخول الآن."));
    }
    if (reset) {
      await api.post("/api/auth", { action: "reset_request", email: f.email });
      setBusy(false);
      return setNotice(t(lang, "Request sent. Message Mr. Fluency on WhatsApp +964 780 340 2205 to receive your reset code, then enter it below.",
        "تم إرسال الطلب. راسل مستر فلونسي عبر واتساب ‎+964 780 340 2205‎ لاستلام رمز إعادة التعيين، ثم أدخله أدناه."));
    }
    const body = mode === "signup"
      ? { action: "register", name: f.name, email: f.email, password: f.password, phone: f.phone, goal: f.who === "parent" ? "parent" : "general" }
      : { action: "login", email: f.email, password: f.password };
    const { ok, data } = await api.post("/api/auth", body);
    setBusy(false);
    if (!ok) {
      const m = ERR[data?.error as string];
      return setErr(m ? t(lang, m[0], m[1]) : t(lang, "That email and password do not match.", "البريد وكلمة المرور غير متطابقين."));
    }
    await refresh();
    const role = data?.user?.role;
    // Students start with the placement test (they can skip it to browse).
    const firstStop = mode === "signup" || !data?.user?.cefr_level ? "/placement" : "/courses";
    router.navigate({ to: role && role !== "student" ? "/studio" : firstStop });
  }

  return (
    <Stage>
      <main style={{ paddingTop: "clamp(16px,5vh,56px)" }}>
        <div style={{ textAlign: "center" }} className="gt-fade">
          <div className="gt-eyebrow">{t(lang, "Parents & students", "أولياء الأمور والطلاب")}</div>
          <h1 className="gt-h1" style={{ fontSize: "clamp(2.2rem,5vw,3.4rem)", marginTop: 12 }}>
            {mode === "signup" ? t(lang, "Start learning", "ابدأ التعلّم") : t(lang, "Welcome back", "أهلاً بعودتك")}
          </h1>
        </div>

        {user ? (
          <div className="gt-panel gt-fade" style={{ textAlign: "center" }}>
            <p style={{ margin: "0 0 16px" }}>{t(lang, "You're signed in as", "أنت مسجّل الدخول باسم")} <b>{user.name}</b>.</p>
            <Link to={user.role === "student" ? "/courses" : "/studio"} className="gt-btn">{t(lang, "Go to my courses", "اذهب إلى دوراتي")}</Link>
          </div>
        ) : (
          <form className="gt-panel gt-fade" style={{ animationDelay: ".15s" }} onSubmit={submit}>
            {!reset ? (
              <div className="gt-tabs" role="tablist">
                <button type="button" role="tab" aria-selected={mode === "signup"} onClick={() => { setMode("signup"); setErr(""); }}>
                  {t(lang, "Create account", "إنشاء حساب")}</button>
                <button type="button" role="tab" aria-selected={mode === "signin"} onClick={() => { setMode("signin"); setErr(""); }}>
                  {t(lang, "Sign in", "تسجيل الدخول")}</button>
              </div>
            ) : null}
            {mode === "signup" && !reset ? (
              <>
                <Field label={t(lang, "Full name", "الاسم الكامل")} autoComplete="name" required maxLength={80}
                  value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
                <label className="gt-field"><span>{t(lang, "I am a…", "أنا…")}</span>
                  <select className="gt-select" value={f.who} onChange={(e) => setF({ ...f, who: e.target.value })}>
                    <option value="student">{t(lang, "Student", "طالب")}</option>
                    <option value="parent">{t(lang, "Parent", "وليّ أمر")}</option>
                  </select>
                </label>
              </>
            ) : null}
            <Field label={t(lang, "Email", "البريد الإلكتروني")} type="email" autoComplete="email" required dir="ltr"
              value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
            {mode === "signup" && !reset ? (
              <Field label={t(lang, "WhatsApp / phone (optional)", "واتساب / الهاتف (اختياري)")} type="tel" autoComplete="tel" dir="ltr" maxLength={40}
                value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
            ) : null}
            {reset ? (
              <>
                <Field label={t(lang, "Reset code (if you have one)", "رمز إعادة التعيين (إن وُجد)")} dir="ltr" autoComplete="one-time-code"
                  value={code} onChange={(e) => setCode(e.target.value)} />
                {code.trim() ? (
                  <Field label={t(lang, "New password", "كلمة المرور الجديدة")} type="password" dir="ltr" required minLength={8}
                    autoComplete="new-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
                ) : null}
              </>
            ) : null}
            {!reset ? (
              <Field label={t(lang, "Password", "كلمة المرور")} type="password" dir="ltr" required minLength={8}
                autoComplete={mode === "signup" ? "new-password" : "current-password"}
                value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
            ) : null}
            {mode === "signup" && !reset ? (
              <p style={{ fontSize: 12.5, color: "#A99F8E", margin: "-6px 0 14px" }}>
                {t(lang, "At least 8 characters, with a letter and a number.", "8 أحرف على الأقل، تحتوي حرفاً ورقماً.")}</p>
            ) : null}
            {err ? <div className="gt-err" role="alert">{err}</div> : null}
            {notice ? <div className="gt-ok" role="status">{notice}</div> : null}
            <button className="gt-btn" disabled={busy}>
              {busy ? t(lang, "Please wait…", "يرجى الانتظار…")
                : reset ? (code.trim() ? t(lang, "Set new password", "تعيين كلمة مرور جديدة") : t(lang, "Request reset code", "طلب رمز إعادة التعيين"))
                : mode === "signup" ? t(lang, "Create my free account", "أنشئ حسابي المجاني") : t(lang, "Sign in", "تسجيل الدخول")}
            </button>
            <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 10, marginTop: 16, fontSize: 13.5 }}>
              {mode === "signin" || reset ? (
                <button type="button" className="gt-link" onClick={() => { setReset(!reset); setErr(""); setNotice(""); }}>
                  {reset ? t(lang, "Back to sign in", "العودة لتسجيل الدخول") : t(lang, "Forgot password?", "نسيت كلمة المرور؟")}
                </button>) : <span />}
              <Link to="/" className="gt-link">{t(lang, "← Back", "رجوع →")}</Link>
            </div>
            <p style={{ fontSize: 12.5, color: "#8F8575", marginTop: 16, lineHeight: 1.5 }}>
              {t(lang, "Guest accounts can watch lessons, answer questions and take exams. Only the owner can add or change content.",
                "حسابات الضيوف تستطيع مشاهدة الدروس والإجابة عن الأسئلة وتقديم الاختبارات. المالك وحده يضيف المحتوى أو يعدّله.")}
            </p>
          </form>
        )}
      </main>
    </Stage>
  );
}
