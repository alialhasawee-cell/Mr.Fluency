import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { Shell } from "../components/shell";
import { Staircase, LevelChip, Mark } from "../components/brand";
import { Report } from "../components/report";
import { useSession } from "../components/session";
import { BigArrow, Reveal } from "../components/motion";
import { GOALS, PROFILE } from "../lib/courses";
import { SITE } from "../lib/site";

function SubmittedNotice() {
  return (
    <Reveal variant="pop">
      <div className="mf-banner mb-8" style={{ borderColor: "#4ADE80", background: "linear-gradient(120deg, rgba(74,222,128,.18), rgba(37,99,235,.2))" }}>
        <div style={{ fontSize: 24, fontWeight: 900 }}>✅ Test submitted</div>
        <p style={{ fontSize: 18, marginTop: 6, color: "var(--ink-2)" }}>
          Your result has been sent automatically to the owner, <b style={{ color: "#fff" }}>{PROFILE.fullName}</b>.
          You don't need to send anything — he will contact you about your course.
        </p>
        <div className="mt-4 flex flex-wrap gap-3">
          <Link to="/course/$slug" params={{ slug: "general-english" }} className="cta-test">Go to General English →</Link>
          <Link to="/contact" className="cta-quiet">Questions? Contact Mr. Ali</Link>
        </div>
      </div>
    </Reveal>
  );
}

export const Route = createFileRoute("/placement")({
  head: () => ({
    meta: [
      { title: "English Placement Test — Mr. Fluency" },
      { name: "description", content: "Free adaptive CEFR placement test from A0 to C2. Five to twenty-five minutes, two attempts, and you can stop and resume at any point." },
    ],
    links: [{ rel: "canonical", href: SITE + "/placement" }],
  }),
  component: Placement,
});

const post = async (body: any) => {
  const r = await fetch("/api/test", {
    method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify(body), credentials: "same-origin",
  });
  return { ok: r.ok, data: await r.json().catch(() => ({})) };
};
const mmss = (ms: number) => {
  const t = Math.max(0, Math.round(ms / 1000));
  return Math.floor(t / 60) + ":" + String(t % 60).padStart(2, "0");
};
const RULES: [string, string, string][] = [
  ["✕", "You cannot skip questions.", "Every question must be answered before the next one appears. There is no back button and no way to jump ahead."],
  ["⏱", "Each question has a time limit.", "75 seconds for grammar and vocabulary, 150 seconds for reading. The countdown is shown at the top of the screen."],
  ["→", "When the time expires, the question is submitted automatically.", "It is marked as unanswered and the test moves on. This is the only time the test advances without an answer."],
  ["⏸", "You can save and exit at any time.", "Your progress is saved and the question timer stops. Resuming brings you back to the same question with the time you had left."],
  ["✓", "Your progress will be saved.", "Closing the browser, losing connection or refreshing the page will not lose your answers or restart the test."],
  ["②", "You have two placement attempts.", "Pausing, exiting and resuming do not use up an attempt."],
  ["✉", "Your result goes directly to Mr. Ali.", "When you submit the last answer, the website sends your result straight to the owner, Mr. Ali Abdul Karim Muhammad, by email and WhatsApp. Nobody can change it."],
];

function Wrap({ children }: { children: ReactNode }) {
  return <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6 sm:py-16">{children}</div>;
}
function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="mb-4 block"><span className="mf-label">{label}</span>{children}</label>;
}

function Placement() {
  const [phase, setPhase] = useState<"loading" | "register" | "instructions" | "test" | "blocked">("loading");
  const [st, setSt] = useState<any>(null);
  const [form, setForm] = useState({ name: "", email: "", goal: "general" });
  const [info, setInfo] = useState<any>(null);
  const [pick, setPick] = useState<number | null>(null);
  const [left, setLeft] = useState(0);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [exitAsk, setExitAsk] = useState(false);
  const { user } = useSession();
  useEffect(() => {
    if (user) setForm((f) => ({ ...f, name: f.name || user.name || "", email: f.email || user.email || "" }));
  }, [user]);
  const offset = useRef(0);
  const firing = useRef(false);
  const pickRef = useRef<number | null>(null);
  pickRef.current = pick;

  const take = useCallback((d: any) => {
    if (d?.serverNow) offset.current = d.serverNow - Date.now();
    setSt(d); setPick(null); firing.current = false;
    if (d?.status && d.status !== "NONE") setPhase("test");
  }, []);

  const answer = useCallback(async (choice: number, auto = false) => {
    setBusy(true); setErr("");
    const { ok, data } = await post({ action: "answer", itemId: st?.question?.id, choice });
    setBusy(false);
    if (!ok && data?.error === "wrong_question") {
      const r = await fetch("/api/test", { credentials: "same-origin" });
      take(await r.json()); return;
    }
    if (!ok) { firing.current = false; if (!auto) setErr("That answer could not be recorded. Please try again."); return; }
    take(data);
  }, [st, take]);

  useEffect(() => {
    let live = true;
    fetch("/api/test", { credentials: "same-origin" })
      .then((r) => r.json())
      .then((d) => { if (!live) return; if (d?.status && d.status !== "NONE") take(d); else setPhase("register"); })
      .catch(() => setPhase("register"));
    return () => { live = false; };
  }, [take]);

  // The countdown is drawn from the server's own deadline, corrected for clock skew.
  useEffect(() => {
    if (st?.status !== "IN_PROGRESS" || !st?.deadlineAt) return;
    const tick = () => {
      const ms = st.deadlineAt - (Date.now() + offset.current);
      setLeft(ms);
      if (ms <= 0 && !firing.current) { firing.current = true; void answer(pickRef.current ?? -1, true); }
    };
    tick();
    const h = window.setInterval(tick, 250);
    return () => window.clearInterval(h);
  }, [st, answer]);

  useEffect(() => {
    if (st?.status !== "IN_PROGRESS") return;
    const h = (e: BeforeUnloadEvent) => { e.preventDefault(); e.returnValue = ""; };
    window.addEventListener("beforeunload", h);
    return () => window.removeEventListener("beforeunload", h);
  }, [st?.status]);

  async function checkStatus() {
    if (!form.name.trim()) { setErr("Please enter your name."); return; }
    setBusy(true); setErr("");
    const { data } = await post({ action: "status", name: form.name, email: form.email });
    setBusy(false); setInfo(data);
    if (data?.open) {
      const r = await fetch("/api/test?id=" + data.open.attemptId, { credentials: "same-origin" });
      take(await r.json()); return;
    }
    if (data && data.left <= 0) { setPhase("blocked"); return; }
    setPhase("instructions");
  }
  async function begin() {
    setBusy(true); setErr("");
    const { ok, data } = await post({ action: "start", ...form });
    setBusy(false);
    if (!ok) {
      if (data?.error === "no_attempts") { setPhase("blocked"); return; }
      setErr(data?.error === "name_required" ? "Please enter your name." : "The test could not be started. Please try again.");
      return;
    }
    take(data);
  }
  async function doPause() { setBusy(true); const { data } = await post({ action: "pause" }); setBusy(false); setExitAsk(false); take(data); }
  async function doResume() { setBusy(true); const { data } = await post({ action: "resume" }); setBusy(false); take(data); }

  if (phase === "loading") return <Shell><Wrap><p className="mf-prose">Opening the test…</p></Wrap></Shell>;

  if (phase === "blocked") return (
    <Shell><Wrap>
      <div className="mf-eyebrow mb-3">Placement test</div>
      <h1 className="text-3xl">Placement test complete</h1>
      <p className="mf-prose mt-4">
        You have used all {info?.allowed ?? 2} placement attempts, so your most recent result stands.
        If you need to sit the test again, contact {PROFILE.name} on {PROFILE.phoneDisplay} and he can
        authorise a further attempt.
      </p>
      {info?.lastResult ? <div className="mt-8"><SubmittedNotice /><Report r={info.lastResult} /></div> : null}
      <Link to="/contact" className="cta-quiet mt-8">Contact Mr. Fluency</Link>
    </Wrap></Shell>
  );

  if (phase === "register") return (
    <Shell><Wrap>
      <div className="mf-eyebrow mb-3">Placement test</div>
      <h1 className="mf-hero-title"><span className="mf-glow-text">Find your English level</span></h1>
      <p className="mf-prose mt-4" style={{ fontSize: 19 }}>
        This is your first step. Five to twenty-five minutes, depending on how far you get. Courses unlock after the test,
        and your result is sent automatically to {PROFILE.fullName}.
      </p>
      <div className="mt-6 flex flex-wrap items-center gap-4">
        <BigArrow size={56} />
        <Link to="/courses" className="mf-link" style={{ fontSize: 16 }}>Skip for now — just browse the courses (they stay locked until you take the test)</Link>
      </div>
      <div className="mf-card mt-8 p-6 sm:p-8">
        <Field label="Full name (required)">
          <input className="mf-field" id="mf-name" value={form.name} autoComplete="name"
            onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="First and family name" />
        </Field>
        <Field label="Email address (optional)">
          <input className="mf-field" id="mf-email" type="email" value={form.email} autoComplete="email"
            onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="name@example.com" />
        </Field>
        <p className="mb-4 text-xs" style={{ color: "var(--ink-3)" }}>
          Your email identifies your attempt so you can resume it on another device, and lets Mr. Fluency
          send you the result. It is never shared or published.
        </p>
        <Field label="What do you need English for?">
          <select className="mf-field" id="mf-goal" value={form.goal}
            onChange={(e) => setForm({ ...form, goal: e.target.value })}>
            {GOALS.map((g) => <option key={g.id} value={g.id}>{g.label}</option>)}
          </select>
        </Field>
        {err ? <p className="mb-3 text-sm" style={{ color: "var(--danger)" }}>{err}</p> : null}
        <button className="cta-test w-full justify-center" onClick={checkStatus} disabled={busy}>
          {busy ? "Checking…" : "Continue →"}
        </button>
      </div>
      <div className="mf-card mt-6 p-6">
        <h2 className="text-xl">Where the test places you</h2>
        <div className="mt-4"><Staircase /></div>
      </div>
    </Wrap></Shell>
  );

  if (phase === "instructions") return (
    <Shell><Wrap>
      <div className="mf-eyebrow mb-3">Before you begin</div>
      <h1 className="text-4xl">Placement test instructions</h1>
      <p className="mf-prose mt-4">
        Read these six points. The test starts as soon as you press the button below, and the timer on
        question one starts with it. This is attempt {(info?.used ?? 0) + 1} of {info?.allowed ?? 2}.
      </p>
      <div className="mt-8 grid gap-3">
        {RULES.map((r) => (
          <div key={r[1]} className="flex gap-3.5 rounded-xl p-4"
            style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
            <span aria-hidden="true" className="grid h-7 w-7 flex-none place-items-center rounded-lg text-sm"
              style={{ background: "#2563EB", color: "#fff" }}>{r[0]}</span>
            <div><b className="block">{r[1]}</b>
              <p className="mt-1 text-sm" style={{ color: "var(--ink-2)" }}>{r[2]}</p></div>
          </div>
        ))}
      </div>
      {err ? <p className="mt-4 text-sm" style={{ color: "var(--danger)" }}>{err}</p> : null}
      <div className="mt-8 flex flex-wrap gap-3">
        <button className="cta-test" onClick={begin} disabled={busy}>
          {busy ? "Starting…" : "I understand — start the test"}
        </button>
        <button className="cta-quiet" onClick={() => setPhase("register")}>Back</button>
      </div>
    </Wrap></Shell>
  );

  if (st?.status === "COMPLETED" && st?.result) return <Shell><Wrap><SubmittedNotice /><Report r={st.result} /></Wrap></Shell>;

  if (st?.status === "PAUSED") return (
    <Shell><Wrap>
      <div className="mf-card p-7" style={{ borderLeft: "3px solid var(--brass)" }}>
        <div className="mf-eyebrow mb-2">Placement test</div>
        <h1 className="text-3xl">Your test is paused</h1>
        <p className="mf-prose mt-4">
          You stopped at question {(st.index ?? 0) + 1} of {st.total} on attempt {st.attemptNo}.
          Everything you answered is saved. Resuming continues from that exact question — it does not
          restart the test and it does not use another attempt.
        </p>
        <p className="mf-mono mt-4 text-xs" style={{ color: "var(--ink-3)" }}>
          Timer held at {mmss(st.remainingMs ?? 0)} · {st.pauseCount} pause{st.pauseCount === 1 ? "" : "s"} so far
        </p>
        <button className="cta-resume mt-6" onClick={doResume} disabled={busy}>
          {busy ? "Resuming…" : "Resume placement test →"}
        </button>
      </div>
    </Wrap></Shell>
  );

  const q = st?.question;
  if (!q) return <Shell><Wrap><p className="mf-prose">Loading your question…</p></Wrap></Shell>;
  const pct = Math.round(((st.index ?? 0) / (st.total || 1)) * 100);
  const frac = Math.max(0, Math.min(1, left / ((st.secondsAllowed || 75) * 1000)));
  const warn = frac <= 0.25;
  const C = 2 * Math.PI * 15.5;
  const parts: string[] = String(q.q).split("___");

  return (
    <Shell>
      <div className="mx-auto max-w-3xl px-4 py-6 sm:px-6">
        <div className="mb-6 flex flex-wrap items-center gap-3 border-b pb-4" style={{ borderColor: "var(--line)" }}>
          <Mark size={30} />
          <div className="min-w-0">
            <b className="block text-sm">{st.name}</b>
            <span className="mf-label" style={{ marginBottom: 0 }}>Attempt {st.attemptNo} of {st.attemptsAllowed}</span>
          </div>
          <div className="ml-auto flex items-center gap-3">
            <LevelChip level={st.section} />
            <div className="relative grid h-10 w-10 place-items-center" title="Time left on this question">
              <svg viewBox="0 0 36 36" className="absolute inset-0 h-10 w-10" aria-hidden="true">
                <circle cx="18" cy="18" r="15.5" fill="none" stroke="var(--line)" strokeWidth="3" />
                <circle cx="18" cy="18" r="15.5" fill="none" strokeWidth="3" strokeLinecap="round"
                  stroke={warn ? "var(--danger)" : "var(--garnet)"} transform="rotate(-90 18 18)"
                  strokeDasharray={(C * frac).toFixed(1) + " " + C.toFixed(1)} />
              </svg>
              <span className="mf-mono relative text-[10.5px] font-semibold"
                style={{ color: warn ? "var(--danger)" : "var(--ink)" }}>{mmss(left)}</span>
            </div>
            <button className="cta-quiet" style={{ padding: "8px 14px", fontSize: 11 }}
              onClick={() => setExitAsk(true)}>Save &amp; exit</button>
          </div>
        </div>

        <div className="mb-4 flex flex-wrap items-center gap-3">
          <span className="mf-label" style={{ marginBottom: 0 }}>Question {(st.index ?? 0) + 1} of {st.total}</span>
          <span className="rounded-full px-2.5 py-0.5 text-xs font-semibold"
            style={{ background: "var(--surface-2)", border: "1px solid var(--line)", color: "var(--ink-2)" }}>{q.skill}</span>
          <span className="mf-mono ml-auto text-[10px]" style={{ color: "var(--ink-3)" }}>{st.secondsAllowed}s allowed</span>
        </div>

        {q.passage ? (
          <div className="mb-5 rounded-lg p-4 text-[15px] leading-relaxed"
            style={{ background: "var(--surface)", border: "1px solid var(--line)", borderLeft: "3px solid var(--brass)", color: "var(--ink-2)" }}>
            {q.passage}
          </div>
        ) : null}

        <h1 className="mb-6 text-2xl leading-snug sm:text-[1.7rem]">
          {parts.map((part, i) => (
            <span key={i}>
              {part}
              {i < parts.length - 1 ? <span style={{ borderBottom: "2px dotted var(--brass)", padding: "0 1.6em" }} /> : null}
            </span>
          ))}
        </h1>

        <div role="radiogroup" aria-label="Answer options" className="grid gap-2.5">
          {q.opts.map((o: string, i: number) => (
            <button key={i} role="radio" aria-checked={pick === i} className="opt-btn"
              onClick={() => setPick(i)} disabled={busy}>
              <span className="opt-key">{"ABCD"[i]}</span><span>{o}</span>
            </button>
          ))}
        </div>
        <p className="mt-5 text-center text-xs italic" style={{ color: "var(--ink-3)" }}>
          You must answer this question to continue — questions cannot be skipped or revisited.
        </p>
        {err ? <p className="mt-3 text-center text-sm" style={{ color: "var(--danger)" }}>{err}</p> : null}

        <div className="mt-7 flex items-center gap-4 border-t pt-5" style={{ borderColor: "var(--line)" }}>
          <div className="mf-bar flex-1" role="progressbar" aria-valuenow={pct} aria-valuemin={0}
            aria-valuemax={100} style={{ pointerEvents: "none" }}>
            <i style={{ width: pct + "%" }} />
          </div>
          <span className="mf-mono whitespace-nowrap text-[10px]" style={{ color: "var(--ink-3)" }}>Progress {pct}%</span>
          <button className="cta-test" style={{ padding: "12px 22px", fontSize: 15 }}
            disabled={pick === null || busy} onClick={() => answer(pick as number)}>
            {busy ? "Saving…" : "Next question →"}
          </button>
        </div>
      </div>

      {exitAsk ? (
        <div className="fixed inset-0 z-50 grid place-items-center p-4" style={{ background: "rgba(20,18,15,.55)" }}>
          <div className="mf-card w-full max-w-md p-6">
            <h2 className="text-xl">Leave the test?</h2>
            <p className="mf-prose mt-3 text-sm">
              Your placement test is currently in progress. If you leave without saving, your current
              session may be affected.
            </p>
            <div className="mf-note mt-4">
              Saving and exiting does <b>not</b> use up a placement attempt. You will come back to this exact
              question with your answers intact and the time you had left.
            </div>
            <div className="mt-6 flex flex-wrap justify-end gap-2">
              <button className="cta-test" style={{ padding: "11px 20px", fontSize: 14 }}
                onClick={() => setExitAsk(false)}>Continue test</button>
              <button className="cta-quiet" onClick={doPause} disabled={busy}>Save &amp; exit</button>
            </div>
          </div>
        </div>
      ) : null}
    </Shell>
  );
}
