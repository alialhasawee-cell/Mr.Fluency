import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell } from "../components/shell";
import { LevelChip, Staircase } from "../components/brand";
import { api, useSession, Spinner, ErrorNote, EmptyNote } from "../components/session";

export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [{ title: "My learning — Mr. Fluency" }, { name: "robots", content: "noindex" }] }),
  component: Dashboard,
});

function Dashboard() {
  const { user, loading } = useSession();
  const router = useRouter();
  const [d, setD] = useState<any>(null);
  const [err, setErr] = useState(false);

  const load = async () => {
    setErr(false);
    const { ok, data } = await api.get("/api/lms?what=dashboard");
    if (!ok) return setErr(true);
    setD(data);
  };
  useEffect(() => { if (user) void load(); }, [user]);
  useEffect(() => { if (!loading && !user) router.navigate({ to: "/login" }); }, [loading, user, router]);

  if (loading || (!d && !err)) return <Shell><Wrap><Spinner label="Opening your dashboard…" /></Wrap></Shell>;
  if (err) return <Shell><Wrap><ErrorNote onRetry={load}>Your dashboard did not load. Check your connection and try again.</ErrorNote></Wrap></Shell>;

  const first = (user?.name ?? "").split(" ")[0];
  const level = d.placement?.level ?? user?.cefr_level ?? null;

  return (
    <Shell>
      <Wrap>
        <div className="flex flex-wrap items-end gap-4">
          <div>
            <div className="mf-eyebrow mb-2">My learning</div>
            <h1 className="text-4xl">Welcome, {first}</h1>
          </div>
          <div className="ml-auto flex items-center gap-4">
            <Stat k="XP" v={String(d.xp ?? user?.xp ?? 0)} />
            <Stat k="Lessons done" v={String(d.lessonsCompleted ?? 0)} />
            {d.streakDays ? <Stat k="Day streak" v={String(d.streakDays)} /> : null}
            {level ? <div className="text-center">
              <div className="mf-label">Your level</div>
              <div className="text-3xl" style={{ fontFamily: "var(--display)", color: "var(--l-" + String(level).toLowerCase() + ")" }}>{level}</div>
            </div> : null}
          </div>
        </div>

        {d.resume ? (
          <div className="mf-card mt-8 p-6" style={{ borderLeft: "3px solid var(--brass)", background: "linear-gradient(180deg,var(--brass-soft),var(--surface) 70%)" }}>
            <div className="mf-eyebrow mb-2">Continue learning</div>
            <h2 className="text-2xl">{d.resume.title}</h2>
            <p className="mf-prose mt-1 text-sm">{d.resume.courseTitle}</p>
            <Link to="/learn/$lessonId" params={{ lessonId: d.resume.id }} className="cta-test mt-5">
              Continue learning →
            </Link>
          </div>
        ) : null}

        <h2 className="mt-12 text-2xl">My courses</h2>
        {d.courses?.length ? (
          <div className="mt-4 grid gap-3">
            {d.courses.map((c: any) => (
              <Link key={c.id} to="/course/$slug" params={{ slug: c.slug }}
                className="mf-card flex flex-wrap items-center gap-4 p-5 no-underline"
                style={{ borderLeft: "3px solid " + (c.color || "var(--garnet)"), color: "var(--ink)" }}>
                <div className="min-w-[200px] flex-1">
                  <b className="text-lg" style={{ fontFamily: "var(--display)" }}>{c.title}</b>
                  <div className="mt-2 mf-bar" style={{ maxWidth: 420 }}><i style={{ width: (c.progress_pct ?? 0) + "%" }} /></div>
                  <p className="mf-mono mt-1.5 text-xs" style={{ color: "var(--ink-3)" }}>
                    {c.progress_pct ?? 0}% complete · {c.status}
                  </p>
                </div>
                <span className="cta-quiet" style={{ padding: "9px 16px", fontSize: 11 }}>Open</span>
              </Link>
            ))}
          </div>
        ) : (
          <EmptyNote title="You are not enrolled yet">
            Take the placement test to find your level, then join the programme it recommends.
          </EmptyNote>
        )}

        <div className="mt-12 grid gap-6 lg:grid-cols-2">
          <section>
            <h2 className="text-2xl">Placement result</h2>
            {d.placement ? (
              <div className="mf-card mt-4 p-6">
                <div className="flex flex-wrap items-center gap-3">
                  <LevelChip level={d.placement.level} />
                  <b style={{ fontFamily: "var(--display)", fontSize: 18 }}>{d.placement.levelName}</b>
                  <span className="mf-mono ml-auto text-sm">{d.placement.percent}%</span>
                </div>
                <div className="mt-4"><Staircase current={d.placement.level} /></div>
                <p className="mt-3 text-sm" style={{ color: "var(--ink-2)" }}>
                  Recommended: <b>{d.placement.course}</b>{d.placement.entry ? ` — start at ${d.placement.entry}` : ""}
                </p>
              </div>
            ) : (
              <div className="mf-card mt-4 p-6">
                <p className="mf-prose text-sm">You have not taken the placement test yet.</p>
                <Link to="/placement" className="cta-test mt-4">Take the placement test</Link>
              </div>
            )}
          </section>

          <section>
            <h2 className="text-2xl">Certificates</h2>
            {d.certificates?.length ? (
              <div className="mt-4 grid gap-2">
                {d.certificates.map((c: any) => (
                  <Link key={c.code} to="/verify/$code" params={{ code: c.code }}
                    className="mf-card flex flex-wrap items-center gap-3 p-4 no-underline" style={{ color: "var(--ink)" }}>
                    <b className="text-[15px]">{c.course_title}</b>
                    {c.cefr ? <LevelChip level={c.cefr} /> : null}
                    <span className="mf-mono ml-auto text-xs" style={{ color: "var(--ink-3)" }}>{c.code}</span>
                  </Link>))}
              </div>
            ) : (
              <p className="mf-prose mt-4 text-sm">
                Certificates appear here when you complete a course.
              </p>
            )}

            {d.achievements?.length ? (
              <>
                <h2 className="mt-8 text-2xl">Badges</h2>
                <div className="mt-4 flex flex-wrap gap-2">
                  {d.achievements.map((a: any) => (
                    <span key={a.code} className="mf-card flex items-center gap-2 px-3 py-2 text-sm" title={a.description ?? ""}>
                      <span aria-hidden>{a.icon || "\u2605"}</span>
                      <b>{a.title}</b>
                    </span>))}
                </div>
              </>
            ) : null}

            <h2 className="mt-8 text-2xl">Recent results</h2>
            {d.quizzes?.length ? (
              <div className="mt-4 grid gap-2">
                {d.quizzes.map((q: any, i: number) => (
                  <div key={i} className="mf-card flex items-center gap-3 p-4">
                    <span className="flex-1 text-sm font-semibold">{q.title}</span>
                    <span className="mf-mono text-sm">{q.pct}%</span>
                    <span className="text-xs" style={{ color: q.passed ? "var(--ok)" : "var(--ink-3)" }}>
                      {q.passed ? "passed" : "not passed"}
                    </span>
                  </div>))}
              </div>
            ) : <p className="mf-prose mt-4 text-sm">No quiz results yet.</p>}
          </section>
        </div>

        {d.notifications?.length ? (
          <section className="mt-12">
            <h2 className="text-2xl">Recent activity</h2>
            <div className="mt-4 grid gap-2">
              {d.notifications.slice(0, 6).map((n: any) => (
                <div key={n.id} className="mf-card p-4">
                  <b className="text-sm">{n.title}</b>
                  {n.body ? <p className="mt-1 text-sm" style={{ color: "var(--ink-2)" }}>{n.body}</p> : null}
                </div>))}
            </div>
          </section>
        ) : null}
      </Wrap>
    </Shell>
  );
}

function Wrap({ children }: { children: React.ReactNode }) {
  return <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6">{children}</div>;
}
function Stat({ k, v }: { k: string; v: string }) {
  return <div className="text-center"><div className="mf-label">{k}</div>
    <div className="mf-mono text-2xl" style={{ fontFamily: "var(--display)" }}>{v}</div></div>;
}
