import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { Shell } from "../components/shell";
import { useSession, Spinner, ErrorNote } from "../components/session";
import { Tabs, Toast, useToast } from "../components/studio-ui";
import { Overview, Courses } from "../components/studio-courses";
import { Bank, Students, Certs, MediaTab, Announce } from "../components/studio-admin";
import { OwnerInbox } from "../components/owner-inbox";

export const Route = createFileRoute("/studio")({
  head: () => ({ meta: [{ title: "Teacher area — Mr. Fluency" }, { name: "robots", content: "noindex" }] }),
  component: Studio,
});

const TABS = [
  { id: "inbox", label: "Inbox" }, { id: "overview", label: "Overview" }, { id: "courses", label: "Courses" },
  { id: "bank", label: "Question bank" }, { id: "students", label: "People" },
  { id: "certs", label: "Certificates" }, { id: "media", label: "Upload videos & files" },
  { id: "announce", label: "Announcements" },
];

function Studio() {
  const { user, loading } = useSession();
  const router = useRouter();
  const [tab, setTab] = useState("inbox");
  const { msg, toast } = useToast();
  const staff = !!user && ["owner", "admin", "teacher"].includes(user.role);

  useEffect(() => {
    if (loading) return;
    if (!user) router.navigate({ to: "/owner" });
    else if (!["owner", "admin", "teacher"].includes(user.role)) router.navigate({ to: "/dashboard" });
  }, [loading, user, router]);

  if (loading || !user) return <Shell><Wrap><Spinner /></Wrap></Shell>;
  if (!staff) return <Shell><Wrap><ErrorNote>This area is for teachers and administrators.</ErrorNote></Wrap></Shell>;

  return (
    <Shell>
      <Wrap>
        <div className="flex flex-wrap items-end gap-4">
          <div>
            <div className="mf-eyebrow mb-2">Teacher area</div>
            <h1 className="text-3xl">Mr. Fluency Studio</h1>
          </div>
          <span className="ml-auto text-sm" style={{ color: "var(--ink-2)" }}>
            {user.name} · <b style={{ color: "var(--brass)" }}>{user.role}</b>
          </span>
        </div>
        <div className="mt-6"><Tabs tabs={TABS} active={tab} onChange={setTab} /></div>
        <div className="mt-8">
          {tab === "inbox" ? <OwnerInbox /> : null}
          {tab === "overview" ? <Overview /> : null}
          {tab === "courses" ? <Courses toast={toast} /> : null}
          {tab === "bank" ? <Bank toast={toast} /> : null}
          {tab === "students" ? <Students toast={toast} isOwner={user.role === "owner"} /> : null}
          {tab === "certs" ? <Certs toast={toast} /> : null}
          {tab === "media" ? <MediaTab toast={toast} /> : null}
          {tab === "announce" ? <Announce toast={toast} /> : null}
        </div>
      </Wrap>
      <Toast msg={msg} />
    </Shell>
  );
}
function Wrap({ children }: { children: ReactNode }) {
  return <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">{children}</div>;
}
