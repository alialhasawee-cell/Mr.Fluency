import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { Shell } from "../../components/shell";
import { api, useSession, Spinner, ErrorNote } from "../../components/session";
import { Reveal, WordField } from "../../components/motion";
import { LEVEL_LOOK, PlacementGate } from "../../components/levels";

export const Route = createFileRoute("/course/$slug")({ component: CoursePage });

function CoursePage() {
  const { slug } = Route.useParams();
  const { user } = useSession();
  const [d, setD] = useState<any>(null);
  const [err, setErr] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  const load = useCallback(async () => {
    setErr(false);
    const { ok, data } = await api.get("/api/lms?what=course&slug=" + encodeURIComponent(slug));
    if (!ok) return setErr(true);
    setD(data);
  }, [slug]);
  useEffect(() => { void load(); }, [load, user]);

  async function join() {
    setBusy(true); setMsg("");
    const { ok, data } = await api.post("/api/lms", { action: "enroll", courseId: d.course.id });
    setBusy(false);
    if (ok) void load(); else setMsg(data?.message ?? "Could not start the course.");
  }

  if (!d && !err) return <Shell><Wrap><Spinner /></Wrap></Shell>;
  if (err) return <Shell><Wrap><ErrorNote onRetry={load}>That course could not be loaded.</ErrorNote></Wrap></Shell>;

  const { course, tree, enrolled, levels, placed } = d;
  const staff = !!user && user.role !== "student";

  return (
    <Shell>
      <section className="relative overflow-hidden">
        <WordField />
        <Wrap>
          <Reveal variant="blur"><div className="mf-eyebrow mb-3">{course.subtitle ?? "Programme"}</div></Reveal>
          <Reveal variant="rise" delay={0.1}><h1 className="mf-hero-title"><span className="mf-glow-text">{course.title}</span></h1></Reveal>
          {course.description ? <Reveal variant="slide-l" delay={0.2}><p className="mf-prose mt-4" style={{ fontSize: 20 }}>{course.description}</p></Reveal> : null}
          <div className="mt-8"><Reveal variant="pop" delay={0.3}>{staff ? null : <PlacementGate placed={placed} signedIn={!!user} />}</Reveal></div>
          {user && placed && !enrolled && !staff ? (
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <button className="cta-test" style={{ fontSize: 19, padding: "16px 30px" }} onClick={join} disabled={busy}>
                {busy ? "Starting…" : "Start this course"}
              </button>
              {msg ? <span style={{ color: "#FCA5A5" }}>{msg}</span> : null}
            </div>
          ) : null}
          {enrolled ? <p className="mt-6" style={{ color: "var(--ok)", fontWeight: 700 }}>✓ You are enrolled — choose your level below.</p> : null}

          <h2 className="mt-14 text-3xl sm:text-4xl">Choose a level</h2>
          <p className="mf-prose mt-2">Each level has its own page with chapters, videos, audio, quizzes and a final exam.</p>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {(tree?.levels ?? []).map((lvl: any, i: number) => {
              const look = LEVEL_LOOK[lvl.cefr] ?? LEVEL_LOOK.A1;
              const st = levels?.[lvl.id];
              const chapters = lvl.modules.filter((m: any) => m.lessons.length).length;
              const lessons = lvl.modules.reduce((n: number, m: any) => n + m.lessons.length, 0);
              const locked = !staff && (!placed || (st && !st.open));
              return (
                <Reveal key={lvl.id} index={i + 1}>
                  <Link to="/level/$slug/$cefr" params={{ slug, cefr: lvl.cefr }} className="mf-card mf-level-tile no-underline"
                    style={{ color: "var(--ink)", ["--lv" as any]: look.color }}>
                    <div className="mf-level-top" style={{ background: look.grad }}>
                      <span className="mf-level-code">{lvl.cefr}</span>
                      <span className="mf-level-icon" aria-hidden="true">{look.icon}</span>
                    </div>
                    <div className="p-6">
                      <div style={{ color: look.color, fontWeight: 800, letterSpacing: ".08em", textTransform: "uppercase", fontSize: 13 }}>{look.name}</div>
                      <h3 className="mt-1 text-2xl">{lvl.title}</h3>
                      <div className="mt-2" style={{ color: "var(--ink-3)", fontSize: 15 }}>{chapters} chapters · {lessons} lessons · final exam</div>
                      <div className="mt-4 flex items-center justify-between gap-2" style={{ fontWeight: 800 }}>
                        <span>{locked ? "🔒 " + (st?.reason ?? "Take the placement test first.") : st?.finalPassed ? "✓ Passed" : "Open level"}</span>
                        <span className="mf-level-go" aria-hidden="true">→</span>
                      </div>
                    </div>
                  </Link>
                </Reveal>
              );
            })}
          </div>
        </Wrap>
      </section>
    </Shell>
  );
}
function Wrap({ children }: { children: React.ReactNode }) {
  return <div className="relative z-10 mx-auto max-w-6xl px-4 py-12 sm:px-6">{children}</div>;
}
