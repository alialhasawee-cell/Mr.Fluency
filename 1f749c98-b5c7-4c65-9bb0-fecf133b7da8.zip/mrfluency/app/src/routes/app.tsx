import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "../components/shell";
import { Reveal, BigArrow } from "../components/motion";

export const Route = createFileRoute("/app")({
  head: () => ({
    meta: [
      { title: "Android app — Mr. Fluency Academy" },
      { name: "description", content: "Download the Mr. Fluency Academy Android app: all courses, videos, audio, quizzes and the placement test on your phone." },
    ],
  }),
  component: AppPage,
});

const STEPS = [
  ["Download", "Tap the yellow button to download mr-fluency.apk (about 1 MB).", "تحميل: اضغط الزر الأصفر لتنزيل التطبيق."],
  ["Allow install", "When Android asks, allow installing apps from your browser or Files app.", "السماح: اسمح بتثبيت التطبيقات من المتصفح عند الطلب."],
  ["Install & open", "Open the downloaded file, tap Install, then open Mr. Fluency.", "التثبيت: افتح الملف واضغط تثبيت ثم افتح التطبيق."],
  ["Sign in", "Sign in with the same email and password you use on the website.", "الدخول: سجّل الدخول بنفس البريد وكلمة المرور."],
];

function AppPage() {
  return (
    <Shell>
      <div className="relative z-10 mx-auto max-w-5xl px-4 py-14 sm:px-6">
        <Reveal variant="blur"><div className="mf-eyebrow mb-3">Android app · تطبيق أندرويد</div></Reveal>
        <Reveal variant="rise" delay={0.1}><h1 className="mf-hero-title"><span className="mf-glow-text">Mr. Fluency on your phone</span></h1></Reveal>
        <Reveal variant="slide-l" delay={0.2}>
          <p className="mf-prose mt-4" style={{ fontSize: 20 }}>
            Every course, video, audio lesson, quiz and the placement test — in one app. Your progress is the same on the website and in the app.
          </p>
        </Reveal>
        <div className="mt-8 flex flex-wrap items-center gap-5">
          <BigArrow dir="right" size={56} />
          <a href="/download/mr-fluency.apk" download className="cta-resume" style={{ fontSize: 20, padding: "18px 30px" }}>
            ⬇ Download for Android (.apk)
          </a>
        </div>
        <p className="mt-3" style={{ color: "var(--ink-3)", fontSize: 15 }}>Android 7.0 or newer. iPhone users can add the website to the Home Screen from Safari's Share menu.</p>
        <div className="mt-12 grid gap-5 sm:grid-cols-2">
          {STEPS.map(([t, en, ar], i) => (
            <Reveal key={t} index={i + 1}>
              <div className="mf-card hoverable h-full p-6">
                <div style={{ fontSize: 40, fontWeight: 900, color: "#FFD54A" }}>{i + 1}</div>
                <h2 className="mt-1 text-2xl">{t}</h2>
                <p className="mt-2" style={{ color: "var(--ink-2)", fontSize: 17 }}>{en}</p>
                <p className="mt-1" dir="rtl" style={{ color: "var(--ink-3)", fontSize: 16 }}>{ar}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </Shell>
  );
}
