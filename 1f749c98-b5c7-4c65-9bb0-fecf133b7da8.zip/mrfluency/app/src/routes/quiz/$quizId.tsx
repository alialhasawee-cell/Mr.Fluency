import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { Shell } from "../../components/shell";
import { api, useSession, Spinner, ErrorNote } from "../../components/session";
import { useAudioLayer } from "../../components/audio-layer";

export const Route = createFileRoute("/quiz/$quizId")({
  head: () => ({ meta: [{ name: "robots", content: "noindex" }] }),
  component: QuizPlayer,
});
const mmss = (ms: number) => { const t = Math.max(0, Math.round(ms / 1000)); return Math.floor(t / 60) + ":" + String(t % 60).padStart(2, "0"); };

function QuizPlayer() {
  const { quizId } = Route.useParams();
  const { user, loading } = useSession();
  const router = useRouter();
  const [st, setSt] = useState<any>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [resp, setResp] = useState<any>(null);
  const [left, setLeft] = useState(0);
  const offset = useRef(0);
  const firing = useRef(false);
  const respRef = useRef<any>(null);
  respRef.current = resp;

  const take = useCallback((d: any) => {
    if (d?.serverNow) offset.current = d.serverNow - Date.now();
    setSt(d); setResp(null); firing.current = false;
  }, []);

  const start = useCallback(async () => {
    setErr("");
    const { ok, data } = await api.post("/api/quiz", { action: "start", quizId });
    if (!ok) {
      setErr(data?.error === "locked" ? (data?.reason ?? "This assessment is locked.") : data?.error === "no_attempts" ? "You have used all attempts for this assessment."
        : data?.error === "empty_quiz" ? "This assessment has no questions yet."
        : "This assessment could not be started.");
      return;
    }
    take(data);
  }, [quizId, take]);

  useEffect(() => { if (user) void start(); }, [user, start]);
  useEffect(() => { if (!loading && !user) router.navigate({ to: "/login" }); }, [loading, user, router]);

  const send = useCallback(async (response: any, auto = false) => {
    setBusy(true);
    const { ok, data } = await api.post("/api/quiz", {
      action: "answer", attemptId: st?.attemptId, questionId: st?.question?.id, response,
    });
    setBusy(false);
    if (!ok && data?.error === "wrong_question") {
      const r = await api.get("/api/quiz?attempt=" + st.attemptId); take(r.data); return;
    }
    if (!ok) { firing.current = false; if (!auto) setErr("That answer was not recorded. Please try again."); return; }
    setErr(""); take(data);
  }, [st, take]);

  useEffect(() => {
    if (st?.status !== "IN_PROGRESS" || !st?.deadlineAt) return;
    const tick = () => {
      const ms = st.deadlineAt - (Date.now() + offset.current);
      setLeft(ms);
      if (ms <= 0 && !firing.current) { firing.current = true; void send(respRef.current, true); }
    };
    tick();
    const h = window.setInterval(tick, 250);
    return () => window.clearInterval(h);
  }, [st, send]);

  const audio = useAudioLayer();
  const cheered = useRef(false);
  useEffect(() => {
    if (st?.status === "COMPLETED" && st?.passed && !cheered.current) {
      cheered.current = true;
      audio?.celebrate("quiz_passed");
    }
  }, [st?.status, st?.passed, audio]);

  if (loading || (!st && !err)) return <Shell><Wrap><Spinner label="Opening the assessment…" /></Wrap></Shell>;
  if (err && !st) return <Shell><Wrap><ErrorNote onRetry={start}>{err}</ErrorNote>
    <Link to="/dashboard" className="cta-quiet mt-6">Back to my learning</Link></Wrap></Shell>;

  if (st.status === "COMPLETED" || st.status === "EXPIRED") {
    return (
      <Shell><Wrap>
        <div className="mf-card p-8 text-center">
          <div className="mf-label">{st.title}</div>
          <div className="mt-2 text-[3.5rem] leading-none"
            style={{ fontFamily: "var(--display)", color: st.passed ? "var(--ok)" : "#F87171" }}>{st.pct}%</div>
          <p className="mt-2 text-lg" style={{ fontFamily: "var(--display)", color: "var(--ink-2)" }}>
            {st.passed ? "Passed" : `Not passed — the pass mark is ${st.passPct}%`}
          </p>
          <p className="mf-mono mt-3 text-sm" style={{ color: "var(--ink-3)" }}>
            {st.score} of {st.maxScore} points · attempt {st.attemptNo}
          </p>
        </div>
        {st.review?.length ? (
          <div className="mf-card mt-4 p-6">
            <h2 className="text-xl">Your answers</h2>
            <div className="mt-4 grid gap-2">
              {st.review.map((r: any, i: number) => (
                <div key={i} className="rounded-lg p-3" style={{
                  background: "var(--surface-2)",
                  borderLeft: "3px solid " + (r.correct ? "var(--ok)" : r.status === "PENDING_REVIEW" ? "var(--brass)" : "var(--danger)"),
                }}>
                  <p className="text-sm">{r.prompt}</p>
                  <p className="mt-1 text-xs" style={{ color: "var(--ink-3)" }}>
                    {r.status === "PENDING_REVIEW" ? "Awaiting teacher review"
                      : r.correct ? "Correct" : r.status === "TIMED_OUT" ? "Time expired" : "Incorrect"}
                    {r.explanation ? " — " + r.explanation : ""}
                  </p>
                </div>))}
            </div>
          </div>) : null}
        <div className="mt-6 flex flex-wrap gap-3">
          <button className="cta-test" onClick={start}>Try again</button>
          <Link to="/dashboard" className="cta-quiet">Back to my learning</Link>
        </div>
      </Wrap></Shell>
    );
  }

  if (st.status === "PAUSED") {
    return (
      <Shell><Wrap>
        <div className="mf-card p-7" style={{ borderLeft: "3px solid var(--brass)" }}>
          <h1 className="text-3xl">Assessment paused</h1>
          <p className="mf-prose mt-3">
            You stopped at question {st.index + 1} of {st.total}. Everything you answered is saved.
          </p>
          <button className="cta-resume mt-6" disabled={busy} onClick={async () => {
            setBusy(true);
            const { data } = await api.post("/api/quiz", { action: "resume", attemptId: st.attemptId });
            setBusy(false); take(data);
          }}>Resume →</button>
        </div>
      </Wrap></Shell>
    );
  }

  const q = st.question;
  if (!q) return <Shell><Wrap><Spinner /></Wrap></Shell>;
  const pct = Math.round((st.index / Math.max(1, st.total)) * 100);
  const canSend = !isEmpty(resp);

  return (
    <Shell>
      <Wrap>
        <div className="mb-6 flex flex-wrap items-center gap-3 border-b pb-4" style={{ borderColor: "var(--line)" }}>
          <div><b className="block text-sm">{st.title}</b>
            <span className="mf-label" style={{ marginBottom: 0 }}>Attempt {st.attemptNo}</span></div>
          <div className="ml-auto flex items-center gap-3">
            {st.secondsAllowed ? (
              <span className="mf-mono text-sm" style={{ color: left < st.secondsAllowed * 250 ? "var(--danger)" : "var(--ink)" }}>
                {mmss(left)}
              </span>) : null}
            <button className="cta-quiet" style={{ padding: "8px 14px", fontSize: 11 }} disabled={busy}
              onClick={async () => { setBusy(true); const { data } = await api.post("/api/quiz", { action: "pause", attemptId: st.attemptId }); setBusy(false); take(data); }}>
              Save &amp; exit
            </button>
          </div>
        </div>

        <span className="mf-label">Question {st.index + 1} of {st.total}</span>
        {q.passage ? (
          <div className="my-4 rounded-lg p-4 text-[15px] leading-relaxed"
            style={{ background: "var(--surface)", border: "1px solid var(--line)", borderLeft: "3px solid var(--brass)", color: "var(--ink-2)" }}>
            {q.passage}
          </div>) : null}
        <h1 className="mb-6 mt-2 text-2xl leading-snug">{q.prompt}</h1>

        <QuestionInput q={q} value={resp} onChange={setResp} disabled={busy} />

        {st.sequential ? (
          <p className="mt-5 text-center text-xs italic" style={{ color: "var(--ink-3)" }}>
            You must answer this question to continue — questions cannot be skipped.
          </p>) : null}
        {err ? <p className="mt-3 text-center text-sm" style={{ color: "var(--danger)" }}>{err}</p> : null}

        <div className="mt-7 flex items-center gap-4 border-t pt-5" style={{ borderColor: "var(--line)" }}>
          <div className="mf-bar flex-1" role="progressbar" aria-valuenow={pct} style={{ pointerEvents: "none" }}>
            <i style={{ width: pct + "%" }} />
          </div>
          <span className="mf-mono text-[10px]" style={{ color: "var(--ink-3)" }}>{pct}%</span>
          <button className="cta-test" style={{ padding: "12px 22px", fontSize: 15 }}
            disabled={busy || (st.sequential && !canSend)} onClick={() => send(resp)}>
            {busy ? "Saving…" : st.index + 1 === st.total ? "Finish" : "Next →"}
          </button>
        </div>
      </Wrap>
    </Shell>
  );
}

function isEmpty(r: any) {
  if (r === null || r === undefined || r === "") return true;
  if (Array.isArray(r)) return r.length === 0 || r.every((x) => !x);
  if (typeof r === "object") return Object.keys(r).length === 0;
  return false;
}

function QuestionInput({ q, value, onChange, disabled }: { q: any; value: any; onChange: (v: any) => void; disabled: boolean }) {
  if (q.type === "mcq" || q.type === "truefalse") {
    return (
      <div role="radiogroup" className="grid gap-2.5">
        {q.options.map((o: any, i: number) => (
          <button key={o.id} role="radio" aria-checked={value === o.id} className="opt-btn" disabled={disabled}
            onClick={() => onChange(o.id)}>
            <span className="opt-key">{"ABCDEF"[i]}</span><span>{o.text}</span>
          </button>))}
      </div>);
  }
  if (q.type === "multi") {
    const arr: string[] = Array.isArray(value) ? value : [];
    return (
      <div className="grid gap-2.5">
        {q.options.map((o: any, i: number) => {
          const on = arr.includes(o.id);
          return (
            <button key={o.id} aria-pressed={on} className="opt-btn" aria-checked={on} role="checkbox" disabled={disabled}
              onClick={() => onChange(on ? arr.filter((x) => x !== o.id) : [...arr, o.id])}>
              <span className="opt-key">{on ? "✓" : "ABCDEF"[i]}</span><span>{o.text}</span>
            </button>);
        })}
        <p className="text-xs" style={{ color: "var(--ink-3)" }}>Choose every correct answer.</p>
      </div>);
  }
  if (q.type === "gap") {
    const n = q.gaps ?? 1;
    const arr: string[] = Array.isArray(value) ? value : Array(n).fill("");
    return (
      <div className="grid gap-2.5">
        {Array.from({ length: n }, (_, i) => (
          <input key={i} className="mf-field" placeholder={`Gap ${i + 1}`} value={arr[i] ?? ""} disabled={disabled}
            onChange={(e) => { const c = [...arr]; c[i] = e.target.value; onChange(c); }} />))}
      </div>);
  }
  if (q.type === "match") {
    const obj: Record<string, string> = value && typeof value === "object" ? value : {};
    return (
      <div className="grid gap-2.5">
        {(q.left ?? []).map((l: string) => (
          <div key={l} className="flex flex-wrap items-center gap-3 rounded-lg p-3"
            style={{ background: "var(--surface-2)", border: "1px solid var(--line)" }}>
            <span className="min-w-[150px] flex-1 text-[15px]">{l}</span>
            <select className="mf-field" style={{ width: 200 }} value={obj[l] ?? ""} disabled={disabled}
              onChange={(e) => onChange({ ...obj, [l]: e.target.value })}>
              <option value="">Choose…</option>
              {(q.right ?? []).map((r: string) => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>))}
      </div>);
  }
  if (q.type === "order") {
    const arr: string[] = Array.isArray(value) && value.length ? value : (q.items ?? []);
    const move = (i: number, d: number) => {
      const c = [...arr]; const j = i + d;
      if (j < 0 || j >= c.length) return;
      [c[i], c[j]] = [c[j], c[i]]; onChange(c);
    };
    return (
      <div className="grid gap-2">
        {arr.map((it, i) => (
          <div key={it + i} className="flex items-center gap-3 rounded-lg p-3"
            style={{ background: "var(--surface-2)", border: "1px solid var(--line)" }}>
            <span className="mf-mono text-xs" style={{ color: "var(--ink-3)" }}>{i + 1}</span>
            <span className="flex-1 text-[15px]">{it}</span>
            <button className="cta-quiet" style={{ padding: "4px 9px", fontSize: 10 }} disabled={disabled || i === 0} onClick={() => move(i, -1)}>↑</button>
            <button className="cta-quiet" style={{ padding: "4px 9px", fontSize: 10 }} disabled={disabled || i === arr.length - 1} onClick={() => move(i, 1)}>↓</button>
          </div>))}
        <p className="text-xs" style={{ color: "var(--ink-3)" }}>Put them in the correct order, then continue.</p>
      </div>);
  }
  return (
    <>
      <textarea className="mf-field" rows={7} value={value ?? ""} disabled={disabled}
        onChange={(e) => onChange(e.target.value)} placeholder="Write your answer…" />
      <p className="mt-2 text-xs" style={{ color: "var(--ink-3)" }}>
        {q.minWords ? `At least ${q.minWords} words. ` : ""}This answer is marked by your teacher.
      </p>
    </>);
}
function Wrap({ children }: { children: React.ReactNode }) {
  return <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">{children}</div>;
}
