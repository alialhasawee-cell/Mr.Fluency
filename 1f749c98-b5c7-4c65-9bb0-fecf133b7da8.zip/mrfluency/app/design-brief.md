# Mr. Fluency — design brief

**Design read.** For adults in Basra and across Iraq who need English to pass IELTS,
work internationally or study abroad, and who are deciding whether to trust one teacher
with that goal. The register is a respected examiner's office: exact, warm, unhurried,
never a bootcamp and never a toy.

**Concept spine.** *The instrument and the door.* The site is a calibration
instrument that measures you honestly, and the measurement is what opens the door.
Every section either measures (levels, bands, modules, hours) or opens (the doorway
mark, the CTA garments, the contact row). Nothing decorative sits between the two.

**Delivery tier.** `editorial` — typography, exact numbers and bespoke chrome carry
the page; micro-motion only. Chosen because the product's promise is accuracy, and a
cinematic camera journey would undercut it.

**Animation mode:** non-animated — user picked Non-animated at intake.

**Locked palette.**
- `#8C2F39` garnet — the brand's authority colour, used for the mark, primary CTA and level C2.
- `#B5821F` brass — the light through the door; eyebrows, rules, the key.
- `#F4F3EF` chalk — the page ground, a warm neutral biased to the brass, not beige.
- `#1B1917` ink — near-black with a red bias so it sits under garnet without going cold.
- `#5C564E` slate-warm — secondary text.
- CEFR scale, cool-to-warm so level reads as temperature: `#5C7F8E` A1, `#3F7D68` A2,
  `#6C8B33` B1, `#B5821F` B2, `#B0602B` C1, `#8C2F39` C2, `#8A8479` A0.

Defence: garnet + brass is the colour of exam boards and bound certificates — it earns
authority without a single stock photograph. It deliberately avoids all five banned
families: no graphite/orange, no neon-on-black, no beige/oxblood drift (the ground is
cool-warm chalk, not cream), no AI violet, and it is not the previous build's palette.

**Locked type.** Display **Newsreader** (variable serif) for headings, level marks and
pull quotes — justified because the product is examination and publishing, where a
serif is the native voice. Body **Public Sans** for everything read at length. Utility
**IBM Plex Mono** for levels, scores, timers and codes, so every number is tabular.

**Section plan.** Home: door-mark hero (asymmetric split) → credential band (stat row)
→ four programmes (icon cards) → how placement works (numbered process, genuinely a
sequence) → the CEFR staircase (diagram) → contact row. No two consecutive sections
share a layout family; six sections, five families, eyebrow budget 2.

**Asset plan.** Hand-authored SVG throughout — the doorway-and-key hero mark, the AA
monogram, the CEFR staircase, four programme glyphs, the contact glyph set, favicon
and the OG card composed from the same geometry. No stock, no placeholders, no
generated photography (image generation was unavailable on this account, so the kit
is drawn rather than rendered — every asset is original and on-palette).

**CTA inventory.**
- *Take the placement test* — garnet slab, brass underline that draws on hover. The
  loudest object on the page; appears once per screen at most.
- *See the programmes* — ink hairline outline, no fill, letter-spaced label.
- *WhatsApp / Call / Email* — three chips with their own glyphs, brass on hover.
- *Resume your test* — brass-filled, only ever rendered when a live attempt exists.
