-- PHASE 1 + 2: identity, roles, sessions, and the course content hierarchy.
-- Additive only. Nothing in 0001/0002 is dropped or altered destructively.

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  phone TEXT,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'student',      -- owner | admin | teacher | student
  status TEXT NOT NULL DEFAULT 'active',     -- active | suspended
  email_verified INTEGER NOT NULL DEFAULT 0,
  verify_token TEXT,
  reset_token TEXT,
  reset_expires INTEGER,
  avatar_url TEXT,
  goal TEXT,
  preferred_course TEXT,
  cefr_level TEXT,
  xp INTEGER NOT NULL DEFAULT 0,
  streak_days INTEGER NOT NULL DEFAULT 0,
  last_active INTEGER,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS users_role ON users(role);

CREATE TABLE IF NOT EXISTS sessions_auth (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  last_seen INTEGER,
  ua TEXT
);
CREATE INDEX IF NOT EXISTS sessions_auth_user ON sessions_auth(user_id);

CREATE TABLE IF NOT EXISTS login_attempts (
  id TEXT PRIMARY KEY,
  key TEXT NOT NULL,          -- normalised email
  at INTEGER NOT NULL,
  ok INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS login_attempts_key ON login_attempts(key, at);

-- ---------- content hierarchy ----------
CREATE TABLE IF NOT EXISTS courses (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  subtitle TEXT,
  description TEXT,
  category TEXT,                              -- general | business | writing | ielts | specialist
  goal TEXT,                                  -- maps to placement goals
  color TEXT,
  thumbnail_url TEXT,
  instructor TEXT,
  status TEXT NOT NULL DEFAULT 'draft',       -- draft | published | archived
  access TEXT NOT NULL DEFAULT 'open',        -- open | invite | paid
  price_cents INTEGER NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'USD',
  sort INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS course_levels (
  id TEXT PRIMARY KEY,
  course_id TEXT NOT NULL,
  cefr TEXT NOT NULL,
  title TEXT NOT NULL,
  summary TEXT,
  sort INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft',
  unlock_rule TEXT NOT NULL DEFAULT 'none',   -- none | previous_level
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS course_levels_course ON course_levels(course_id, sort);

CREATE TABLE IF NOT EXISTS modules (
  id TEXT PRIMARY KEY,
  level_id TEXT NOT NULL,
  course_id TEXT NOT NULL,
  code TEXT,
  title TEXT NOT NULL,
  summary TEXT,
  hours INTEGER NOT NULL DEFAULT 0,
  sort INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft',
  unlock_rule TEXT NOT NULL DEFAULT 'previous_module',  -- none | previous_module | min_score
  min_score INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS modules_level ON modules(level_id, sort);

CREATE TABLE IF NOT EXISTS lessons (
  id TEXT PRIMARY KEY,
  module_id TEXT NOT NULL,
  course_id TEXT NOT NULL,
  level_id TEXT NOT NULL,
  title TEXT NOT NULL,
  summary TEXT,
  objective TEXT,
  duration_min INTEGER NOT NULL DEFAULT 15,
  sort INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft',
  unlock_rule TEXT NOT NULL DEFAULT 'previous_lesson',
  completion_rule TEXT NOT NULL DEFAULT '{"blocks":true,"quiz":false,"minQuizPct":0}',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS lessons_module ON lessons(module_id, sort);

CREATE TABLE IF NOT EXISTS lesson_blocks (
  id TEXT PRIMARY KEY,
  lesson_id TEXT NOT NULL,
  kind TEXT NOT NULL,            -- heading|text|image|gallery|vocab|grammar|example|dialogue|audio|video|animation|pdf|reading|listening|speaking|writing|activity|quiz|assignment|callout
  sort INTEGER NOT NULL DEFAULT 0,
  required INTEGER NOT NULL DEFAULT 0,
  data TEXT NOT NULL DEFAULT '{}',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS lesson_blocks_lesson ON lesson_blocks(lesson_id, sort);

CREATE TABLE IF NOT EXISTS media (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  kind TEXT NOT NULL,            -- image | audio | video | animation | pdf | document
  url TEXT NOT NULL,
  storage_key TEXT,
  mime TEXT,
  bytes INTEGER,
  duration_s INTEGER,
  alt TEXT,
  thumb_url TEXT,
  course_id TEXT,
  lesson_id TEXT,
  created_by TEXT,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS media_kind ON media(kind, created_at);
