-- PHASE 5-9: question bank, quizzes, enrolment, progress, certificates,
-- assignments, gamification and notifications. Additive only.

CREATE TABLE IF NOT EXISTS questions (
  id TEXT PRIMARY KEY,
  bank TEXT NOT NULL DEFAULT 'general',   -- placement | course | general
  type TEXT NOT NULL,                     -- mcq|multi|truefalse|gap|match|order|writing|speaking
  cefr TEXT,
  skill TEXT,                             -- Grammar|Vocabulary|Reading|Listening|Writing|Speaking
  topic TEXT,
  difficulty INTEGER NOT NULL DEFAULT 2,
  prompt TEXT NOT NULL,
  passage TEXT,
  media_id TEXT,
  explanation TEXT,
  points INTEGER NOT NULL DEFAULT 1,
  data TEXT NOT NULL DEFAULT '{}',        -- type-specific payload (pairs, ordering, gaps…)
  status TEXT NOT NULL DEFAULT 'published',
  created_by TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS questions_tags ON questions(bank, cefr, skill);

CREATE TABLE IF NOT EXISTS question_options (
  id TEXT PRIMARY KEY,
  question_id TEXT NOT NULL,
  sort INTEGER NOT NULL DEFAULT 0,
  text TEXT NOT NULL,
  is_correct INTEGER NOT NULL DEFAULT 0,
  media_id TEXT
);
CREATE INDEX IF NOT EXISTS question_options_q ON question_options(question_id, sort);

CREATE TABLE IF NOT EXISTS quizzes (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  kind TEXT NOT NULL DEFAULT 'lesson',    -- lesson | module_exam | final_exam
  course_id TEXT, level_id TEXT, module_id TEXT, lesson_id TEXT,
  pass_pct INTEGER NOT NULL DEFAULT 60,
  max_attempts INTEGER NOT NULL DEFAULT 0,   -- 0 = unlimited
  time_limit_s INTEGER NOT NULL DEFAULT 0,   -- 0 = untimed
  per_question_s INTEGER NOT NULL DEFAULT 0,
  sequential INTEGER NOT NULL DEFAULT 1,     -- 1 = no skipping (spec 13)
  shuffle INTEGER NOT NULL DEFAULT 1,
  show_feedback INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'draft',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS quizzes_owner ON quizzes(course_id, module_id, lesson_id);

CREATE TABLE IF NOT EXISTS quiz_questions (
  id TEXT PRIMARY KEY,
  quiz_id TEXT NOT NULL,
  question_id TEXT NOT NULL,
  sort INTEGER NOT NULL DEFAULT 0,
  points INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS quiz_questions_quiz ON quiz_questions(quiz_id, sort);

CREATE TABLE IF NOT EXISTS quiz_attempts (
  id TEXT PRIMARY KEY,
  quiz_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  attempt_no INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'IN_PROGRESS',  -- IN_PROGRESS|PAUSED|COMPLETED|EXPIRED
  order_json TEXT NOT NULL DEFAULT '[]',
  cursor INTEGER NOT NULL DEFAULT 0,
  q_started_at INTEGER, q_deadline INTEGER, remaining_ms INTEGER, paused_at INTEGER,
  pause_count INTEGER NOT NULL DEFAULT 0, total_paused_ms INTEGER NOT NULL DEFAULT 0,
  score INTEGER NOT NULL DEFAULT 0, max_score INTEGER NOT NULL DEFAULT 0,
  pct INTEGER NOT NULL DEFAULT 0, passed INTEGER NOT NULL DEFAULT 0,
  started_at INTEGER NOT NULL, submitted_at INTEGER, updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS quiz_attempts_user ON quiz_attempts(user_id, quiz_id);

CREATE TABLE IF NOT EXISTS quiz_answers (
  id TEXT PRIMARY KEY,
  attempt_id TEXT NOT NULL,
  question_id TEXT NOT NULL,
  response TEXT,
  correct INTEGER NOT NULL DEFAULT 0,
  points INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'ANSWERED',  -- ANSWERED | TIMED_OUT | PENDING_REVIEW
  answered_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS quiz_answers_attempt ON quiz_answers(attempt_id);

CREATE TABLE IF NOT EXISTS enrollments (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  course_id TEXT NOT NULL,
  level_id TEXT,
  status TEXT NOT NULL DEFAULT 'active',    -- active | completed | expired | revoked
  source TEXT NOT NULL DEFAULT 'self',      -- self | admin | placement | invite
  enrolled_at INTEGER NOT NULL,
  expires_at INTEGER,
  completed_at INTEGER,
  progress_pct INTEGER NOT NULL DEFAULT 0,
  last_lesson_id TEXT,
  UNIQUE (user_id, course_id)
);
CREATE INDEX IF NOT EXISTS enrollments_user ON enrollments(user_id);

CREATE TABLE IF NOT EXISTS progress (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  lesson_id TEXT NOT NULL,
  course_id TEXT NOT NULL,
  module_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'started',   -- started | completed
  checks TEXT NOT NULL DEFAULT '{}',        -- which completion requirements are met
  seconds INTEGER NOT NULL DEFAULT 0,
  started_at INTEGER NOT NULL,
  completed_at INTEGER,
  updated_at INTEGER NOT NULL,
  UNIQUE (user_id, lesson_id)
);
CREATE INDEX IF NOT EXISTS progress_user ON progress(user_id, course_id);

CREATE TABLE IF NOT EXISTS certificates (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  user_id TEXT NOT NULL,
  course_id TEXT NOT NULL,
  level_id TEXT,
  student_name TEXT NOT NULL,
  course_title TEXT NOT NULL,
  cefr TEXT,
  score_pct INTEGER NOT NULL DEFAULT 0,
  instructor TEXT NOT NULL,
  issued_at INTEGER NOT NULL,
  revoked INTEGER NOT NULL DEFAULT 0,
  revoked_reason TEXT
);

CREATE TABLE IF NOT EXISTS assignments (
  id TEXT PRIMARY KEY,
  lesson_id TEXT, course_id TEXT,
  title TEXT NOT NULL,
  instructions TEXT,
  skill TEXT,
  max_points INTEGER NOT NULL DEFAULT 10,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS submissions (
  id TEXT PRIMARY KEY,
  assignment_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  body TEXT,
  media_id TEXT,
  status TEXT NOT NULL DEFAULT 'submitted',  -- submitted | graded | returned
  score INTEGER,
  feedback TEXT,
  submitted_at INTEGER NOT NULL,
  graded_at INTEGER,
  graded_by TEXT
);
CREATE INDEX IF NOT EXISTS submissions_user ON submissions(user_id);

CREATE TABLE IF NOT EXISTS achievements (
  id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, title TEXT NOT NULL,
  description TEXT, icon TEXT, xp INTEGER NOT NULL DEFAULT 0, rule TEXT
);
CREATE TABLE IF NOT EXISTS student_achievements (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL, achievement_id TEXT NOT NULL,
  earned_at INTEGER NOT NULL, UNIQUE (user_id, achievement_id)
);
CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL, kind TEXT NOT NULL,
  title TEXT NOT NULL, body TEXT, link TEXT,
  read_at INTEGER, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS notifications_user ON notifications(user_id, created_at);
CREATE TABLE IF NOT EXISTS announcements (
  id TEXT PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL,
  audience TEXT NOT NULL DEFAULT 'all', created_by TEXT, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS email_outbox (
  id TEXT PRIMARY KEY, to_email TEXT NOT NULL, subject TEXT NOT NULL,
  body TEXT NOT NULL, kind TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'PENDING',
  error TEXT, retry_count INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL, sent_at INTEGER
);

-- bind existing placement attempts to accounts (additive column)
ALTER TABLE attempts ADD COLUMN user_id TEXT;
