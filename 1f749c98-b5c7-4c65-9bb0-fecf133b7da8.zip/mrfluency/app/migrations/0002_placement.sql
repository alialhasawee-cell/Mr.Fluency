CREATE TABLE IF NOT EXISTS candidates (
  ckey TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT,
  extra_attempts INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS attempts (
  id TEXT PRIMARY KEY,
  ckey TEXT NOT NULL,
  name TEXT NOT NULL,
  email TEXT,
  goal TEXT NOT NULL,
  attempt_no INTEGER NOT NULL,
  status TEXT NOT NULL,
  plan TEXT NOT NULL,
  bi INTEGER NOT NULL DEFAULT 0,
  qi INTEGER NOT NULL DEFAULT 0,
  q_started_at INTEGER,
  q_deadline INTEGER,
  remaining_ms INTEGER,
  paused_at INTEGER,
  pause_count INTEGER NOT NULL DEFAULT 0,
  total_paused_ms INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  completed_at INTEGER,
  result TEXT
);
CREATE INDEX IF NOT EXISTS attempts_ckey ON attempts(ckey);
CREATE INDEX IF NOT EXISTS attempts_updated ON attempts(updated_at);
CREATE TABLE IF NOT EXISTS responses (
  id TEXT PRIMARY KEY,
  attempt_id TEXT NOT NULL,
  item_id TEXT NOT NULL,
  level TEXT NOT NULL,
  skill TEXT NOT NULL,
  choice INTEGER,
  correct INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  started_at INTEGER NOT NULL,
  deadline_at INTEGER NOT NULL,
  submitted_at INTEGER NOT NULL,
  time_used_ms INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS responses_attempt ON responses(attempt_id);
CREATE TABLE IF NOT EXISTS audit (
  id TEXT PRIMARY KEY,
  attempt_id TEXT,
  ckey TEXT,
  event TEXT NOT NULL,
  detail TEXT,
  at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS audit_at ON audit(at);
CREATE TABLE IF NOT EXISTS enquiries (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  goal TEXT,
  message TEXT,
  at INTEGER NOT NULL
);
